package io.orchestra.example.domain.service;

import io.orchestra.example.domain.model.Order;
import io.orchestra.example.domain.model.OrderItem;
import io.orchestra.example.api.dto.OrderRequest;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * 订单领域服务。
 * 
 * <p>封装订单相关的领域逻辑。</p>
 */
@Service
public class OrderDomainService {
    
    /**
     * 创建订单。
     */
    public Order createOrder(OrderRequest request) {
        Order order = new Order();
        order.setOrderId("ORDER-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        order.setCustomerId(request.getCustomerId());
        
        // 计算总金额
        BigDecimal totalAmount = request.getItems().stream()
            .map(item -> item.getUnitPrice().multiply(new BigDecimal(item.getQuantity())))
            .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        order.setTotalAmount(totalAmount);
        
        // 转换订单项
        order.setItems(request.getItems().stream()
            .map(item -> new OrderItem(
                "ITEM-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(),
                item.getProductId(),
                item.getProductName(),
                item.getQuantity(),
                item.getUnitPrice()
            ))
            .collect(Collectors.toList()));
        
        order.setStatus(Order.OrderStatus.CREATED);
        return order;
    }
    
    /**
     * 验证订单。
     */
    public void validateOrder(Order order) {
        if (order == null) {
            throw new IllegalArgumentException("订单不能为空");
        }
        if (order.getTotalAmount() == null || order.getTotalAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("订单金额必须大于 0");
        }
        if (order.getItems() == null || order.getItems().isEmpty()) {
            throw new IllegalArgumentException("订单必须包含至少一个商品");
        }
        order.setStatus(Order.OrderStatus.VALIDATED);
    }
    
    /**
     * 确认订单。
     */
    public void confirmOrder(Order order) {
        if (order == null) {
            throw new IllegalArgumentException("订单不能为空");
        }
        // 订单确认逻辑
        // ...
    }
    
    /**
     * 完成订单。
     */
    public void finalizeOrder(Order order) {
        if (order == null) {
            throw new IllegalArgumentException("订单不能为空");
        }
        order.setStatus(Order.OrderStatus.COMPLETED);
    }
    
    /**
     * 取消订单。
     */
    public void cancelOrder(Order order) {
        if (order == null) {
            throw new IllegalArgumentException("订单不能为空");
        }
        order.setStatus(Order.OrderStatus.CANCELLED);
    }
}


