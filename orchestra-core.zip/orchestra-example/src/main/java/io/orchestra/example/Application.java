package io.orchestra.example;

import io.orchestra.spring.boot.annotation.EnableOrchestra;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Orchestra 示例应用主类。
 * 
 * <p>电商订单处理系统示例，展示 Orchestra 框架的所有核心特性。</p>
 */
@SpringBootApplication
@EnableOrchestra
public class Application {
    
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}


