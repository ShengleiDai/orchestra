package io.orchestra.example.application.procedure;

import io.orchestra.core.Composer;
import io.orchestra.core.Procedure;
import io.orchestra.core.Procedurable;
import io.orchestra.example.api.dto.OrderRequest;
import io.orchestra.example.api.dto.OrderResponse;
import io.orchestra.example.context.OrderContext;
import io.orchestra.example.domain.model.Payment;
import io.orchestra.example.domain.service.PaymentService;
import io.orchestra.spring.boot.annotation.OrchestraProcedure;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * 支付处理子流程。
 * 
 * <p>封装支付相关的业务逻辑，可以在主流程中复用。</p>
 */
@OrchestraProcedure
public class PaymentProcedure implements Procedure<OrderRequest, OrderResponse, OrderContext> {
    
    private static final Logger logger = LoggerFactory.getLogger(PaymentProcedure.class);
    
    @Autowired
    private PaymentService paymentService;
    
    @Override
    public Procedurable<OrderContext> execute(OrderContext context, Composer composer) {
        return composer.just(context)
            // 提交支付请求
            .sync(ctx -> {
                String paymentId = paymentService.submitPayment(
                    ctx.getOrder().getOrderId(),
                    ctx.getOrder().getTotalAmount(),
                    ctx.getRequest().getPaymentMethod()
                );
                Payment payment = new Payment(paymentId, ctx.getOrder().getOrderId(), 
                    ctx.getOrder().getTotalAmount(), ctx.getRequest().getPaymentMethod());
                payment.setStatus(Payment.PaymentStatus.PROCESSING);
                ctx.setPayment(payment);
                ctx.setAttribute("paymentId", paymentId);
                logger.info("提交支付请求: paymentId={}, orderId={}", paymentId, ctx.getOrder().getOrderId());
            })
            // 处理支付（异步）
            .async(ctx -> paymentService.processPayment(
                ctx.getOrder().getOrderId(),
                ctx.getOrder().getTotalAmount(),
                ctx.getRequest().getPaymentMethod()
            ))
                .onErrorRetry(RuntimeException.class, 2)
                .timeout(30, TimeUnit.SECONDS, ctx -> {
                    logger.warn("支付处理超时: orderId={}", ctx.getOrder().getOrderId());
                    if (ctx.getPayment() != null) {
                        ctx.getPayment().setStatus(Payment.PaymentStatus.FAILED);
                    }
                })
            // 确认支付
            .sync(ctx -> {
                String paymentId = (String) ctx.getAttribute("paymentId");
                if (paymentId != null) {
                    paymentService.confirmPayment(paymentId);
                    if (ctx.getPayment() != null) {
                        ctx.getPayment().setStatus(Payment.PaymentStatus.SUCCESS);
                    }
                    logger.info("确认支付: paymentId={}", paymentId);
                }
            });
    }
}


