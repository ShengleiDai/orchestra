package io.orchestra.example.application.procedure;

import io.orchestra.core.Composer;
import io.orchestra.core.Procedure;
import io.orchestra.core.Procedurable;
import io.orchestra.example.api.dto.OrderRequest;
import io.orchestra.example.api.dto.OrderResponse;
import io.orchestra.example.context.OrderContext;
import io.orchestra.example.domain.service.ShippingService;
import io.orchestra.spring.boot.annotation.OrchestraProcedure;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 发货处理子流程。
 * 
 * <p>封装发货相关的业务逻辑，可以在主流程中复用。</p>
 */
@OrchestraProcedure
public class ShippingProcedure implements Procedure<OrderRequest, OrderResponse, OrderContext> {
    
    private static final Logger logger = LoggerFactory.getLogger(ShippingProcedure.class);
    
    @Autowired
    private ShippingService shippingService;
    
    @Override
    public Procedurable<OrderContext> execute(OrderContext context, Composer composer) {
        return composer.just(context)
            // 准备发货（异步）
            .async(ctx -> shippingService.prepareShipping(
                ctx.getOrder(),
                ctx.getRequest().getShippingAddress()
            ).thenApply(shipping -> {
                // 将返回的 Shipping 对象设置到 context 中
                ctx.setShipping(shipping);
                logger.debug("准备发货完成: orderId={}, shippingId={}", 
                    ctx.getOrder().getOrderId(), shipping.getShippingId());
                return shipping;
            }))
                .onErrorResume(Exception.class, error -> {
                    logger.warn("发货准备失败: {}", error.getMessage());
                    return composer.just(context).sync(ctx -> {
                        // 降级处理：创建默认物流信息
                        // 实际场景中，这里会创建默认的 Shipping 对象
                    });
                })
            // 安排发货
            .sync(ctx -> {
                if (ctx.getShipping() != null) {
                    shippingService.arrangeShipping(ctx.getOrder(), ctx.getShipping());
                    logger.info("安排发货: orderId={}, trackingNumber={}", 
                        ctx.getOrder().getOrderId(), ctx.getShipping().getTrackingNumber());
                } else {
                    logger.warn("物流信息为空，无法安排发货: orderId={}", ctx.getOrder().getOrderId());
                }
            });
    }
}

