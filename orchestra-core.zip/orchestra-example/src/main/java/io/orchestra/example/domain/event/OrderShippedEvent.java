package io.orchestra.example.domain.event;

import io.orchestra.core.eventbus.BaseEvent;

/**
 * 订单发货事件。
 */
public class OrderShippedEvent extends BaseEvent {
    
    private String orderId;
    private String shippingId;
    private String trackingNumber;
    
    public OrderShippedEvent() {}
    
    public OrderShippedEvent(String orderId, String shippingId, String trackingNumber) {
        this.orderId = orderId;
        this.shippingId = shippingId;
        this.trackingNumber = trackingNumber;
    }
    
    // Getters and Setters
    public String getOrderId() {
        return orderId;
    }
    
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    
    public String getShippingId() {
        return shippingId;
    }
    
    public void setShippingId(String shippingId) {
        this.shippingId = shippingId;
    }
    
    public String getTrackingNumber() {
        return trackingNumber;
    }
    
    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }
}


