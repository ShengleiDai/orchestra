package io.orchestra.example.application.procedure;

import io.orchestra.core.Composer;
import io.orchestra.core.Procedure;
import io.orchestra.core.Procedurable;
import io.orchestra.example.domain.event.OrderCreatedEvent;
import io.orchestra.example.domain.service.CustomerService;
import io.orchestra.example.domain.service.NotificationService;
import io.orchestra.spring.boot.annotation.OnEvent;
import io.orchestra.spring.boot.annotation.OrchestraProcedure;
import io.orchestra.spring.boot.context.EventRuntimeContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 订单创建事件处理流程。
 * 
 * <p>当收到订单创建事件时，自动触发此流程，执行后续处理逻辑。</p>
 * 
 * <p>使用 {@link OnEvent} 注解标记此 Procedure 监听 {@link OrderCreatedEvent} 事件。</p>
 * 
 * <p>此流程演示了事件驱动的 Procedure 使用方式：</p>
 * <ul>
 *   <li>自动监听订单创建事件</li>
 *   <li>异步执行后续处理逻辑</li>
 *   <li>支持依赖注入使用其他服务</li>
 * </ul>
 */
@OrchestraProcedure
@OnEvent(value = OrderCreatedEvent.class, async = true)
public class OrderCreatedHandlerProcedure implements Procedure<OrderCreatedEvent, Void, EventRuntimeContext<OrderCreatedEvent>> {
    
    private static final Logger logger = LoggerFactory.getLogger(OrderCreatedHandlerProcedure.class);
    
    @Autowired
    private NotificationService notificationService;
    
    @Autowired
    private CustomerService customerService;
    
    @Override
    public Procedurable<EventRuntimeContext<OrderCreatedEvent>> execute(
            EventRuntimeContext<OrderCreatedEvent> context, 
            Composer composer) {
        
        return composer.just(context)
            .sync(ctx -> {
                OrderCreatedEvent event = ctx.getEvent();
                logger.info("【事件驱动】开始处理订单创建事件: orderId={}, customerId={}, amount={}", 
                    event.getOrderId(), event.getCustomerId(), event.getAmount());
                
                // 将事件信息存储到 context 中，供后续步骤使用
                ctx.setAttribute("orderId", event.getOrderId());
                ctx.setAttribute("customerId", event.getCustomerId());
                ctx.setAttribute("amount", event.getAmount());
            })
            .async(ctx -> {
                OrderCreatedEvent event = ctx.getEvent();
                // 加载客户信息（同步方式，因为 CustomerService.getCustomer 是同步方法）
                try {
                    io.orchestra.example.domain.model.Customer customer = customerService.getCustomer(event.getCustomerId());
                    // 发送订单创建后的欢迎通知
                    // 注意：这里简化处理，实际场景中需要加载订单信息
                    return notificationService.sendOrderConfirmation(customer, null)
                        .thenRun(() -> {
                            logger.info("【事件驱动】订单创建欢迎通知已发送: orderId={}, customerId={}", 
                                event.getOrderId(), event.getCustomerId());
                        });
                } catch (Exception e) {
                    logger.error("【事件驱动】处理订单创建事件失败: orderId={}", event.getOrderId(), e);
                    throw new RuntimeException(e);
                }
            })
            .sync(ctx -> {
                OrderCreatedEvent event = ctx.getEvent();
                // 执行其他后续处理，例如：
                // - 更新用户统计
                // - 触发推荐系统
                // - 记录订单创建日志
                // - 发送营销活动通知
                logger.info("【事件驱动】订单创建事件后续处理完成: orderId={}, customerId={}", 
                    event.getOrderId(), event.getCustomerId());
            });
    }
}

