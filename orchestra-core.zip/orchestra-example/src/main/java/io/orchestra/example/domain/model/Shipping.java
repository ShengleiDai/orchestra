package io.orchestra.example.domain.model;

import java.time.LocalDateTime;

/**
 * 物流领域模型。
 */
public class Shipping {
    
    private String shippingId;
    private String orderId;
    private String trackingNumber;
    private ShippingStatus status;
    private String carrier;
    private String address;
    private LocalDateTime shipTime;
    private LocalDateTime deliverTime;
    
    public Shipping() {}
    
    public Shipping(String shippingId, String orderId, String carrier, String address) {
        this.shippingId = shippingId;
        this.orderId = orderId;
        this.carrier = carrier;
        this.address = address;
        this.status = ShippingStatus.PENDING;
    }
    
    // Getters and Setters
    public String getShippingId() {
        return shippingId;
    }
    
    public void setShippingId(String shippingId) {
        this.shippingId = shippingId;
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    
    public String getTrackingNumber() {
        return trackingNumber;
    }
    
    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }
    
    public ShippingStatus getStatus() {
        return status;
    }
    
    public void setStatus(ShippingStatus status) {
        this.status = status;
        if (status == ShippingStatus.SHIPPED && shipTime == null) {
            this.shipTime = LocalDateTime.now();
        }
        if (status == ShippingStatus.DELIVERED && deliverTime == null) {
            this.deliverTime = LocalDateTime.now();
        }
    }
    
    public String getCarrier() {
        return carrier;
    }
    
    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public LocalDateTime getShipTime() {
        return shipTime;
    }
    
    public void setShipTime(LocalDateTime shipTime) {
        this.shipTime = shipTime;
    }
    
    public LocalDateTime getDeliverTime() {
        return deliverTime;
    }
    
    public void setDeliverTime(LocalDateTime deliverTime) {
        this.deliverTime = deliverTime;
    }
    
    /**
     * 物流状态枚举。
     */
    public enum ShippingStatus {
        PENDING,    // 待发货
        SHIPPED,    // 已发货
        DELIVERED,  // 已送达
        CANCELLED   // 已取消
    }
}


