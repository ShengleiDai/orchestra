package io.orchestra.example.domain.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 支付领域模型。
 */
public class Payment {
    
    private String paymentId;
    private String orderId;
    private BigDecimal amount;
    private PaymentStatus status;
    private String paymentMethod;
    private LocalDateTime createTime;
    private LocalDateTime completeTime;
    
    public Payment() {
        this.createTime = LocalDateTime.now();
    }
    
    public Payment(String paymentId, String orderId, BigDecimal amount, String paymentMethod) {
        this();
        this.paymentId = paymentId;
        this.orderId = orderId;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.status = PaymentStatus.PENDING;
    }
    
    // Getters and Setters
    public String getPaymentId() {
        return paymentId;
    }
    
    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    
    public BigDecimal getAmount() {
        return amount;
    }
    
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
    
    public PaymentStatus getStatus() {
        return status;
    }
    
    public void setStatus(PaymentStatus status) {
        this.status = status;
        if (status == PaymentStatus.SUCCESS || status == PaymentStatus.FAILED) {
            this.completeTime = LocalDateTime.now();
        }
    }
    
    public String getPaymentMethod() {
        return paymentMethod;
    }
    
    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
    
    public LocalDateTime getCreateTime() {
        return createTime;
    }
    
    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }
    
    public LocalDateTime getCompleteTime() {
        return completeTime;
    }
    
    public void setCompleteTime(LocalDateTime completeTime) {
        this.completeTime = completeTime;
    }
    
    /**
     * 支付状态枚举。
     */
    public enum PaymentStatus {
        PENDING,    // 待支付
        PROCESSING,// 处理中
        SUCCESS,    // 成功
        FAILED,     // 失败
        REFUNDED    // 已退款
    }
}


