package io.orchestra.example.api.controller;

import io.orchestra.example.api.dto.OrderRequest;
import io.orchestra.example.api.dto.OrderResponse;
import io.orchestra.example.application.service.OrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * 订单控制器。
 * 
 * <p>提供订单相关的 REST API 接口。</p>
 */
@RestController
@RequestMapping("/api/orders")
public class OrderController {
    
    private static final Logger logger = LoggerFactory.getLogger(OrderController.class);
    
    @Autowired
    private OrderService orderService;
    
    /**
     * 创建订单（同步）。
     */
    @PostMapping
    public ResponseEntity<OrderResponse> createOrder(@RequestBody OrderRequest request) {
        logger.info("收到订单创建请求: customerId={}", request.getCustomerId());
        
        try {
            OrderResponse response = orderService.createOrder(request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("订单创建失败", e);
            OrderResponse errorResponse = new OrderResponse();
            errorResponse.setStatus("FAILED");
            errorResponse.setMessage("订单创建失败: " + e.getMessage());
            return ResponseEntity.internalServerError().body(errorResponse);
        }
    }
    
    /**
     * 异步创建订单。
     */
    @PostMapping("/async")
    public ResponseEntity<java.util.concurrent.CompletableFuture<OrderResponse>> createOrderAsync(
            @RequestBody OrderRequest request) {
        logger.info("收到异步订单创建请求: customerId={}", request.getCustomerId());
        
        java.util.concurrent.CompletableFuture<OrderResponse> future = 
            orderService.createOrderAsync(request);
        
        return ResponseEntity.accepted().body(future);
    }
    
    /**
     * 健康检查。
     */
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("OK");
    }
}


