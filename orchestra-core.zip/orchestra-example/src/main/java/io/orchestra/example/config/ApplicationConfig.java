package io.orchestra.example.config;

import io.orchestra.core.eventbus.EventBus;
import io.orchestra.example.domain.event.OrderCreatedEvent;
import io.orchestra.example.domain.event.PaymentCompletedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

/**
 * 应用配置类。
 * 
 * <p>配置事件订阅等应用级别的设置。</p>
 */
@Configuration
public class ApplicationConfig {
    
    private static final Logger logger = LoggerFactory.getLogger(ApplicationConfig.class);
    
    @Autowired
    private EventBus eventBus;
    
    /**
     * 初始化事件订阅。
     */
    @PostConstruct
    public void initEventSubscriptions() {
        // 订阅订单创建事件
        eventBus.subscribe(OrderCreatedEvent.class, event -> {
            logger.info("收到订单创建事件: orderId={}, customerId={}, amount={}", 
                event.getOrderId(), event.getCustomerId(), event.getAmount());
            // 实际场景中，这里可以触发其他业务流程，如：
            // - 发送欢迎邮件
            // - 更新用户统计
            // - 触发推荐系统
        });
        
        // 订阅支付完成事件
        eventBus.subscribe(PaymentCompletedEvent.class, event -> {
            logger.info("收到支付完成事件: paymentId={}, orderId={}, success={}", 
                event.getPaymentId(), event.getOrderId(), event.isSuccess());
            // 实际场景中，这里可以触发其他业务流程，如：
            // - 更新订单状态
            // - 触发发货流程
            // - 发送支付确认通知
        });
        
        logger.info("事件订阅初始化完成");
    }
}


