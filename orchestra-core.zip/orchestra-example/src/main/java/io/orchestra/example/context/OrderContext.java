package io.orchestra.example.context;

import io.orchestra.core.StandardRuntimeContext;
import io.orchestra.example.api.dto.OrderRequest;
import io.orchestra.example.api.dto.OrderResponse;
import io.orchestra.example.domain.model.Customer;
import io.orchestra.example.domain.model.Order;
import io.orchestra.example.domain.model.Payment;
import io.orchestra.example.domain.model.Shipping;

/**
 * 订单处理运行时上下文。
 * 
 * <p>封装订单处理流程执行期间的所有上下文信息。</p>
 */
public class OrderContext extends StandardRuntimeContext<OrderRequest, OrderResponse> {
    
    private Order order;
    private Customer customer;
    private Payment payment;
    private Shipping shipping;
    
    public OrderContext(OrderRequest request) {
        super(request);
    }
    
    // Getters and Setters
    public Order getOrder() {
        return order;
    }
    
    public void setOrder(Order order) {
        this.order = order;
    }
    
    public Customer getCustomer() {
        return customer;
    }
    
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    
    public Payment getPayment() {
        return payment;
    }
    
    public void setPayment(Payment payment) {
        this.payment = payment;
    }
    
    public Shipping getShipping() {
        return shipping;
    }
    
    public void setShipping(Shipping shipping) {
        this.shipping = shipping;
    }
    
    /**
     * 判断是否为 VIP 客户。
     */
    public boolean isVipCustomer() {
        return customer != null && customer.isVip();
    }
    
    /**
     * 获取订单金额。
     */
    public java.math.BigDecimal getOrderAmount() {
        return order != null ? order.getTotalAmount() : java.math.BigDecimal.ZERO;
    }
}


