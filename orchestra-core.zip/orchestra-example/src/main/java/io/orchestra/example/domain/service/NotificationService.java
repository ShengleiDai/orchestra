package io.orchestra.example.domain.service;

import io.orchestra.example.domain.model.Customer;
import io.orchestra.example.domain.model.Order;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

/**
 * 通知服务。
 * 
 * <p>模拟通知发送服务。</p>
 */
@Service
public class NotificationService {
    
    /**
     * 发送订单确认通知（异步）。
     */
    public CompletableFuture<Void> sendOrderConfirmation(Customer customer, Order order) {
        return CompletableFuture.runAsync(() -> {
            // 模拟发送通知延迟
            try {
                Thread.sleep(30);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            // 实际场景中，这里会发送邮件或短信
            // System.out.println("发送订单确认通知给: " + customer.getEmail() + ", 订单ID: " + order.getOrderId());
        });
    }
    
    /**
     * 发送订单发货通知（异步）。
     */
    public CompletableFuture<Void> sendShippingNotification(Customer customer, Order order, String trackingNumber) {
        return CompletableFuture.runAsync(() -> {
            try {
                Thread.sleep(30);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            // 实际场景中，这里会发送发货通知
            // System.out.println("发送发货通知给: " + customer.getEmail() + ", 订单ID: " + order.getOrderId() + ", 物流单号: " + trackingNumber);
        });
    }
}


