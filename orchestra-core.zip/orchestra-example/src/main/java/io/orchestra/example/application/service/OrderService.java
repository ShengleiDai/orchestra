package io.orchestra.example.application.service;

import io.orchestra.example.api.dto.OrderRequest;
import io.orchestra.example.api.dto.OrderResponse;
import io.orchestra.example.application.procedure.OrderCreationProcedure;
import io.orchestra.example.context.OrderContext;
import io.orchestra.core.RuntimeContext;
import io.orchestra.spring.boot.autoconfigure.ReactiveApplicatorFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 订单应用服务。
 * 
 * <p>应用层服务，负责协调业务流程的执行。</p>
 */
@Service
public class OrderService {
    
    private static final Logger logger = LoggerFactory.getLogger(OrderService.class);
    
    @Autowired
    private ReactiveApplicatorFactory applicatorFactory;
    
    @Autowired
    private OrderCreationProcedure orderCreationProcedure;
    
    /**
     * 创建订单。
     */
    public OrderResponse createOrder(OrderRequest request) {
        logger.info("开始处理订单创建请求: customerId={}", request.getCustomerId());
        
        // 创建上下文
        OrderContext context = new OrderContext(request);
        
        // 创建 Applicator 并执行流程
        io.orchestra.core.ReactiveApplicator<OrderRequest, OrderResponse, OrderContext> applicator = 
            applicatorFactory.<OrderRequest, OrderResponse, OrderContext>create();
        RuntimeContext<OrderRequest, OrderResponse> result = 
            applicator.apply(context, orderCreationProcedure);
        
        logger.info("订单创建完成: orderId={}", result.getResponse().getOrderId());
        return result.getResponse();
    }
    
    /**
     * 异步创建订单。
     */
    public java.util.concurrent.CompletableFuture<OrderResponse> createOrderAsync(OrderRequest request) {
        logger.info("开始异步处理订单创建请求: customerId={}", request.getCustomerId());
        
        OrderContext context = new OrderContext(request);
        io.orchestra.core.ReactiveApplicator<OrderRequest, OrderResponse, OrderContext> applicator = 
            applicatorFactory.<OrderRequest, OrderResponse, OrderContext>create();
        
        return applicator.applyAsync(context, orderCreationProcedure)
            .toCompletionStage()
            .toCompletableFuture()
            .thenApply((RuntimeContext<OrderRequest, OrderResponse> ctx) -> ctx.getResponse())
            .whenComplete((response, error) -> {
                if (error != null) {
                    logger.error("订单创建失败", error);
                } else {
                    logger.info("订单创建完成: orderId={}", response.getOrderId());
                }
            });
    }
}

