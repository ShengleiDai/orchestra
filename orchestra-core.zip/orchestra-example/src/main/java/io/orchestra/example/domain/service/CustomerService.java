package io.orchestra.example.domain.service;

import io.orchestra.example.domain.model.Customer;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * 客户服务。
 * 
 * <p>模拟客户数据服务。</p>
 */
@Service
public class CustomerService {
    
    // 模拟客户数据存储
    private final Map<String, Customer> customers = new HashMap<>();
    
    public CustomerService() {
        // 初始化一些测试数据
        customers.put("C001", new Customer("C001", "张三", "zhangsan@example.com", Customer.CustomerType.NORMAL));
        customers.put("C002", new Customer("C002", "李四", "lisi@example.com", Customer.CustomerType.VIP));
        customers.put("C003", new Customer("C003", "王五", "wangwu@example.com", Customer.CustomerType.ENTERPRISE));
    }
    
    /**
     * 根据客户 ID 获取客户信息。
     */
    public Customer getCustomer(String customerId) {
        Customer customer = customers.get(customerId);
        if (customer == null) {
            // 默认创建普通客户
            customer = new Customer(customerId, "客户" + customerId, customerId + "@example.com", Customer.CustomerType.NORMAL);
            customers.put(customerId, customer);
        }
        return customer;
    }
}


