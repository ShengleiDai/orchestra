package io.orchestra.example.application.procedure;

import io.orchestra.core.Composer;
import io.orchestra.core.Procedure;
import io.orchestra.core.Procedurable;
import io.orchestra.example.api.dto.OrderRequest;
import io.orchestra.example.api.dto.OrderResponse;
import io.orchestra.example.context.OrderContext;
import io.orchestra.spring.boot.annotation.OrchestraProcedure;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 普通客户订单处理子流程。
 * 
 * <p>针对普通客户的标准处理流程。</p>
 */
@OrchestraProcedure
public class NormalOrderProcedure implements Procedure<OrderRequest, OrderResponse, OrderContext> {
    
    private static final Logger logger = LoggerFactory.getLogger(NormalOrderProcedure.class);
    
    @Override
    public Procedurable<OrderContext> execute(OrderContext context, Composer composer) {
        return composer.just(context)
            .sync(ctx -> {
                logger.info("普通客户订单处理: orderId={}, customerId={}", 
                    ctx.getOrder().getOrderId(), ctx.getCustomer().getCustomerId());
                ctx.setAttribute("orderType", "NORMAL");
                // 普通客户标准处理逻辑
            });
    }
}


