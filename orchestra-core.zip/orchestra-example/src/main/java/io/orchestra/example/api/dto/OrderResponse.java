package io.orchestra.example.api.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 订单创建响应 DTO。
 */
public class OrderResponse {
    
    private String orderId;
    private String status;
    private BigDecimal totalAmount;
    private String message;
    private LocalDateTime createTime;
    
    public OrderResponse() {}
    
    public OrderResponse(String orderId, String status, BigDecimal totalAmount, String message) {
        this.orderId = orderId;
        this.status = status;
        this.totalAmount = totalAmount;
        this.message = message;
        this.createTime = LocalDateTime.now();
    }
    
    // Getters and Setters
    public String getOrderId() {
        return orderId;
    }
    
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public BigDecimal getTotalAmount() {
        return totalAmount;
    }
    
    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public LocalDateTime getCreateTime() {
        return createTime;
    }
    
    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }
}


