package io.orchestra.example.domain.event;

import io.orchestra.core.eventbus.BaseEvent;

/**
 * 支付完成事件。
 */
public class PaymentCompletedEvent extends BaseEvent {
    
    private String paymentId;
    private String orderId;
    private boolean success;
    private String reason;
    
    public PaymentCompletedEvent() {}
    
    public PaymentCompletedEvent(String paymentId, String orderId, boolean success) {
        this.paymentId = paymentId;
        this.orderId = orderId;
        this.success = success;
    }
    
    public PaymentCompletedEvent(String paymentId, String orderId, boolean success, String reason) {
        this.paymentId = paymentId;
        this.orderId = orderId;
        this.success = success;
        this.reason = reason;
    }
    
    // Getters and Setters
    public String getPaymentId() {
        return paymentId;
    }
    
    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }
    
    public String getOrderId() {
        return orderId;
    }
    
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    
    public boolean isSuccess() {
        return success;
    }
    
    public void setSuccess(boolean success) {
        this.success = success;
    }
    
    public String getReason() {
        return reason;
    }
    
    public void setReason(String reason) {
        this.reason = reason;
    }
}


