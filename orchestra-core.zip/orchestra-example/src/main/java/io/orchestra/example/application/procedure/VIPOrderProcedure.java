package io.orchestra.example.application.procedure;

import io.orchestra.core.Composer;
import io.orchestra.core.Procedure;
import io.orchestra.core.Procedurable;
import io.orchestra.example.api.dto.OrderRequest;
import io.orchestra.example.api.dto.OrderResponse;
import io.orchestra.example.context.OrderContext;
import io.orchestra.example.domain.service.NotificationService;
import io.orchestra.spring.boot.annotation.OrchestraProcedure;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.concurrent.CompletableFuture;

/**
 * VIP 客户订单处理子流程。
 * 
 * <p>针对 VIP 客户的特殊处理流程。</p>
 */
@OrchestraProcedure
public class VIPOrderProcedure implements Procedure<OrderRequest, OrderResponse, OrderContext> {
    
    private static final Logger logger = LoggerFactory.getLogger(VIPOrderProcedure.class);
    
    @Autowired
    private NotificationService notificationService;
    
    @Override
    public Procedurable<OrderContext> execute(OrderContext context, Composer composer) {
        return composer.just(context)
            .sync(ctx -> {
                logger.info("VIP 客户订单特殊处理: orderId={}, customerId={}", 
                    ctx.getOrder().getOrderId(), ctx.getCustomer().getCustomerId());
                ctx.setAttribute("orderType", "VIP");
                // VIP 客户特殊处理逻辑
                // 例如：优先处理、特殊折扣等
            })
            .async(ctx -> {
                // VIP 客户特殊通知
                return notificationService.sendOrderConfirmation(ctx.getCustomer(), ctx.getOrder())
                    .thenRun(() -> {
                        logger.info("VIP 客户订单确认通知已发送: orderId={}", ctx.getOrder().getOrderId());
                    });
            });
    }
}


