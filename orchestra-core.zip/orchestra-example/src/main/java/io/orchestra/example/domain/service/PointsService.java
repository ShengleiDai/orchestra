package io.orchestra.example.domain.service;

import io.orchestra.example.domain.model.Order;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.concurrent.CompletableFuture;

/**
 * 积分服务。
 * 
 * <p>模拟积分管理服务。</p>
 */
@Service
public class PointsService {
    
    /**
     * 更新用户积分（异步）。
     */
    public CompletableFuture<Void> updateUserPoints(String customerId, Order order) {
        return CompletableFuture.runAsync(() -> {
            // 模拟积分更新延迟
            try {
                Thread.sleep(40);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            // 计算积分：订单金额的 1%
            BigDecimal points = order.getTotalAmount().multiply(new BigDecimal("0.01"));
            // 实际场景中，这里会更新用户积分
            // System.out.println("更新用户积分: " + customerId + ", 积分: " + points.intValue());
        });
    }
}


