package io.orchestra.example.domain.service;

import io.orchestra.example.domain.model.Order;
import io.orchestra.example.domain.model.Shipping;
import org.springframework.stereotype.Service;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * 物流服务。
 * 
 * <p>模拟物流管理服务。</p>
 */
@Service
public class ShippingService {
    
    /**
     * 准备发货（异步）。
     */
    public CompletableFuture<Shipping> prepareShipping(Order order, String address) {
        return CompletableFuture.supplyAsync(() -> {
            // 模拟发货准备延迟
            try {
                Thread.sleep(80);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            Shipping shipping = new Shipping();
            shipping.setShippingId("SHIP-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
            shipping.setOrderId(order.getOrderId());
            shipping.setCarrier("顺丰快递");
            shipping.setAddress(address);
            shipping.setStatus(Shipping.ShippingStatus.PENDING);
            
            return shipping;
        });
    }
    
    /**
     * 安排发货。
     */
    public void arrangeShipping(Order order, Shipping shipping) {
        // 安排发货逻辑
        shipping.setTrackingNumber("SF" + UUID.randomUUID().toString().substring(0, 12).toUpperCase());
        shipping.setStatus(Shipping.ShippingStatus.SHIPPED);
    }
}


