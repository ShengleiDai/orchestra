package io.orchestra.example.application.procedure;

import io.orchestra.core.Composer;
import io.orchestra.core.Procedure;
import io.orchestra.core.Procedurable;
import io.orchestra.example.api.dto.OrderRequest;
import io.orchestra.example.api.dto.OrderResponse;
import io.orchestra.example.context.OrderContext;
import io.orchestra.spring.boot.annotation.OrchestraProcedure;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 企业客户订单处理子流程。
 * 
 * <p>针对企业客户的特殊处理流程。</p>
 */
@OrchestraProcedure
public class EnterpriseOrderProcedure implements Procedure<OrderRequest, OrderResponse, OrderContext> {
    
    private static final Logger logger = LoggerFactory.getLogger(EnterpriseOrderProcedure.class);
    
    @Override
    public Procedurable<OrderContext> execute(OrderContext context, Composer composer) {
        return composer.just(context)
            .sync(ctx -> {
                logger.info("企业客户订单处理: orderId={}, customerId={}", 
                    ctx.getOrder().getOrderId(), ctx.getCustomer().getCustomerId());
                ctx.setAttribute("orderType", "ENTERPRISE");
                // 企业客户特殊处理逻辑
                // 例如：批量折扣、特殊账期等
            });
    }
}


