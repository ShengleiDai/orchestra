package io.orchestra.example.application.procedure;

import io.orchestra.core.Composer;
import io.orchestra.core.Procedure;
import io.orchestra.core.Procedurable;
import io.orchestra.example.api.dto.OrderRequest;
import io.orchestra.example.api.dto.OrderResponse;
import io.orchestra.example.context.OrderContext;
import io.orchestra.example.domain.model.Payment;
import io.orchestra.spring.boot.annotation.OrchestraProcedure;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 支付降级处理子流程。
 * 
 * <p>当主支付流程失败时，执行降级处理。</p>
 */
@OrchestraProcedure
public class FallbackPaymentProcedure implements Procedure<OrderRequest, OrderResponse, OrderContext> {
    
    private static final Logger logger = LoggerFactory.getLogger(FallbackPaymentProcedure.class);
    
    @Override
    public Procedurable<OrderContext> execute(OrderContext context, Composer composer) {
        return composer.just(context)
            .sync(ctx -> {
                logger.warn("执行支付降级处理: orderId={}", ctx.getOrder().getOrderId());
                // 降级处理：标记为待支付，稍后重试
                if (ctx.getPayment() != null) {
                    ctx.getPayment().setStatus(Payment.PaymentStatus.PENDING);
                }
                // 实际场景中，这里可以：
                // 1. 记录到待支付队列
                // 2. 发送通知给用户
                // 3. 触发人工处理流程
            });
    }
}


