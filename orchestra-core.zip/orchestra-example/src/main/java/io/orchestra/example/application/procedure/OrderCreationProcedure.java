package io.orchestra.example.application.procedure;

import io.orchestra.core.Case;
import io.orchestra.core.Composer;
import io.orchestra.core.Procedure;
import io.orchestra.core.ProcedureCase;
import io.orchestra.core.Procedurable;
import io.orchestra.core.abtest.Variant;
import io.orchestra.core.config.BackpressureStrategy;
import io.orchestra.example.api.dto.OrderRequest;
import io.orchestra.example.api.dto.OrderResponse;
import io.orchestra.example.context.OrderContext;
import io.orchestra.example.domain.event.OrderCreatedEvent;
import io.orchestra.example.domain.event.PaymentCompletedEvent;
import io.orchestra.example.domain.event.OrderShippedEvent;
import io.orchestra.example.domain.model.Customer;
import io.orchestra.example.domain.model.Order;
import io.orchestra.example.domain.service.CustomerService;
import io.orchestra.example.domain.service.InventoryService;
import io.orchestra.example.domain.service.NotificationService;
import io.orchestra.example.domain.service.OrderDomainService;
import io.orchestra.example.domain.service.PaymentService;
import io.orchestra.example.domain.service.PointsService;
import io.orchestra.example.domain.service.ShippingService;
import io.orchestra.spring.boot.annotation.OrchestraProcedure;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.Arrays;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * 订单创建业务流程。
 *
 * <p>这是一个完整的订单处理流程示例，展示了 Orchestra 框架的所有核心特性：</p>
 * <ul>
 *   <li>同步和异步执行</li>
 *   <li>并行执行</li>
 *   <li>条件分支（branch）</li>
 *   <li>多分支选择（select）</li>
 *   <li>A/B 测试</li>
 *   <li>Saga 模式（分布式事务）</li>
 *   <li>事件总线（发布和订阅）</li>
 *   <li>错误处理（重试、降级、超时）</li>
 *   <li>性能控制（熔断器、隔离舱、限流器、背压）</li>
 *   <li><b>Procedure 组合</b>：使用子 Procedure 实现模块化和复用</li>
 * </ul>
 */
@OrchestraProcedure
public class OrderCreationProcedure implements Procedure<OrderRequest, OrderResponse, OrderContext> {

  private static final Logger logger = LoggerFactory.getLogger(OrderCreationProcedure.class);

  @Autowired
  private OrderDomainService orderDomainService;

  @Autowired
  private CustomerService customerService;

  @Autowired
  private PaymentService paymentService;

  @Autowired
  private InventoryService inventoryService;

  @Autowired
  private ShippingService shippingService;

  @Autowired
  private NotificationService notificationService;

  @Autowired
  private PointsService pointsService;
  
  @Autowired
  private PaymentProcedure paymentProcedure;
  
  @Autowired
  private ShippingProcedure shippingProcedure;
  
  @Autowired
  private VIPOrderProcedure vipOrderProcedure;
  
  @Autowired
  private NormalOrderProcedure normalOrderProcedure;
  
  @Autowired
  private FallbackPaymentProcedure fallbackPaymentProcedure;
  
  @Autowired
  private EnterpriseOrderProcedure enterpriseOrderProcedure;

  @Override
  public Procedurable<OrderContext> execute(OrderContext context, Composer composer) {
    return composer.just(context)
        // ========== 1. 初始化阶段 ==========
        .sync(this::loadCustomer)
        .sync(this::createOrder)
        .sync(this::validateOrder)
        .onError(IllegalArgumentException.class, ctx -> {
          logger.error("订单验证失败");
        })

        // ========== 2. A/B 测试：库存预留策略 ==========
        .abTest(
            "inventory-reservation-v2",
            ctx -> ctx.getCustomer().getCustomerId(),
            Arrays.asList(
                new Variant("V2", 0.3),  // 30% 流量使用新策略
                new Variant("V1", 0.7)   // 70% 流量使用旧策略
            ),
            (variant, branch) -> {
              if ("V2".equals(variant)) {
                return branch.async(ctx -> inventoryService.reserveInventoryV2(ctx.getOrder()));
              } else {
                return branch.async(ctx -> inventoryService.reserveInventory(ctx.getOrder()));
              }
            }
        )

        // ========== 3. Saga 模式：分布式事务管理 ==========
        .sagaStart()
        .async(ctx -> {
          OrderContext orderCtx = (OrderContext) ctx;
          return inventoryService.reserveInventory(orderCtx.getOrder());
        })
        .withCompensation(ctx -> {
          OrderContext orderCtx = (OrderContext) ctx;
          inventoryService.releaseInventory(orderCtx.getOrder());
          return null;
        })
        .onErrorRetry(RuntimeException.class, 2)

        // ========== 4. 条件分支：根据订单金额选择处理方式 ==========
        .branch(
            ctx -> ctx.getOrderAmount().compareTo(new BigDecimal("1000")) > 0,
            // 大额订单：需要额外验证
            branch -> branch
                .sync(ctx -> {
                  logger.info("大额订单，执行额外验证: {}", ctx.getOrder().getOrderId());
                  ctx.setAttribute("largeOrder", true);
                }),
            // 普通订单：正常处理
            branch -> branch
                .sync(ctx -> {
                  logger.info("普通订单处理: {}", ctx.getOrder().getOrderId());
                  ctx.setAttribute("largeOrder", false);
                })
        )

            // ========== 5. 多分支选择：根据客户类型选择处理流程（使用 Procedure） ==========
            .select(
                ctx -> ctx.getCustomer().getType().name(),
                ProcedureCase.of("VIP", vipOrderProcedure),
                ProcedureCase.of("ENTERPRISE", enterpriseOrderProcedure),
                ProcedureCase.defaultCase(normalOrderProcedure)
            )

            // ========== 6. 支付处理（使用子 Procedure，带性能控制和错误降级） ==========
            .sync(paymentProcedure)
                .withCircuitBreaker("payment-service", 
                    io.orchestra.core.config.CircuitBreakerConfig.custom()
                        .failureRateThreshold(0.5f)
                        .slidingWindowSize(10)
                        .waitDurationInOpenState(5000L)
                        .build())
                .withBulkhead("payment-pool", 10)
                .withRateLimiter("payment-api",
                    io.orchestra.core.config.RateLimiterConfig.custom()
                        .limitForPeriod(100)
                        .limitRefreshPeriod(Duration.ofSeconds(1))
                        .timeoutDuration(Duration.ofMillis(100))
                        .build())
                .onBackpressure(BackpressureStrategy.BUFFER)
                .onErrorResume(Exception.class, fallbackPaymentProcedure)

        // ========== 7. 状态机：管理支付状态流转（可选，用于复杂状态管理） ==========
        // 注意：在实际场景中，如果状态转换逻辑简单，可以直接在业务方法中处理
        // 这里为了演示状态机功能，我们简化处理

        // ========== 8. 事件发布：订单创建事件 ==========
        .publish(ctx -> new OrderCreatedEvent(
            ctx.getOrder().getOrderId(),
            ctx.getCustomer().getCustomerId(),
            ctx.getOrder().getTotalAmount()
        ))

            // ========== 9. 并行执行：多个独立操作（混合使用 Procedure 和 Function，提高效率） ==========
            // 注意：parallel 方法不能混用 Procedure 和 Function，这里使用 Function 方式
            .parallel(
                // 并行分支 1：发货流程（使用子 Procedure）
                stream -> stream.sync(shippingProcedure),
                
                // 并行分支 2：发送订单确认通知
                stream -> stream
                    .async(ctx -> notificationService.sendOrderConfirmation(ctx.getCustomer(), ctx.getOrder()))
                        .withRateLimiter("notification-api",
                            io.orchestra.core.config.RateLimiterConfig.custom()
                                .limitForPeriod(200)
                                .limitRefreshPeriod(Duration.ofSeconds(1))
                                .build()),
                
                // 并行分支 3：更新用户积分
                stream -> stream
                    .async(ctx -> pointsService.updateUserPoints(ctx.getCustomer().getCustomerId(), ctx.getOrder()))
                        .onError(Exception.class, ctx -> {
                            // 积分更新失败不影响主流程
                            logger.warn("积分更新失败，但不影响订单处理: {}", ctx.getOrder().getOrderId());
                        })
            )
        .publish(ctx -> {
          if (ctx.getShipping() != null) {
            return new OrderShippedEvent(
                ctx.getOrder().getOrderId(),
                ctx.getShipping().getShippingId(),
                ctx.getShipping().getTrackingNumber()
            );
          }
          return new OrderShippedEvent(ctx.getOrder().getOrderId(), null, null);
        })

            // ========== 10. 完成订单（Saga 补偿） ==========
            .sync(this::confirmPayment)
                .withCompensation(ctx -> {
                    OrderContext orderCtx = (OrderContext) ctx;
                    if (orderCtx.getPayment() != null) {
                        paymentService.refundPayment(orderCtx.getPayment().getPaymentId());
                    }
                    return null;
                })
            .sync(this::finalizeOrder)

            // ========== 11. 结束 Saga 事务（如果所有步骤成功，不执行补偿） ==========
        .sagaEnd();
  }

  // ========== 业务方法实现 ==========

  private void loadCustomer(OrderContext ctx) {
    Customer customer = customerService.getCustomer(ctx.getRequest().getCustomerId());
    ctx.setCustomer(customer);
    logger.info("加载客户信息: {}", customer.getCustomerId());
  }

  private void createOrder(OrderContext ctx) {
    Order order = orderDomainService.createOrder(ctx.getRequest());
    ctx.setOrder(order);
    ctx.setAttribute("orderId", order.getOrderId());
    logger.info("创建订单: {}", order.getOrderId());
  }

  private void validateOrder(OrderContext ctx) {
    orderDomainService.validateOrder(ctx.getOrder());
    logger.info("验证订单: {}", ctx.getOrder().getOrderId());
  }

  private void confirmPayment(OrderContext ctx) {
    String paymentId = (String) ctx.getAttribute("paymentId");
    if (paymentId != null) {
      paymentService.confirmPayment(paymentId);
      logger.info("确认支付: {}", paymentId);
    }
  }

  private void finalizeOrder(OrderContext ctx) {
    orderDomainService.finalizeOrder(ctx.getOrder());

    // 构建响应
    OrderResponse response = new OrderResponse();
    response.setOrderId(ctx.getOrder().getOrderId());
    response.setStatus(ctx.getOrder().getStatus().name());
    response.setTotalAmount(ctx.getOrder().getTotalAmount());
    response.setMessage("订单处理完成");
    ctx.setResponse(response);

    logger.info("完成订单: {}", ctx.getOrder().getOrderId());
  }
}

