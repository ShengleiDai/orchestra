package io.orchestra.example.domain.model;

/**
 * 客户领域模型。
 */
public class Customer {
    
    private String customerId;
    private String name;
    private String email;
    private CustomerType type;
    private boolean vip;
    
    public Customer() {}
    
    public Customer(String customerId, String name, String email, CustomerType type) {
        this.customerId = customerId;
        this.name = name;
        this.email = email;
        this.type = type;
        this.vip = type == CustomerType.VIP;
    }
    
    // Getters and Setters
    public String getCustomerId() {
        return customerId;
    }
    
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public CustomerType getType() {
        return type;
    }
    
    public void setType(CustomerType type) {
        this.type = type;
        this.vip = type == CustomerType.VIP;
    }
    
    public boolean isVip() {
        return vip;
    }
    
    public void setVip(boolean vip) {
        this.vip = vip;
    }
    
    /**
     * 客户类型枚举。
     */
    public enum CustomerType {
        NORMAL,  // 普通客户
        VIP,     // VIP 客户
        ENTERPRISE // 企业客户
    }
}


