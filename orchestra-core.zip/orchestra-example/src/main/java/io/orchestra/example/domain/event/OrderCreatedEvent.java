package io.orchestra.example.domain.event;

import io.orchestra.core.eventbus.BaseEvent;

/**
 * 订单创建事件。
 */
public class OrderCreatedEvent extends BaseEvent {
    
    private String orderId;
    private String customerId;
    private java.math.BigDecimal amount;
    
    public OrderCreatedEvent() {}
    
    public OrderCreatedEvent(String orderId, String customerId, java.math.BigDecimal amount) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.amount = amount;
    }
    
    // Getters and Setters
    public String getOrderId() {
        return orderId;
    }
    
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
    
    public String getCustomerId() {
        return customerId;
    }
    
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
    
    public java.math.BigDecimal getAmount() {
        return amount;
    }
    
    public void setAmount(java.math.BigDecimal amount) {
        this.amount = amount;
    }
}


