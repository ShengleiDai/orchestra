# Orchestra 最佳实践示例项目

## 项目简介

`orchestra-example` 是一个基于 Orchestra 框架的完整示例项目，展示了如何在实际业务场景中使用 Orchestra 框架的所有核心特性。本项目以**电商订单处理系统**为业务场景，实现了订单从创建到完成的全生命周期处理流程。

## 项目特性

本示例项目完整展示了 Orchestra 框架的以下核心特性：

- ✅ **同步和异步执行**：展示如何混合使用同步和异步操作
- ✅ **并行执行**：多个独立操作并行执行，提高效率
- ✅ **条件分支（branch）**：根据业务条件选择不同的处理路径
- ✅ **多分支选择（select）**：基于值匹配选择分支，类似于 switch-case
- ✅ **A/B 测试**：新功能的灰度发布和效果验证
- ✅ **Saga 模式**：分布式事务管理，支持补偿操作
- ✅ **事件总线**：发布和订阅事件，实现业务流程解耦
- ✅ **错误处理**：重试、降级、超时等错误处理机制
- ✅ **性能控制**：熔断器、隔离舱、限流器、背压等性能控制机制

## 快速开始

### 1. 构建项目

```bash
cd orchestra-example
mvn clean install
```

### 2. 运行应用

```bash
mvn spring-boot:run
```

或者：

```bash
java -jar target/orchestra-example-1.0-SNAPSHOT.jar
```

### 3. 测试 API

#### 创建订单

```bash
curl -X POST http://localhost:8080/api/orders \
  -H "Content-Type: application/json" \
  -d '{
    "customerId": "C001",
    "items": [
      {
        "productId": "P001",
        "productName": "商品1",
        "quantity": 2,
        "unitPrice": 100.00
      }
    ],
    "shippingAddress": "北京市朝阳区xxx",
    "paymentMethod": "ALIPAY"
  }'
```

#### 异步创建订单

```bash
curl -X POST http://localhost:8080/api/orders/async \
  -H "Content-Type: application/json" \
  -d '{
    "customerId": "C002",
    "items": [
      {
        "productId": "P002",
        "productName": "商品2",
        "quantity": 1,
        "unitPrice": 500.00
      }
    ],
    "shippingAddress": "上海市浦东新区xxx",
    "paymentMethod": "WECHAT"
  }'
```

## 项目结构

```
orchestra-example/
├── src/main/java/io/orchestra/example/
│   ├── api/                          # 接口层
│   │   ├── controller/               # REST 控制器
│   │   └── dto/                      # 数据传输对象
│   ├── application/                  # 应用层
│   │   ├── procedure/                # 业务流程定义
│   │   └── service/                  # 应用服务
│   ├── context/                      # 运行时上下文
│   ├── domain/                       # 领域层
│   │   ├── event/                    # 领域事件
│   │   ├── model/                    # 领域模型
│   │   └── service/                  # 领域服务
│   ├── config/                       # 配置类
│   └── Application.java              # 应用主类
└── src/main/resources/
    └── application.yml               # 配置文件
```

## 核心业务流程

订单处理流程包括以下主要步骤：

1. **订单创建**：根据客户请求创建订单
2. **订单验证**：验证订单信息的合法性
3. **库存预留**：预留商品库存（支持 A/B 测试）
4. **支付处理**：处理订单支付（带性能控制）
5. **发货准备**：准备订单发货
6. **通知发送**：发送订单确认通知
7. **积分更新**：更新用户积分
8. **订单完成**：完成订单处理

## 文档

详细的最佳实践说明请参考：[最佳实践案例说明.md](./最佳实践案例说明.md)

## 技术栈

- **Java 8**
- **Spring Boot 2.7.18**
- **Orchestra Core 1.0-SNAPSHOT**
- **Orchestra Spring Boot Starter 1.0-SNAPSHOT**

## 许可证

本项目遵循 Orchestra 框架的许可证。


