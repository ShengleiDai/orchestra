package io.orchestra.core.statemachine;

import io.orchestra.core.RuntimeContext;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Predicate;

/**
 * 状态机构建器。
 * 
 * @param <State> 状态类型
 * @param <Event> 事件类型
 * @param <T> 运行时上下文类型
 * @author Orchestra Team
 * @since 2.0.0
 */
public class StateMachineBuilder<State, Event, T extends RuntimeContext<?, ?>> {
    
    private State initialState;
    private final List<StateTransitionRule<State, Event, T>> transitionRules = new ArrayList<>();
    private final Set<State> terminalStates = new HashSet<>();
    private BiConsumer<T, Event> globalAction;
    private StatePersistence<State, Event> persistence;
    private String instanceId;
    
    /**
     * 设置初始状态。
     */
    public StateMachineBuilder<State, Event, T> initial(State state) {
        if (state == null) {
            throw new NullPointerException("Initial state cannot be null");
        }
        this.initialState = state;
        return this;
    }
    
    /**
     * 添加状态转换规则。
     */
    public StateMachineBuilder<State, Event, T> transition(State from, Class<? extends Event> eventType, State to) {
        transitionRules.add(new StateTransitionRule<>(from, eventType, to));
        return this;
    }
    
    /**
     * 添加带条件的状态转换规则。
     */
    public StateMachineBuilder<State, Event, T> transition(State from, Class<? extends Event> eventType, State to, Predicate<T> condition) {
        StateTransitionRule<State, Event, T> rule = new StateTransitionRule<>(from, eventType, to);
        rule.setCondition(condition);
        transitionRules.add(rule);
        return this;
    }
    
    /**
     * 设置状态转换时的全局动作。
     */
    public StateMachineBuilder<State, Event, T> onTransition(BiConsumer<T, Event> action) {
        this.globalAction = action;
        return this;
    }
    
    /**
     * 设置终止状态。
     */
    public StateMachineBuilder<State, Event, T> terminateOn(State... states) {
        if (states != null && states.length > 0) {
            terminalStates.addAll(Arrays.asList(states));
        }
        return this;
    }
    
    /**
     * 设置状态持久化。
     */
    public StateMachineBuilder<State, Event, T> withPersistence(StatePersistence<State, Event> persistence) {
        this.persistence = persistence;
        return this;
    }
    
    /**
     * 设置状态机实例 ID。
     */
    public StateMachineBuilder<State, Event, T> withInstanceId(String instanceId) {
        this.instanceId = instanceId;
        return this;
    }
    
    /**
     * 构建状态机。
     */
    public StateMachine<State, Event, T> build() {
        if (initialState == null) {
            throw new IllegalStateException("Initial state must be set");
        }
        if (transitionRules.isEmpty()) {
            throw new IllegalStateException("At least one transition rule must be defined");
        }
        
        // 如果没有指定持久化，使用内存持久化
        if (persistence == null) {
            persistence = new InMemoryStatePersistence<>();
        }
        
        return new DefaultStateMachine<>(initialState, transitionRules, terminalStates, 
                                        globalAction, persistence, instanceId);
    }
    
    // Getters for internal use
    State getInitialState() {
        return initialState;
    }
    
    List<StateTransitionRule<State, Event, T>> getTransitionRules() {
        return transitionRules;
    }
    
    Set<State> getTerminalStates() {
        return terminalStates;
    }
    
    BiConsumer<T, Event> getGlobalAction() {
        return globalAction;
    }
    
    StatePersistence<State, Event> getPersistence() {
        return persistence;
    }
    
    String getInstanceId() {
        return instanceId;
    }
}

