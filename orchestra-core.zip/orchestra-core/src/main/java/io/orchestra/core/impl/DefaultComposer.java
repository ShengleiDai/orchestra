package io.orchestra.core.impl;

import io.orchestra.core.Composer;
import io.orchestra.core.ProcedureManager;
import io.orchestra.core.RuntimeContext;

import java.util.Objects;

/**
 * Composer 接口的默认实现。
 * 
 * <p>DefaultComposer 负责创建 ProcedureManager 实例，是流程 DSL 的入口点。</p>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
public class DefaultComposer implements Composer {
    
    /**
     * 从给定的运行时上下文开始构建流程。
     * 
     * @param <T> 运行时上下文类型
     * @param <R> 请求类型
     * @param <S> 响应类型
     * @param context 运行时上下文，不能为 null
     * @return ProcedureManager 实例
     * @throws NullPointerException 如果 context 为 null
     */
    @Override
    public <T extends RuntimeContext<R, S>, R, S> ProcedureManager<T> just(T context) {
        Objects.requireNonNull(context, "Context cannot be null");
        return new DefaultProcedureManager<>(context, this);
    }
}

