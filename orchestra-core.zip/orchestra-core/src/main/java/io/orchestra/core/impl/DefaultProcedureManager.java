package io.orchestra.core.impl;

import io.orchestra.core.Case;
import io.orchestra.core.Composer;
import io.orchestra.core.Procedure;
import io.orchestra.core.ProcedureCase;
import io.orchestra.core.Procedurable;
import io.orchestra.core.ProcedureManager;
import io.orchestra.core.RuntimeContext;
import io.orchestra.core.StateMachineManager;
import io.orchestra.core.abtest.Variant;
import io.orchestra.core.config.BackpressureStrategy;
import io.orchestra.core.config.CircuitBreakerConfig;
import io.orchestra.core.config.RateLimiterConfig;
import io.orchestra.core.eventbus.Event;
import io.orchestra.core.statemachine.StateMachine;
import io.orchestra.core.statemachine.StateMachineBuilder;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * ProcedureManager 接口的默认实现。
 * 
 * <p>DefaultProcedureManager 是流程 DSL 的核心实现类，持有运行时上下文，
 * 并提供链式调用的基础框架。实现了同步、异步、并行、分支等 DSL 方法。</p>
 * 
 * @param <T> 运行时上下文类型
 * @author Orchestra Team
 * @since 1.0.0
 */
public class DefaultProcedureManager<T extends RuntimeContext<?, ?>> implements ProcedureManager<T> {
    
    private final T context;
    private final List<ProcedureStep<T>> steps;
    private final Composer composer;
    
    /**
     * 构造一个 DefaultProcedureManager 实例。
     * 
     * @param context 运行时上下文，不能为 null
     * @param composer 流程编织器，用于执行子 Procedure
     */
    DefaultProcedureManager(T context, Composer composer) {
        if (context == null) {
            throw new NullPointerException("Context cannot be null");
        }
        if (composer == null) {
            throw new NullPointerException("Composer cannot be null");
        }
        this.context = context;
        this.composer = composer;
        this.steps = new ArrayList<>();
    }
    
    /**
     * 创建子流程管理器（内部使用，用于分支和并行）。
     * 
     * @return 新的 ProcedureManager 实例
     */
    ProcedureManager<T> createSubManager() {
        return new DefaultProcedureManager<>(context, composer);
    }
    
    /**
     * 获取 Composer 实例（内部使用）。
     * 
     * @return Composer 实例
     */
    Composer getComposer() {
        return composer;
    }
    
    /**
     * 获取运行时上下文。
     * 
     * @return 运行时上下文
     */
    public T getContext() {
        return context;
    }
    
    /**
     * 获取流程步骤列表（内部使用）。
     * 
     * @return 步骤列表
     */
    public List<ProcedureStep<T>> getSteps() {
        return steps;
    }
    
    
    @Override
    public ProcedureManager<T> sync(Consumer<T> consumer) {
        if (consumer == null) {
            throw new NullPointerException("Consumer cannot be null");
        }
        steps.add(ProcedureStep.syncConsumer(consumer));
        return this;
    }
    
    @Override
    public ProcedureManager<T> sync(Function<T, ?> function) {
        if (function == null) {
            throw new NullPointerException("Function cannot be null");
        }
        steps.add(ProcedureStep.syncFunction(function));
        return this;
    }
    
    @Override
    public ProcedureManager<T> async(Supplier<?> supplier) {
        if (supplier == null) {
            throw new NullPointerException("Supplier cannot be null");
        }
        steps.add(ProcedureStep.asyncSupplier(supplier));
        return this;
    }
    
    @Override
    public ProcedureManager<T> async(Function<T, CompletableFuture<?>> function) {
        if (function == null) {
            throw new NullPointerException("Function cannot be null");
        }
        steps.add(ProcedureStep.asyncFunction(function));
        return this;
    }
    
    @Override
    public ProcedureManager<T> sync(Procedure<?, ?, T> procedure) {
        if (procedure == null) {
            throw new NullPointerException("Procedure cannot be null");
        }
        steps.add(ProcedureStep.syncProcedure(procedure));
        return this;
    }
    
    @Override
    public ProcedureManager<T> async(Procedure<?, ?, T> procedure) {
        if (procedure == null) {
            throw new NullPointerException("Procedure cannot be null");
        }
        steps.add(ProcedureStep.asyncProcedure(procedure));
        return this;
    }
    
    @Override
    @SafeVarargs
    public final ProcedureManager<T> parallel(final Function<ProcedureManager<T>, Procedurable<T>>... streamBuilders) {
        if (streamBuilders == null || streamBuilders.length == 0) {
            throw new IllegalArgumentException("Stream builders cannot be null or empty");
        }
        steps.add(ProcedureStep.parallel(Arrays.asList(streamBuilders)));
        return this;
    }
    
    @Override
    @SafeVarargs
    public final ProcedureManager<T> parallel(Procedure<?, ?, T>... procedures) {
        if (procedures == null || procedures.length == 0) {
            throw new IllegalArgumentException("Procedures cannot be null or empty");
        }
        List<Procedure<?, ?, T>> procedureList = Arrays.asList(procedures);
        steps.add(ProcedureStep.parallelProcedure(procedureList));
        return this;
    }
    
    @Override
    public ProcedureManager<T> branch(
            Predicate<T> condition,
            Function<ProcedureManager<T>, Procedurable<T>> trueBranch,
            Function<ProcedureManager<T>, Procedurable<T>> falseBranch) {
        if (condition == null) {
            throw new NullPointerException("Condition cannot be null");
        }
        if (trueBranch == null || falseBranch == null) {
            throw new NullPointerException("Branch handlers cannot be null");
        }
        steps.add(ProcedureStep.branch(condition, trueBranch, falseBranch));
        return this;
    }
    
    @Override
    public ProcedureManager<T> branch(
            Predicate<T> condition,
            Function<ProcedureManager<T>, Procedurable<T>> branch) {
        if (condition == null) {
            throw new NullPointerException("Condition cannot be null");
        }
        if (branch == null) {
            throw new NullPointerException("Branch handler cannot be null");
        }
        steps.add(ProcedureStep.branchSingle(condition, branch));
        return this;
    }
    
    @Override
    public ProcedureManager<T> branch(
            Predicate<T> condition,
            Procedure<?, ?, T> trueProcedure,
            Procedure<?, ?, T> falseProcedure) {
        if (condition == null) {
            throw new NullPointerException("Condition cannot be null");
        }
        if (trueProcedure == null) {
            throw new NullPointerException("True procedure cannot be null");
        }
        if (falseProcedure == null) {
            throw new NullPointerException("False procedure cannot be null");
        }
        steps.add(ProcedureStep.branchProcedure(condition, trueProcedure, falseProcedure));
        return this;
    }
    
    @Override
    public ProcedureManager<T> branch(
            Predicate<T> condition,
            Procedure<?, ?, T> procedure) {
        if (condition == null) {
            throw new NullPointerException("Condition cannot be null");
        }
        if (procedure == null) {
            throw new NullPointerException("Procedure cannot be null");
        }
        steps.add(ProcedureStep.branchProcedureSingle(condition, procedure));
        return this;
    }
    
    @Override
    @SafeVarargs
    public final <V> ProcedureManager<T> select(
            Function<T, V> valueExtractor,
            Case<V, T>... cases) {
        if (valueExtractor == null) {
            throw new NullPointerException("Value extractor cannot be null");
        }
        if (cases == null || cases.length == 0) {
            throw new IllegalArgumentException("Cases cannot be null or empty");
        }
        steps.add(ProcedureStep.select(valueExtractor, Arrays.asList(cases)));
        return this;
    }
    
    @Override
    @SafeVarargs
    public final <V> ProcedureManager<T> select(
            Function<T, V> valueExtractor,
            ProcedureCase<V, ?, ?, T>... cases) {
        if (valueExtractor == null) {
            throw new NullPointerException("Value extractor cannot be null");
        }
        if (cases == null || cases.length == 0) {
            throw new IllegalArgumentException("Cases cannot be null or empty");
        }
        List<ProcedureCase<V, ?, ?, T>> caseList = Arrays.asList(cases);
        steps.add(ProcedureStep.selectProcedure(valueExtractor, caseList));
        return this;
    }
    
    @Override
    public ProcedureManager<T> onErrorRetry(Class<? extends Throwable> errorType, int retryCount) {
        if (errorType == null) {
            throw new NullPointerException("Error type cannot be null");
        }
        if (retryCount < 0) {
            throw new IllegalArgumentException("Retry count cannot be negative");
        }
        steps.add(ProcedureStep.errorRetry(errorType, retryCount));
        return this;
    }
    
    @Override
    public ProcedureManager<T> onErrorResume(Class<? extends Throwable> errorType, Function<Throwable, Procedurable<T>> fallbackHandler) {
        if (errorType == null) {
            throw new NullPointerException("Error type cannot be null");
        }
        if (fallbackHandler == null) {
            throw new NullPointerException("Fallback handler cannot be null");
        }
        steps.add(ProcedureStep.errorResume(errorType, fallbackHandler));
        return this;
    }
    
    @Override
    public ProcedureManager<T> onErrorResume(Class<? extends Throwable> errorType, Procedure<?, ?, T> fallbackProcedure) {
        if (errorType == null) {
            throw new NullPointerException("Error type cannot be null");
        }
        if (fallbackProcedure == null) {
            throw new NullPointerException("Fallback procedure cannot be null");
        }
        steps.add(ProcedureStep.errorResumeProcedure(errorType, fallbackProcedure));
        return this;
    }
    
    @Override
    public ProcedureManager<T> onError(Class<? extends Throwable> errorType, Consumer<T> handler) {
        if (errorType == null) {
            throw new NullPointerException("Error type cannot be null");
        }
        if (handler == null) {
            throw new NullPointerException("Error handler cannot be null");
        }
        steps.add(ProcedureStep.errorHandler(errorType, handler));
        return this;
    }
    
    @Override
    public ProcedureManager<T> timeout(long timeout, TimeUnit timeUnit, Consumer<T> handler) {
        if (timeUnit == null) {
            throw new NullPointerException("Time unit cannot be null");
        }
        if (timeout < 0) {
            throw new IllegalArgumentException("Timeout cannot be negative");
        }
        if (handler == null) {
            throw new NullPointerException("Timeout handler cannot be null");
        }
        steps.add(ProcedureStep.timeout(timeout, timeUnit, handler));
        return this;
    }
    
    @Override
    public ProcedureManager<T> timeoutWithProcedure(long timeout, TimeUnit timeUnit, Procedure<?, ?, T> timeoutProcedure) {
        if (timeUnit == null) {
            throw new NullPointerException("Time unit cannot be null");
        }
        if (timeout < 0) {
            throw new IllegalArgumentException("Timeout cannot be negative");
        }
        if (timeoutProcedure == null) {
            throw new NullPointerException("Timeout procedure cannot be null");
        }
        steps.add(ProcedureStep.timeoutProcedure(timeout, timeUnit, timeoutProcedure));
        return this;
    }
    
    @Override
    public ProcedureManager<T> sagaStart() {
        steps.add(ProcedureStep.sagaStart());
        return this;
    }
    
    @Override
    public ProcedureManager<T> sagaEnd() {
        steps.add(ProcedureStep.sagaEnd());
        return this;
    }
    
    @Override
    public ProcedureManager<T> withCompensation(Function<T, ?> compensationFunction) {
        if (compensationFunction == null) {
            throw new NullPointerException("Compensation function cannot be null");
        }
        steps.add(ProcedureStep.compensation(compensationFunction));
        return this;
    }
    
    @Override
    public ProcedureManager<T> withCircuitBreaker(String name, CircuitBreakerConfig config) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Circuit breaker name cannot be null or empty");
        }
        if (config == null) {
            throw new NullPointerException("Circuit breaker config cannot be null");
        }
        steps.add(ProcedureStep.circuitBreaker(name, config));
        return this;
    }
    
    @Override
    public ProcedureManager<T> withBulkhead(String name, int maxConcurrency) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Bulkhead name cannot be null or empty");
        }
        if (maxConcurrency <= 0) {
            throw new IllegalArgumentException("Max concurrency must be positive");
        }
        steps.add(ProcedureStep.bulkhead(name, maxConcurrency));
        return this;
    }
    
    @Override
    public ProcedureManager<T> withRateLimiter(String name, RateLimiterConfig config) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Rate limiter name cannot be null or empty");
        }
        if (config == null) {
            throw new NullPointerException("Rate limiter config cannot be null");
        }
        steps.add(ProcedureStep.rateLimiter(name, config));
        return this;
    }
    
    @Override
    public ProcedureManager<T> onBackpressure(BackpressureStrategy strategy) {
        if (strategy == null) {
            throw new NullPointerException("Backpressure strategy cannot be null");
        }
        steps.add(ProcedureStep.backpressure(strategy));
        return this;
    }
    
    @Override
    public <State, Event> StateMachineManager<State, Event, T> stateMachine(
            Class<State> stateType,
            Function<StateMachineBuilder<State, Event, T>, StateMachine<State, Event, T>> builder) {
        if (stateType == null) {
            throw new NullPointerException("State type cannot be null");
        }
        if (builder == null) {
            throw new NullPointerException("State machine builder cannot be null");
        }
        
        // 创建状态机
        StateMachineBuilder<State, Event, T> stateMachineBuilder = new StateMachineBuilder<>();
        stateMachineBuilder.withInstanceId(generateStateMachineInstanceId());
        StateMachine<State, Event, T> stateMachine = builder.apply(stateMachineBuilder);
        
        // 创建状态机步骤
        ProcedureStep<T> step = ProcedureStep.stateMachine(stateType, builder);
        step.setStateMachine(stateMachine);
        steps.add(step);
        
        // 返回 StateMachineManager 以便后续操作
        return new DefaultStateMachineManager<>(context, stateMachine, this);
    }
    
    /**
     * 生成状态机实例 ID。
     */
    private String generateStateMachineInstanceId() {
        return "sm-" + System.currentTimeMillis() + "-" + 
               Integer.toHexString(hashCode());
    }
    
    @Override
    public <E extends Event> ProcedureManager<T> publish(Function<T, E> eventSupplier) {
        if (eventSupplier == null) {
            throw new NullPointerException("Event supplier cannot be null");
        }
        steps.add(ProcedureStep.publishEvent(eventSupplier));
        return this;
    }
    
    @Override
    public <E extends Event> ProcedureManager<T> onEvent(Class<E> eventType, BiConsumer<T, E> handler) {
        return onEvent(eventType, handler, Duration.ZERO);  // 0 表示无限等待
    }
    
    @Override
    public <E extends Event> ProcedureManager<T> onEvent(Class<E> eventType, BiConsumer<T, E> handler, Duration timeout) {
        if (eventType == null) {
            throw new NullPointerException("Event type cannot be null");
        }
        if (handler == null) {
            throw new NullPointerException("Event handler cannot be null");
        }
        if (timeout == null) {
            throw new NullPointerException("Timeout cannot be null");
        }
        
        long timeoutMillis = timeout.toMillis();
        steps.add(ProcedureStep.awaitEvent(eventType, handler, timeoutMillis));
        return this;
    }
    
    @Override
    public ProcedureManager<T> abTest(
            String experimentId,
            Function<T, String> userIdExtractor,
            List<Variant> variants,
            BiFunction<String, ProcedureManager<T>, Procedurable<T>> variantHandler) {
        if (experimentId == null || experimentId.trim().isEmpty()) {
            throw new IllegalArgumentException("Experiment ID cannot be null or empty");
        }
        if (userIdExtractor == null) {
            throw new NullPointerException("User ID extractor cannot be null");
        }
        if (variants == null || variants.isEmpty()) {
            throw new IllegalArgumentException("Variants cannot be null or empty");
        }
        if (variantHandler == null) {
            throw new NullPointerException("Variant handler cannot be null");
        }
        steps.add(ProcedureStep.abTest(experimentId, userIdExtractor, variants, variantHandler));
        return this;
    }
    
    @Override
    @SafeVarargs
    public final ProcedureManager<T> abTest(
            String experimentId,
            Function<T, String> userIdExtractor,
            List<Variant> variants,
            Procedure<?, ?, T>... procedures) {
        if (experimentId == null || experimentId.trim().isEmpty()) {
            throw new IllegalArgumentException("Experiment ID cannot be null or empty");
        }
        if (userIdExtractor == null) {
            throw new NullPointerException("User ID extractor cannot be null");
        }
        if (variants == null || variants.isEmpty()) {
            throw new IllegalArgumentException("Variants cannot be null or empty");
        }
        if (procedures == null || procedures.length == 0) {
            throw new IllegalArgumentException("Procedures cannot be null or empty");
        }
        if (variants.size() != procedures.length) {
            throw new IllegalArgumentException("Variants size must match procedures size");
        }
        List<Procedure<?, ?, T>> procedureList = Arrays.asList(procedures);
        steps.add(ProcedureStep.abTestProcedure(experimentId, userIdExtractor, variants, procedureList));
        return this;
    }
}

