package io.orchestra.core.eventbus;

/**
 * 事件总线异常。
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
public class EventBusException extends RuntimeException {
    
    public EventBusException(String message) {
        super(message);
    }
    
    public EventBusException(String message, Throwable cause) {
        super(message, cause);
    }
    
    public EventBusException(Throwable cause) {
        super(cause);
    }
}

