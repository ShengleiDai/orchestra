package io.orchestra.core.saga;

import io.orchestra.core.RuntimeContext;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.function.Function;

/**
 * 本地 Saga 事务管理器实现。
 * 
 * <p>默认实现，适用于单机应用。基于内存的事务管理，不支持跨进程的分布式事务。</p>
 * 
 * <p>生产环境如需跨进程的分布式事务，建议使用 Seata、TCC 等分布式事务中间件实现。</p>
 * 
 * @param <T> 运行时上下文类型
 * @author Orchestra Team
 * @since 2.0.0
 */
public class LocalSagaManager<T extends RuntimeContext<?, ?>> implements SagaManager<T> {
    
    /**
     * Saga 事务信息。
     */
    private static class SagaTransaction {
        private final String sagaId;
        private final String contextId;
        private boolean active;
        private final List<Function<RuntimeContext<?, ?>, ?>> compensations;
        
        public SagaTransaction(String sagaId, String contextId) {
            this.sagaId = sagaId;
            this.contextId = contextId;
            this.active = true;
            this.compensations = new ArrayList<>();
        }
        
        public String getSagaId() {
            return sagaId;
        }
        
        public String getContextId() {
            return contextId;
        }
        
        public boolean isActive() {
            return active;
        }
        
        public void setActive(boolean active) {
            this.active = active;
        }
        
        public List<Function<RuntimeContext<?, ?>, ?>> getCompensations() {
            return compensations;
        }
        
        public void addCompensation(Function<RuntimeContext<?, ?>, ?> compensation) {
            compensations.add(compensation);
        }
    }
    
    // Saga 事务映射：sagaId -> SagaTransaction
    private final ConcurrentMap<String, SagaTransaction> transactions = new ConcurrentHashMap<>();
    
    // 上下文到 Saga ID 的映射：contextId -> sagaId
    private final ConcurrentMap<String, String> contextToSaga = new ConcurrentHashMap<>();
    
    @Override
    public String startSaga(T context) {
        if (context == null) {
            throw new NullPointerException("Context cannot be null");
        }
        
        String contextId = getContextId(context);
        String sagaId = UUID.randomUUID().toString();
        
        SagaTransaction transaction = new SagaTransaction(sagaId, contextId);
        transactions.put(sagaId, transaction);
        contextToSaga.put(contextId, sagaId);
        
        // 将 sagaId 保存到上下文，以便后续使用
        context.setAttribute("sagaId", sagaId);
        
        return sagaId;
    }
    
    @Override
    public void endSaga(T context, String sagaId) {
        if (context == null) {
            throw new NullPointerException("Context cannot be null");
        }
        if (sagaId == null || sagaId.trim().isEmpty()) {
            throw new IllegalArgumentException("Saga ID cannot be null or empty");
        }
        
        SagaTransaction transaction = transactions.get(sagaId);
        if (transaction != null) {
            transaction.setActive(false);
            // 清除补偿操作列表（因为事务成功，不需要补偿）
            transaction.getCompensations().clear();
        }
        
        // 清理映射
        String contextId = getContextId(context);
        contextToSaga.remove(contextId);
        transactions.remove(sagaId);
        
        // 从上下文移除 sagaId
        context.setAttribute("sagaId", null);
    }
    
    @Override
    public void registerCompensation(T context, String sagaId, Function<T, ?> compensationFunction) {
        if (context == null) {
            throw new NullPointerException("Context cannot be null");
        }
        if (sagaId == null || sagaId.trim().isEmpty()) {
            throw new IllegalArgumentException("Saga ID cannot be null or empty");
        }
        if (compensationFunction == null) {
            throw new NullPointerException("Compensation function cannot be null");
        }
        
        SagaTransaction transaction = transactions.get(sagaId);
        if (transaction != null && transaction.isActive()) {
            @SuppressWarnings("unchecked")
            Function<RuntimeContext<?, ?>, ?> compensation = 
                (Function<RuntimeContext<?, ?>, ?>) (Function<?, ?>) compensationFunction;
            transaction.addCompensation(compensation);
        }
    }
    
    @Override
    public void executeCompensations(T context, String sagaId, Throwable error) {
        if (context == null) {
            throw new NullPointerException("Context cannot be null");
        }
        if (sagaId == null || sagaId.trim().isEmpty()) {
            return;  // 如果没有 sagaId，说明不在 Saga 事务中
        }
        
        SagaTransaction transaction = transactions.get(sagaId);
        if (transaction == null || !transaction.isActive()) {
            return;  // 事务不存在或已结束
        }
        
        List<Function<RuntimeContext<?, ?>, ?>> compensations = 
            new ArrayList<>(transaction.getCompensations());
        
        // 按相反顺序执行补偿操作
        Collections.reverse(compensations);
        
        for (Function<RuntimeContext<?, ?>, ?> compensation : compensations) {
            try {
                compensation.apply(context);
            } catch (Exception e) {
                // 补偿操作失败，记录但不阻止其他补偿操作执行
                // 在实际应用中，可能需要更完善的错误处理
                System.err.println("Compensation failed for saga " + sagaId + ": " + e.getMessage());
                e.printStackTrace();
            }
        }
        
        // 标记事务为不活跃
        transaction.setActive(false);
        
        // 清理映射
        String contextId = getContextId(context);
        contextToSaga.remove(contextId);
        transactions.remove(sagaId);
        
        // 从上下文移除 sagaId
        context.setAttribute("sagaId", null);
    }
    
    @Override
    public boolean isInSaga(T context, String sagaId) {
        if (context == null || sagaId == null || sagaId.trim().isEmpty()) {
            return false;
        }
        
        SagaTransaction transaction = transactions.get(sagaId);
        return transaction != null && transaction.isActive();
    }
    
    /**
     * 获取上下文的唯一标识。
     */
    private String getContextId(T context) {
        // 尝试从上下文获取 ID
        Object id = context.getAttribute("contextId");
        if (id != null) {
            return id.toString();
        }
        
        // 如果没有，使用上下文的 hashCode 和类名生成
        String contextId = context.getClass().getSimpleName() + "-" + 
                          Integer.toHexString(context.hashCode());
        context.setAttribute("contextId", contextId);
        return contextId;
    }
    
    /**
     * 根据上下文获取 Saga ID。
     */
    public String getSagaId(T context) {
        if (context == null) {
            return null;
        }
        Object sagaId = context.getAttribute("sagaId");
        return sagaId != null ? sagaId.toString() : null;
    }
    
    /**
     * 清除所有事务（主要用于测试）。
     */
    public void clear() {
        transactions.clear();
        contextToSaga.clear();
    }
}

