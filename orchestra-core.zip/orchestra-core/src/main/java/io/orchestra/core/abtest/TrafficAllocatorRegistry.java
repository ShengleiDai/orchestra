package io.orchestra.core.abtest;

/**
 * 流量分配器注册表。
 * 
 * <p>用于管理全局的 TrafficAllocator 实例，支持默认实例和自定义实例。</p>
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
public class TrafficAllocatorRegistry {
    
    private static volatile TrafficAllocator defaultAllocator;
    private static volatile TrafficAllocationPersistence defaultPersistence;
    
    static {
        // 默认使用 DefaultTrafficAllocator 和 InMemoryTrafficAllocationPersistence
        defaultAllocator = new DefaultTrafficAllocator();
        defaultPersistence = new InMemoryTrafficAllocationPersistence();
    }
    
    /**
     * 获取默认的 TrafficAllocator 实例。
     * 
     * @return 默认的 TrafficAllocator 实例
     */
    public static TrafficAllocator getDefaultAllocator() {
        return defaultAllocator;
    }
    
    /**
     * 设置默认的 TrafficAllocator 实例。
     * 
     * @param allocator TrafficAllocator 实例
     */
    public static void setDefaultAllocator(TrafficAllocator allocator) {
        if (allocator == null) {
            throw new NullPointerException("TrafficAllocator cannot be null");
        }
        synchronized (TrafficAllocatorRegistry.class) {
            defaultAllocator = allocator;
        }
    }
    
    /**
     * 获取默认的 TrafficAllocationPersistence 实例。
     * 
     * @return 默认的 TrafficAllocationPersistence 实例
     */
    public static TrafficAllocationPersistence getDefaultPersistence() {
        return defaultPersistence;
    }
    
    /**
     * 设置默认的 TrafficAllocationPersistence 实例。
     * 
     * @param persistence TrafficAllocationPersistence 实例
     */
    public static void setDefaultPersistence(TrafficAllocationPersistence persistence) {
        if (persistence == null) {
            throw new NullPointerException("TrafficAllocationPersistence cannot be null");
        }
        synchronized (TrafficAllocatorRegistry.class) {
            defaultPersistence = persistence;
        }
    }
    
    /**
     * 重置为默认实例（主要用于测试）。
     */
    public static void reset() {
        synchronized (TrafficAllocatorRegistry.class) {
            defaultAllocator = new DefaultTrafficAllocator();
            defaultPersistence = new InMemoryTrafficAllocationPersistence();
        }
    }
}

