package io.orchestra.core.performance;

import io.orchestra.core.config.CircuitBreakerConfig;
import io.orchestra.core.config.RateLimiterConfig;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * 性能控制组件注册表。
 * 
 * <p>用于管理和复用性能控制组件（熔断器、隔离舱、限流器）。</p>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
public class PerformanceControlRegistry {
    
    private static final PerformanceControlRegistry INSTANCE = new PerformanceControlRegistry();
    
    private final ConcurrentMap<String, CircuitBreaker> circuitBreakers = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, Bulkhead> bulkheads = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, RateLimiter> rateLimiters = new ConcurrentHashMap<>();
    
    private PerformanceControlRegistry() {
    }
    
    public static PerformanceControlRegistry getInstance() {
        return INSTANCE;
    }
    
    /**
     * 获取或创建熔断器。
     */
    public CircuitBreaker getOrCreateCircuitBreaker(String name, CircuitBreakerConfig config) {
        return circuitBreakers.computeIfAbsent(name, k -> new CircuitBreaker(k, config));
    }
    
    /**
     * 获取或创建隔离舱。
     */
    public Bulkhead getOrCreateBulkhead(String name, int maxConcurrency) {
        return bulkheads.computeIfAbsent(name, k -> new Bulkhead(k, maxConcurrency));
    }
    
    /**
     * 获取或创建限流器。
     */
    public RateLimiter getOrCreateRateLimiter(String name, RateLimiterConfig config) {
        return rateLimiters.computeIfAbsent(name, k -> new RateLimiter(k, config));
    }
    
    /**
     * 清除所有组件（主要用于测试）。
     */
    public void clear() {
        circuitBreakers.clear();
        bulkheads.clear();
        rateLimiters.clear();
    }
}

