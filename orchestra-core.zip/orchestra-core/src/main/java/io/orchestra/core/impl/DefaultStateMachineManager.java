package io.orchestra.core.impl;

import io.orchestra.core.RuntimeContext;
import io.orchestra.core.StateMachineManager;
import io.orchestra.core.statemachine.StateMachine;

/**
 * StateMachineManager 的默认实现。
 * 
 * @param <State> 状态类型
 * @param <Event> 事件类型
 * @param <T> 运行时上下文类型
 * @author Orchestra Team
 * @since 2.0.0
 */
public class DefaultStateMachineManager<State, Event, T extends RuntimeContext<?, ?>> 
        implements StateMachineManager<State, Event, T> {
    
    private final T context;
    private final StateMachine<State, Event, T> stateMachine;
    private final DefaultProcedureManager<T> parentManager;
    
    public DefaultStateMachineManager(
            T context,
            StateMachine<State, Event, T> stateMachine,
            DefaultProcedureManager<T> parentManager) {
        if (context == null) {
            throw new NullPointerException("Context cannot be null");
        }
        if (stateMachine == null) {
            throw new NullPointerException("State machine cannot be null");
        }
        if (parentManager == null) {
            throw new NullPointerException("Parent manager cannot be null");
        }
        this.context = context;
        this.stateMachine = stateMachine;
        this.parentManager = parentManager;
    }
    
    @Override
    public StateMachineManager<State, Event, T> trigger(Event event) {
        if (event == null) {
            throw new NullPointerException("Event cannot be null");
        }
        stateMachine.transition(context, event);
        return this;
    }
    
    @Override
    public State getCurrentState() {
        return stateMachine.getCurrentState();
    }
    
    @Override
    public StateMachine<State, Event, T> getStateMachine() {
        return stateMachine;
    }
    
    public T getContext() {
        return context;
    }
    
    public DefaultProcedureManager<T> getParentManager() {
        return parentManager;
    }
}

