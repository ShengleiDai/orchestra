package io.orchestra.core;

/**
 * 流程编织器接口，用于将多个步骤组合成一个完整的流程。
 * 
 * <p>Composer 是 Orchestra 框架的核心组件，提供了流程编排的 DSL 入口。
 * 通过 Composer，可以将业务步骤以声明式的方式组合成完整的业务流程。</p>
 * 
 * <p>Composer 的主要职责：</p>
 * <ul>
 *   <li>提供流程 DSL 的入口点（just 方法）</li>
 *   <li>创建 ProcedureManager 实例，用于链式调用</li>
 * </ul>
 * 
 * <p>使用示例：</p>
 * <pre>{@code
 * public Procedurable<OrderContext> execute(OrderContext context, Composer composer) {
 *     return composer.just(context)
 *         .sync(this::validateOrder)
 *         .async(this::processPayment);
 * }
 * }</pre>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
public interface Composer {
    
    /**
     * 从给定的运行时上下文开始构建流程。
     * 
     * <p>此方法是流程 DSL 的入口点，返回一个 ProcedureManager 实例，
     * 可以通过链式调用来定义流程步骤。</p>
     * 
     * @param <T> 运行时上下文类型，必须继承自 RuntimeContext
     * @param <R> 请求类型
     * @param <S> 响应类型
     * @param context 运行时上下文，不能为 null
     * @return ProcedureManager 实例，用于后续的链式调用
     * @throws NullPointerException 如果 context 为 null
     */
    <T extends RuntimeContext<R, S>, R, S> ProcedureManager<T> just(T context);
}

