package io.orchestra.core.eventbus;

/**
 * 事件接口。
 * 
 * <p>所有通过 EventBus 传递的事件都应该实现此接口。</p>
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
public interface Event {
    
    /**
     * 获取事件 ID。
     * 
     * @return 事件唯一标识
     */
    String getEventId();
    
    /**
     * 获取事件时间戳。
     * 
     * @return 事件发生时间（毫秒）
     */
    long getTimestamp();
}

