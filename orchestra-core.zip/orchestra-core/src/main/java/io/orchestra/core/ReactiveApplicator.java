package io.orchestra.core;

import io.orchestra.core.impl.DefaultComposer;
import io.orchestra.core.impl.DefaultProcedureManager;
import io.orchestra.core.impl.ProcedureExecutor;
import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.schedulers.Schedulers;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * 基于 RXJava 的响应式流程执行引擎。
 * 
 * <p>ReactiveApplicator 是 Orchestra 框架的核心执行引擎，负责执行和管理业务流程。
 * 它基于 RXJava 3.x 实现，天然支持异步、并发和背压处理。</p>
 * 
 * <p>主要特性：</p>
 * <ul>
 *   <li>响应式执行：基于 RXJava 的响应式编程模型</li>
 *   <li>背压处理：自动处理数据流背压，防止系统过载</li>
 *   <li>异步支持：支持异步流程执行</li>
 *   <li>监控支持：可集成自定义监控器（后续阶段实现）</li>
 * </ul>
 * 
 * <p>使用示例：</p>
 * <pre>{@code
 * ReactiveApplicator<OrderRequest, OrderResponse, OrderContext> applicator = 
 *     new ReactiveApplicator<>();
 * 
 * OrderContext context = new OrderContext(new OrderRequest("order-123"));
 * RuntimeContext<OrderRequest, OrderResponse> result = 
 *     applicator.apply(context, new OrderCreationProcedure());
 * 
 * OrderResponse response = result.getResponse();
 * }</pre>
 * 
 * @param <R> 请求类型
 * @param <S> 响应类型
 * @param <T> 运行时上下文类型，必须继承自 RuntimeContext&lt;R, S&gt;
 * @author Orchestra Team
 * @since 1.0.0
 */
public class ReactiveApplicator<R, S, T extends RuntimeContext<R, S>> {
    
    private final Composer composer;
    
    /**
     * 构造一个 ReactiveApplicator 实例，使用默认的 Composer。
     */
    public ReactiveApplicator() {
        this.composer = new DefaultComposer();
    }
    
    /**
     * 构造一个 ReactiveApplicator 实例，使用指定的 Composer。
     * 
     * @param composer 流程编织器，不能为 null
     * @throws NullPointerException 如果 composer 为 null
     */
    public ReactiveApplicator(Composer composer) {
        this.composer = Objects.requireNonNull(composer, "Composer cannot be null");
    }
    
    /**
     * 执行业务流程。
     * 
     * <p>此方法会同步执行流程，直到流程完成或发生错误。
     * 对于需要异步执行的场景，可以使用 {@link #applyAsync(RuntimeContext, Procedure)} 方法。</p>
     * 
     * @param context 运行时上下文，包含请求和流程状态信息
     * @param procedure 要执行的业务流程
     * @return 执行完成后的运行时上下文，包含响应结果
     * @throws NullPointerException 如果 context 或 procedure 为 null
     * @throws RuntimeException 如果流程执行过程中发生错误
     */
    public RuntimeContext<R, S> apply(T context, Procedure<R, S, T> procedure) {
        Objects.requireNonNull(context, "Context cannot be null");
        Objects.requireNonNull(procedure, "Procedure cannot be null");
        
        try {
            // 执行流程定义，获取可执行对象
            Procedurable<T> procedurable = procedure.execute(context, composer);
            
            // 当前阶段（1.2），流程执行逻辑较为简单
            // 由于还没有实现具体的 DSL 方法（sync/async），这里先直接返回上下文
            // 在后续阶段（1.3）实现具体 DSL 方法后，这里会改为基于 RXJava 的执行逻辑
            
            // 使用 RXJava 的 Single 来包装执行逻辑，为后续扩展做准备
            return Single.fromCallable(() -> {
                // 执行流程（当前阶段为占位实现）
                executeProcedurable(procedurable, context);
                return context;
            })
            .subscribeOn(Schedulers.io())
            .timeout(30, TimeUnit.SECONDS)
            .blockingGet();
            
        } catch (Exception e) {
            throw new RuntimeException("Failed to execute procedure", e);
        }
    }
    
    /**
     * 异步执行业务流程。
     * 
     * <p>此方法会立即返回一个 Single，流程在后台异步执行。
     * 调用者可以通过 Single 来获取执行结果或处理错误。</p>
     * 
     * @param context 运行时上下文
     * @param procedure 要执行的业务流程
     * @return Single 对象，包含执行结果
     * @throws NullPointerException 如果 context 或 procedure 为 null
     */
    public Single<RuntimeContext<R, S>> applyAsync(T context, Procedure<R, S, T> procedure) {
        Objects.requireNonNull(context, "Context cannot be null");
        Objects.requireNonNull(procedure, "Procedure cannot be null");
        
        return Single.fromCallable(() -> {
            Procedurable<T> procedurable = procedure.execute(context, composer);
            executeProcedurable(procedurable, context);
            return (RuntimeContext<R, S>) context;
        })
        .subscribeOn(Schedulers.io())
        .timeout(30, TimeUnit.SECONDS);
    }
    
    /**
     * 执行可执行流程对象。
     * 
     * <p>此方法是流程执行的核心逻辑，解析并执行流程步骤。</p>
     * 
     * @param procedurable 可执行的流程对象
     * @param context 运行时上下文
     */
    private void executeProcedurable(Procedurable<T> procedurable, T context) {
        if (procedurable instanceof DefaultProcedureManager) {
            @SuppressWarnings("unchecked")
            DefaultProcedureManager<T> manager = (DefaultProcedureManager<T>) procedurable;
            ProcedureExecutor<T> executor = new ProcedureExecutor<>();
            executor.executeSteps(manager.getSteps(), context, manager);
        }
    }
    
    /**
     * 获取当前使用的 Composer 实例。
     * 
     * @return Composer 实例
     */
    public Composer getComposer() {
        return composer;
    }
}

