package io.orchestra.core.config;

/**
 * 背压策略枚举。
 * 
 * <p>定义在响应式流中处理背压的策略。</p>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
public enum BackpressureStrategy {
    /**
     * 缓冲策略：当生产者速度超过消费者时，将数据缓冲在内存中。
     * 如果缓冲区满了，会抛出异常。
     */
    BUFFER,
    
    /**
     * 丢弃策略：当生产者速度超过消费者时，丢弃最新的数据。
     */
    DROP,
    
    /**
     * 错误策略：当生产者速度超过消费者时，立即抛出错误。
     */
    ERROR,
    
    /**
     * 最新策略：当生产者速度超过消费者时，只保留最新的数据，丢弃旧数据。
     */
    LATEST,
    
    /**
     * 无背压策略：不进行背压处理，可能导致内存溢出。
     */
    NONE
}

