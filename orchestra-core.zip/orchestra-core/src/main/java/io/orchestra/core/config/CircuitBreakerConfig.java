package io.orchestra.core.config;

/**
 * 熔断器配置。
 * 
 * <p>用于配置熔断器的行为，包括失败率阈值、时间窗口等参数。</p>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
public class CircuitBreakerConfig {
    
    private final float failureRateThreshold;  // 失败率阈值（0.0-1.0）
    private final int slidingWindowSize;       // 滑动窗口大小
    private final long waitDurationInOpenState; // 打开状态等待时间（毫秒）
    private final int minimumNumberOfCalls;    // 最小调用次数
    
    private CircuitBreakerConfig(Builder builder) {
        this.failureRateThreshold = builder.failureRateThreshold;
        this.slidingWindowSize = builder.slidingWindowSize;
        this.waitDurationInOpenState = builder.waitDurationInOpenState;
        this.minimumNumberOfCalls = builder.minimumNumberOfCalls;
    }
    
    public float getFailureRateThreshold() {
        return failureRateThreshold;
    }
    
    public int getSlidingWindowSize() {
        return slidingWindowSize;
    }
    
    public long getWaitDurationInOpenState() {
        return waitDurationInOpenState;
    }
    
    public int getMinimumNumberOfCalls() {
        return minimumNumberOfCalls;
    }
    
    /**
     * 创建默认配置。
     */
    public static CircuitBreakerConfig ofDefaults() {
        return new Builder()
            .failureRateThreshold(0.5f)
            .slidingWindowSize(10)
            .waitDurationInOpenState(60000L)
            .minimumNumberOfCalls(5)
            .build();
    }
    
    /**
     * 创建自定义配置的构建器。
     */
    public static Builder custom() {
        return new Builder();
    }
    
    /**
     * 熔断器配置构建器。
     */
    public static class Builder {
        private float failureRateThreshold = 0.5f;
        private int slidingWindowSize = 10;
        private long waitDurationInOpenState = 60000L;
        private int minimumNumberOfCalls = 5;
        
        public Builder failureRateThreshold(float failureRateThreshold) {
            if (failureRateThreshold < 0.0f || failureRateThreshold > 1.0f) {
                throw new IllegalArgumentException("Failure rate threshold must be between 0.0 and 1.0");
            }
            this.failureRateThreshold = failureRateThreshold;
            return this;
        }
        
        public Builder slidingWindowSize(int slidingWindowSize) {
            if (slidingWindowSize <= 0) {
                throw new IllegalArgumentException("Sliding window size must be positive");
            }
            this.slidingWindowSize = slidingWindowSize;
            return this;
        }
        
        public Builder waitDurationInOpenState(long waitDurationInOpenState) {
            if (waitDurationInOpenState <= 0) {
                throw new IllegalArgumentException("Wait duration must be positive");
            }
            this.waitDurationInOpenState = waitDurationInOpenState;
            return this;
        }
        
        public Builder minimumNumberOfCalls(int minimumNumberOfCalls) {
            if (minimumNumberOfCalls <= 0) {
                throw new IllegalArgumentException("Minimum number of calls must be positive");
            }
            this.minimumNumberOfCalls = minimumNumberOfCalls;
            return this;
        }
        
        public CircuitBreakerConfig build() {
            return new CircuitBreakerConfig(this);
        }
    }
}

