package io.orchestra.core;

import io.orchestra.core.statemachine.StateMachine;

/**
 * 状态机管理器接口，用于在流程 DSL 中管理状态机。
 * 
 * <p>StateMachineManager 提供了状态机相关的 DSL 方法，用于在流程中执行状态转换。</p>
 * 
 * @param <State> 状态类型
 * @param <Event> 事件类型
 * @param <T> 运行时上下文类型
 * @author Orchestra Team
 * @since 2.0.0
 */
public interface StateMachineManager<State, Event, T extends RuntimeContext<?, ?>> extends Procedurable<T> {
    
    /**
     * 触发状态转换。
     * 
     * @param event 触发事件
     * @return StateMachineManager 实例，支持链式调用
     */
    StateMachineManager<State, Event, T> trigger(Event event);
    
    /**
     * 获取当前状态。
     * 
     * @return 当前状态
     */
    State getCurrentState();
    
    /**
     * 获取状态机实例。
     * 
     * @return 状态机实例
     */
    StateMachine<State, Event, T> getStateMachine();
}

