package io.orchestra.core.statemachine;

import java.util.HashMap;
import java.util.Map;

/**
 * 状态机快照，用于状态持久化。
 * 
 * @param <State> 状态类型
 * @param <Event> 事件类型
 * @author Orchestra Team
 * @since 2.0.0
 */
public class StateMachineSnapshot<State, Event> {
    
    private String instanceId;
    private State currentState;
    private Map<String, Object> contextData;
    private long timestamp;
    private int version;
    
    public StateMachineSnapshot() {
        this.contextData = new HashMap<>();
        this.version = 0;
        this.timestamp = System.currentTimeMillis();
    }
    
    public StateMachineSnapshot(String instanceId, State currentState) {
        this();
        this.instanceId = instanceId;
        this.currentState = currentState;
    }
    
    public String getInstanceId() {
        return instanceId;
    }
    
    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }
    
    public State getCurrentState() {
        return currentState;
    }
    
    public void setCurrentState(State currentState) {
        this.currentState = currentState;
        this.timestamp = System.currentTimeMillis();
    }
    
    public Map<String, Object> getContextData() {
        return contextData;
    }
    
    public void setContextData(Map<String, Object> contextData) {
        this.contextData = contextData != null ? new HashMap<>(contextData) : new HashMap<>();
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    
    public int getVersion() {
        return version;
    }
    
    public void setVersion(int version) {
        this.version = version;
    }
    
    /**
     * 更新状态（带版本检查，乐观锁）。
     */
    public boolean updateWithVersion(int expectedVersion, State newState) {
        if (this.version != expectedVersion) {
            return false;
        }
        this.currentState = newState;
        this.version++;
        this.timestamp = System.currentTimeMillis();
        return true;
    }
    
    /**
     * 增加版本号。
     */
    public void incrementVersion() {
        this.version++;
        this.timestamp = System.currentTimeMillis();
    }
}

