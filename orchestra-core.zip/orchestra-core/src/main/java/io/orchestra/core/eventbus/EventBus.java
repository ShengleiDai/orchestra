package io.orchestra.core.eventbus;

import java.util.concurrent.CompletableFuture;

/**
 * 事件总线接口。
 * 
 * <p>EventBus 用于在流程中发布和订阅事件，支持同步和异步事件发布。</p>
 * 
 * <p>实现类应该提供线程安全的事件发布和订阅机制。</p>
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
public interface EventBus {
    
    /**
     * 发布事件（同步）。
     * 
     * <p>同步发布事件，会等待所有订阅者处理完成后返回。</p>
     * 
     * @param event 要发布的事件
     * @throws EventBusException 如果发布失败
     */
    void publish(Event event) throws EventBusException;
    
    /**
     * 发布事件（异步）。
     * 
     * <p>异步发布事件，立即返回，不等待订阅者处理。</p>
     * 
     * @param event 要发布的事件
     * @return CompletableFuture，表示异步操作的结果
     */
    CompletableFuture<Void> publishAsync(Event event);
    
    /**
     * 订阅事件。
     * 
     * <p>注册一个事件处理器，当指定类型的事件发布时，会调用该处理器。</p>
     * 
     * @param <E> 事件类型
     * @param eventType 要订阅的事件类型
     * @param handler 事件处理器
     * @return 订阅 ID，可用于取消订阅
     */
    <E extends Event> String subscribe(Class<E> eventType, EventHandler<E> handler);
    
    /**
     * 取消订阅。
     * 
     * @param subscriptionId 订阅 ID
     */
    void unsubscribe(String subscriptionId);
    
    /**
     * 取消订阅指定事件类型的所有处理器。
     * 
     * @param eventType 事件类型
     */
    void unsubscribe(Class<? extends Event> eventType);
    
    /**
     * 等待事件（阻塞直到收到指定类型的事件）。
     * 
     * <p>此方法会阻塞当前线程，直到收到指定类型的事件或超时。</p>
     * 
     * @param <E> 事件类型
     * @param eventType 要等待的事件类型
     * @param timeoutMillis 超时时间（毫秒），0 表示无限等待
     * @return 收到的事件，如果超时则返回 null
     * @throws InterruptedException 如果等待过程中线程被中断
     */
    <E extends Event> E await(Class<E> eventType, long timeoutMillis) throws InterruptedException;
    
    /**
     * 关闭事件总线。
     * 
     * <p>释放所有资源，停止所有后台任务。</p>
     */
    void shutdown();
}

