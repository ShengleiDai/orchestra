package io.orchestra.core.performance;

import io.orchestra.core.config.CircuitBreakerConfig;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * 熔断器实现。
 * 
 * <p>用于防止级联故障，当失败率超过阈值时，会打开熔断器，拒绝后续请求。</p>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
public class CircuitBreaker {
    
    /**
     * 熔断器状态。
     */
    public enum State {
        CLOSED,   // 关闭状态：正常处理请求
        OPEN,     // 打开状态：拒绝请求
        HALF_OPEN // 半开状态：允许少量请求通过，用于测试
    }
    
    private final String name;
    private final CircuitBreakerConfig config;
    
    private final AtomicReference<State> state = new AtomicReference<>(State.CLOSED);
    private final AtomicInteger successCount = new AtomicInteger(0);
    private final AtomicInteger failureCount = new AtomicInteger(0);
    private final AtomicLong lastFailureTime = new AtomicLong(0);
    private final AtomicInteger halfOpenSuccessCount = new AtomicInteger(0);
    
    public CircuitBreaker(String name, CircuitBreakerConfig config) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Circuit breaker name cannot be null or empty");
        }
        if (config == null) {
            throw new NullPointerException("Circuit breaker config cannot be null");
        }
        this.name = name;
        this.config = config;
    }
    
    /**
     * 尝试执行操作。
     * 
     * @param operation 要执行的操作
     * @return 操作结果
     * @throws CircuitBreakerOpenException 如果熔断器处于打开状态
     */
    public <T> T execute(java.util.function.Supplier<T> operation) {
        State currentState = state.get();
        
        if (currentState == State.OPEN) {
            // 检查是否可以进入半开状态
            long now = System.currentTimeMillis();
            if (now - lastFailureTime.get() >= config.getWaitDurationInOpenState()) {
                if (state.compareAndSet(State.OPEN, State.HALF_OPEN)) {
                    halfOpenSuccessCount.set(0);
                    currentState = State.HALF_OPEN;
                } else {
                    currentState = state.get();
                }
            }
            
            if (currentState == State.OPEN) {
                throw new CircuitBreakerOpenException("Circuit breaker is OPEN: " + name);
            }
        }
        
        try {
            T result = operation.get();
            onSuccess();
            return result;
        } catch (Exception e) {
            onFailure();
            throw e;
        }
    }
    
    /**
     * 执行操作（无返回值）。
     */
    public void execute(Runnable operation) {
        execute(() -> {
            operation.run();
            return null;
        });
    }
    
    private void onSuccess() {
        State currentState = state.get();
        
        if (currentState == State.HALF_OPEN) {
            int halfOpenSuccess = halfOpenSuccessCount.incrementAndGet();
            // 如果半开状态下成功次数达到阈值，关闭熔断器
            if (halfOpenSuccess >= config.getMinimumNumberOfCalls()) {
                state.set(State.CLOSED);
                resetCounters();
            }
        } else if (currentState == State.CLOSED) {
            successCount.incrementAndGet();
            checkAndResetWindow();
        }
    }
    
    private void onFailure() {
        State currentState = state.get();
        lastFailureTime.set(System.currentTimeMillis());
        
        if (currentState == State.HALF_OPEN) {
            // 半开状态下失败，重新打开熔断器
            state.set(State.OPEN);
            resetCounters();
        } else if (currentState == State.CLOSED) {
            failureCount.incrementAndGet();
            checkFailureRate();
        }
    }
    
    private void checkFailureRate() {
        int total = successCount.get() + failureCount.get();
        if (total >= config.getMinimumNumberOfCalls()) {
            float failureRate = (float) failureCount.get() / total;
            if (failureRate >= config.getFailureRateThreshold()) {
                state.set(State.OPEN);
            }
        }
        
        // 检查滑动窗口大小
        if (total >= config.getSlidingWindowSize()) {
            resetCounters();
        }
    }
    
    private void checkAndResetWindow() {
        int total = successCount.get() + failureCount.get();
        if (total >= config.getSlidingWindowSize()) {
            resetCounters();
        }
    }
    
    private void resetCounters() {
        successCount.set(0);
        failureCount.set(0);
    }
    
    public State getState() {
        return state.get();
    }
    
    public String getName() {
        return name;
    }
    
    /**
     * 熔断器打开异常。
     */
    public static class CircuitBreakerOpenException extends RuntimeException {
        public CircuitBreakerOpenException(String message) {
            super(message);
        }
    }
}

