package io.orchestra.core;

/**
 * 流程可执行对象的抽象接口。
 * 
 * <p>Procedurable 表示一个可以被执行的流程单元，它支持链式调用和组合。
 * 这是 Orchestra 框架中流程编排的基础抽象，所有的流程步骤都应该实现此接口。</p>
 * 
 * <p>Procedurable 的设计允许流程步骤以声明式的方式组合，形成复杂的业务流程。
 * 通过链式调用，可以构建出清晰、易读的流程定义。</p>
 * 
 * @param <T> 运行时上下文类型，必须继承自 RuntimeContext
 * @author Orchestra Team
 * @since 1.0.0
 */
public interface Procedurable<T extends RuntimeContext<?, ?>> {
    // 此接口主要用于类型标记和扩展点
    // 具体的 DSL 方法将在 ProcedureManager 中实现
}

