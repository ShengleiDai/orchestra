package io.orchestra.core.eventbus;

/**
 * 事件处理器接口。
 * 
 * @param <E> 事件类型
 * @author Orchestra Team
 * @since 2.0.0
 */
@FunctionalInterface
public interface EventHandler<E extends Event> {
    
    /**
     * 处理事件。
     * 
     * @param event 要处理的事件
     * @throws Exception 处理过程中可能抛出的异常
     */
    void handle(E event) throws Exception;
}

