package io.orchestra.core.statemachine;

/**
 * 状态转换记录。
 * 
 * @param <State> 状态类型
 * @param <Event> 事件类型
 * @author Orchestra Team
 * @since 2.0.0
 */
public class StateTransition<State, Event> {
    
    private String instanceId;
    private State fromState;
    private State toState;
    private Event event;
    private long timestamp;
    private boolean success;
    private String errorMessage;
    
    public StateTransition() {
        this.timestamp = System.currentTimeMillis();
        this.success = true;
    }
    
    public StateTransition(String instanceId, State fromState, State toState, Event event) {
        this();
        this.instanceId = instanceId;
        this.fromState = fromState;
        this.toState = toState;
        this.event = event;
    }
    
    public String getInstanceId() {
        return instanceId;
    }
    
    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }
    
    public State getFromState() {
        return fromState;
    }
    
    public void setFromState(State fromState) {
        this.fromState = fromState;
    }
    
    public State getToState() {
        return toState;
    }
    
    public void setToState(State toState) {
        this.toState = toState;
    }
    
    public Event getEvent() {
        return event;
    }
    
    public void setEvent(Event event) {
        this.event = event;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    
    public boolean isSuccess() {
        return success;
    }
    
    public void setSuccess(boolean success) {
        this.success = success;
    }
    
    public String getErrorMessage() {
        return errorMessage;
    }
    
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}

