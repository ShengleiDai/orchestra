package io.orchestra.core.eventbus;

/**
 * 事件总线注册表。
 * 
 * <p>用于管理全局的 EventBus 实例，支持默认实例和自定义实例。</p>
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
public class EventBusRegistry {
    
    private static volatile EventBus defaultEventBus;
    
    /**
     * 获取默认的 EventBus 实例。
     * 
     * <p>如果未设置，则创建一个 InMemoryEventBus 实例。</p>
     * 
     * @return 默认的 EventBus 实例
     */
    public static EventBus getDefault() {
        if (defaultEventBus == null) {
            synchronized (EventBusRegistry.class) {
                if (defaultEventBus == null) {
                    defaultEventBus = new InMemoryEventBus();
                }
            }
        }
        return defaultEventBus;
    }
    
    /**
     * 设置默认的 EventBus 实例。
     * 
     * @param eventBus EventBus 实例
     */
    public static void setDefault(EventBus eventBus) {
        synchronized (EventBusRegistry.class) {
            defaultEventBus = eventBus;
        }
    }
    
    /**
     * 重置默认的 EventBus 实例。
     * 
     * <p>主要用于测试。</p>
     */
    public static void reset() {
        synchronized (EventBusRegistry.class) {
            if (defaultEventBus != null) {
                defaultEventBus.shutdown();
            }
            defaultEventBus = null;
        }
    }
}

