package io.orchestra.core.statemachine;

import io.orchestra.core.RuntimeContext;

import java.util.List;

/**
 * 状态机接口。
 * 
 * @param <State> 状态类型
 * @param <Event> 事件类型
 * @param <T> 运行时上下文类型
 * @author Orchestra Team
 * @since 2.0.0
 */
public interface StateMachine<State, Event, T extends RuntimeContext<?, ?>> {
    
    /**
     * 获取当前状态。
     * 
     * @return 当前状态
     */
    State getCurrentState();
    
    /**
     * 执行状态转换。
     * 
     * @param context 运行时上下文
     * @param event 触发事件
     * @return 转换后的新状态，如果转换失败则返回 null
     * @throws IllegalStateException 如果当前状态不允许该转换
     */
    State transition(T context, Event event);
    
    /**
     * 检查是否可以执行状态转换。
     * 
     * @param fromState 源状态
     * @param event 触发事件
     * @return 如果可以转换返回 true，否则返回 false
     */
    boolean canTransition(State fromState, Event event);
    
    /**
     * 获取可能的下一个状态列表。
     * 
     * @param currentState 当前状态
     * @return 可能的下一个状态列表
     */
    List<State> getPossibleNextStates(State currentState);
    
    /**
     * 检查状态是否为终止状态。
     * 
     * @param state 要检查的状态
     * @return 如果是终止状态返回 true，否则返回 false
     */
    boolean isTerminalState(State state);
    
    /**
     * 获取初始状态。
     * 
     * @return 初始状态
     */
    State getInitialState();
    
    /**
     * 获取状态机实例 ID。
     * 
     * @return 实例 ID
     */
    String getInstanceId();
}

