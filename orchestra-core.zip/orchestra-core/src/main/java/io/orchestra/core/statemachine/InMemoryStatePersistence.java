package io.orchestra.core.statemachine;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * 内存状态持久化实现。
 * 
 * <p>默认实现，适用于开发和测试环境。生产环境建议使用数据库或 Redis 实现。</p>
 * 
 * @param <State> 状态类型
 * @param <Event> 事件类型
 * @author Orchestra Team
 * @since 2.0.0
 */
public class InMemoryStatePersistence<State, Event> implements StatePersistence<State, Event> {
    
    private final ConcurrentMap<String, StateMachineSnapshot<State, Event>> snapshots = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, List<StateTransition<State, Event>>> transitions = new ConcurrentHashMap<>();
    
    @Override
    public void saveState(String instanceId, StateMachineSnapshot<State, Event> snapshot) {
        if (instanceId == null || instanceId.trim().isEmpty()) {
            throw new IllegalArgumentException("Instance ID cannot be null or empty");
        }
        if (snapshot == null) {
            throw new NullPointerException("Snapshot cannot be null");
        }
        // 创建快照的深拷贝以避免外部修改影响内部状态
        StateMachineSnapshot<State, Event> snapshotCopy = new StateMachineSnapshot<>();
        snapshotCopy.setInstanceId(snapshot.getInstanceId());
        snapshotCopy.setCurrentState(snapshot.getCurrentState());
        snapshotCopy.setContextData(snapshot.getContextData());
        snapshotCopy.setVersion(snapshot.getVersion());
        snapshotCopy.setTimestamp(snapshot.getTimestamp());
        snapshots.put(instanceId, snapshotCopy);
    }
    
    @Override
    public StateMachineSnapshot<State, Event> loadState(String instanceId) {
        if (instanceId == null || instanceId.trim().isEmpty()) {
            return null;
        }
        StateMachineSnapshot<State, Event> snapshot = snapshots.get(instanceId);
        if (snapshot == null) {
            return null;
        }
        // 返回快照的深拷贝以避免外部修改影响内部状态
        StateMachineSnapshot<State, Event> snapshotCopy = new StateMachineSnapshot<>();
        snapshotCopy.setInstanceId(snapshot.getInstanceId());
        snapshotCopy.setCurrentState(snapshot.getCurrentState());
        snapshotCopy.setContextData(snapshot.getContextData());
        snapshotCopy.setVersion(snapshot.getVersion());
        snapshotCopy.setTimestamp(snapshot.getTimestamp());
        return snapshotCopy;
    }
    
    @Override
    public void deleteState(String instanceId) {
        if (instanceId != null && !instanceId.trim().isEmpty()) {
            snapshots.remove(instanceId);
            transitions.remove(instanceId);
        }
    }
    
    @Override
    public void saveTransition(String instanceId, StateTransition<State, Event> transition) {
        if (instanceId == null || instanceId.trim().isEmpty()) {
            throw new IllegalArgumentException("Instance ID cannot be null or empty");
        }
        if (transition == null) {
            throw new NullPointerException("Transition cannot be null");
        }
        // 使用 CopyOnWriteArrayList 保证线程安全
        transitions.computeIfAbsent(instanceId, k -> new CopyOnWriteArrayList<>()).add(transition);
    }
    
    @Override
    public List<StateTransition<State, Event>> getTransitionHistory(String instanceId) {
        if (instanceId == null || instanceId.trim().isEmpty()) {
            return new ArrayList<>();
        }
        List<StateTransition<State, Event>> history = transitions.get(instanceId);
        return history != null ? new ArrayList<>(history) : new ArrayList<>();
    }
    
    @Override
    public List<StateTransition<State, Event>> getTransitionHistory(String instanceId, int limit) {
        List<StateTransition<State, Event>> history = getTransitionHistory(instanceId);
        if (limit <= 0) {
            return history;
        }
        int size = history.size();
        int fromIndex = Math.max(0, size - limit);
        return history.subList(fromIndex, size);
    }
    
    /**
     * 清除所有状态（主要用于测试）。
     */
    public void clear() {
        snapshots.clear();
        transitions.clear();
    }
}

