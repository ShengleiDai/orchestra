package io.orchestra.core;

import io.orchestra.core.abtest.Variant;
import io.orchestra.core.config.BackpressureStrategy;
import io.orchestra.core.config.CircuitBreakerConfig;
import io.orchestra.core.config.RateLimiterConfig;
import io.orchestra.core.eventbus.Event;
import io.orchestra.core.statemachine.StateMachine;
import io.orchestra.core.statemachine.StateMachineBuilder;

import java.util.List;

import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * 流程管理器接口，提供丰富的 DSL 来定义业务流程。
 * 
 * <p>ProcedureManager 是 Orchestra 框架中流程 DSL 的核心接口，
 * 提供了同步、异步、并行、分支等各种流程编排操作。</p>
 * 
 * <p>ProcedureManager 支持链式调用，可以流畅地组合多个步骤：
 * <pre>{@code
 * return composer.just(context)
 *     .sync(this::step1)
 *     .async(this::step2)
 *     .parallel(stream -> stream.async(this::step3))
 *     .sync(this::step4);
 * }</pre>
 * </p>
 * 
 * @param <T> 运行时上下文类型，必须继承自 RuntimeContext
 * @author Orchestra Team
 * @since 1.0.0
 */
public interface ProcedureManager<T extends RuntimeContext<?, ?>> extends Procedurable<T> {
    
    /**
     * 添加同步执行步骤（Consumer 版本）。
     * 
     * @param consumer 同步执行的业务逻辑
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> sync(Consumer<T> consumer);
    
    /**
     * 添加同步执行步骤（Function 版本）。
     * 
     * @param function 同步执行的业务逻辑，返回结果
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> sync(Function<T, ?> function);
    
    /**
     * 添加同步执行步骤（Procedure 版本）。
     * 
     * <p>执行一个子 Procedure，实现流程的模块化和复用。</p>
     * 
     * <p>使用示例：</p>
     * <pre>{@code
     * return composer.just(context)
     *     .sync(new PaymentProcedure())
     *     .sync(new ShippingProcedure());
     * }</pre>
     * 
     * @param procedure 要执行的子 Procedure，必须接受当前上下文类型 T
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> sync(Procedure<?, ?, T> procedure);
    
    /**
     * 添加异步执行步骤（Supplier 版本）。
     * 
     * @param supplier 异步执行的业务逻辑
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> async(Supplier<?> supplier);
    
    /**
     * 添加异步执行步骤（Function 版本，返回 CompletableFuture）。
     * 
     * @param function 异步执行的业务逻辑，返回 CompletableFuture
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> async(Function<T, CompletableFuture<?>> function);
    
    /**
     * 添加异步执行步骤（Procedure 版本）。
     * 
     * <p>异步执行一个子 Procedure，实现流程的模块化和复用。</p>
     * 
     * @param procedure 要执行的子 Procedure，必须接受当前上下文类型 T
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> async(Procedure<?, ?, T> procedure);
    
    /**
     * 添加并行执行步骤。
     * 
     * @param streamBuilders 并行流的构建器数组
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> parallel(Function<ProcedureManager<T>, Procedurable<T>>... streamBuilders);
    
    /**
     * 添加并行执行步骤（Procedure 版本）。
     * 
     * <p>并行执行多个子 Procedure，提高执行效率。</p>
     * 
     * <p>使用示例：</p>
     * <pre>{@code
     * return composer.just(context)
     *     .parallel(
     *         new PaymentProcedure(),
     *         new InventoryProcedure(),
     *         new NotificationProcedure()
     *     );
     * }</pre>
     * 
     * @param procedures 要并行执行的子 Procedure 数组，必须接受当前上下文类型 T
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> parallel(Procedure<?, ?, T>... procedures);
    
    /**
     * 添加条件分支步骤（双分支）。
     * 
     * @param condition 条件判断
     * @param trueBranch 条件为真时的分支处理
     * @param falseBranch 条件为假时的分支处理
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> branch(
            Predicate<T> condition,
            Function<ProcedureManager<T>, Procedurable<T>> trueBranch,
            Function<ProcedureManager<T>, Procedurable<T>> falseBranch);
    
    /**
     * 添加条件分支步骤（单分支）。
     * 
     * @param condition 条件判断
     * @param branch 条件为真时的分支处理
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> branch(
            Predicate<T> condition,
            Function<ProcedureManager<T>, Procedurable<T>> branch);
    
    /**
     * 添加条件分支步骤（Procedure 版本，双分支）。
     * 
     * <p>根据条件选择执行不同的子 Procedure。</p>
     * 
     * @param condition 条件判断
     * @param trueProcedure 条件为真时执行的 Procedure，必须接受当前上下文类型 T
     * @param falseProcedure 条件为假时执行的 Procedure，必须接受当前上下文类型 T
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> branch(
            Predicate<T> condition,
            Procedure<?, ?, T> trueProcedure,
            Procedure<?, ?, T> falseProcedure);
    
    /**
     * 添加条件分支步骤（Procedure 版本，单分支）。
     * 
     * @param condition 条件判断
     * @param procedure 条件为真时执行的 Procedure，必须接受当前上下文类型 T
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> branch(
            Predicate<T> condition,
            Procedure<?, ?, T> procedure);
    
    /**
     * 多分支选择操作（基于值匹配）。
     * 
     * <p>根据上下文中的某个值，选择对应的分支执行。类似于 Java 的 switch-case 语句。</p>
     * 
     * <p>使用示例：</p>
     * <pre>{@code
     * return composer.just(context)
     *     .select(ctx -> ctx.getOrderType(),  // 提取要匹配的值
     *         Case.of("VIP", branch -> branch
     *             .sync(this::processVIPOrder)
     *             .async(this::sendVIPNotification)),
     *         Case.of("NORMAL", branch -> branch
     *             .sync(this::processNormalOrder)),
     *         Case.of("BULK", branch -> branch
     *             .sync(this::processBulkOrder)),
     *         Case.defaultCase(branch -> branch
     *             .sync(this::processDefaultOrder))
     *     );
     * }</pre>
     * 
     * <p>注意事项：</p>
     * <ul>
     *   <li>分支按顺序匹配，第一个匹配的分支会被执行</li>
     *   <li>建议在最后提供默认分支（使用 {@link Case#defaultCase}）</li>
     *   <li>如果没有匹配的分支且没有默认分支，会抛出异常</li>
     *   <li>匹配使用 {@link Object#equals} 方法，确保值类型正确实现 equals 方法</li>
     * </ul>
     * 
     * @param <V> 匹配值的类型
     * @param valueExtractor 从上下文中提取要匹配的值
     * @param cases 分支列表，最后一个可以是默认分支
     * @return ProcedureManager 实例，支持链式调用
     * @throws NullPointerException 如果 valueExtractor 或 cases 为 null
     * @throws IllegalArgumentException 如果 cases 为空
     */
    <V> ProcedureManager<T> select(
            Function<T, V> valueExtractor,
            Case<V, T>... cases);
    
    /**
     * 多分支选择操作（Procedure 版本）。
     * 
     * <p>根据上下文中的某个值，选择对应的 Procedure 执行。</p>
     * 
     * <p>使用示例：</p>
     * <pre>{@code
     * return composer.just(context)
     *     .select(ctx -> ctx.getOrderType(),
     *         ProcedureCase.of("VIP", new VIPOrderProcedure()),
     *         ProcedureCase.of("NORMAL", new NormalOrderProcedure()),
     *         ProcedureCase.defaultCase(new DefaultOrderProcedure())
     *     );
     * }</pre>
     * 
     * @param <V> 匹配值的类型
     * @param valueExtractor 从上下文中提取要匹配的值
     * @param cases 分支列表，每个 Case 包含匹配值和对应的 Procedure
     * @return ProcedureManager 实例，支持链式调用
     */
    <V> ProcedureManager<T> select(
            Function<T, V> valueExtractor,
            ProcedureCase<V, ?, ?, T>... cases);
    
    /**
     * 添加错误重试处理。
     * 
     * @param errorType 要重试的异常类型
     * @param retryCount 重试次数
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> onErrorRetry(Class<? extends Throwable> errorType, int retryCount);
    
    /**
     * 添加错误降级处理。
     * 
     * @param errorType 要降级的异常类型
     * @param fallbackHandler 降级处理函数
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> onErrorResume(Class<? extends Throwable> errorType, Function<Throwable, Procedurable<T>> fallbackHandler);
    
    /**
     * 添加错误降级处理（Procedure 版本）。
     * 
     * <p>当发生指定类型的错误时，执行降级 Procedure。</p>
     * 
     * @param errorType 要降级的异常类型
     * @param fallbackProcedure 降级 Procedure，必须接受当前上下文类型 T
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> onErrorResume(Class<? extends Throwable> errorType, Procedure<?, ?, T> fallbackProcedure);
    
    /**
     * 添加错误处理。
     * 
     * @param errorType 要处理的异常类型
     * @param handler 错误处理函数
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> onError(Class<? extends Throwable> errorType, Consumer<T> handler);
    
    /**
     * 添加超时控制。
     * 
     * @param timeout 超时时间
     * @param timeUnit 时间单位
     * @param handler 超时处理函数
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> timeout(long timeout, TimeUnit timeUnit, Consumer<T> handler);
    
    /**
     * 添加超时控制（Procedure 版本）。
     * 
     * <p>当操作超时时，执行超时处理 Procedure。</p>
     * 
     * <p>注意：由于 Java 类型擦除的限制，此方法与 {@link #timeout(long, TimeUnit, Consumer)} 在运行时签名相同，
     * 因此使用不同的方法名。</p>
     * 
     * @param timeout 超时时间
     * @param timeUnit 时间单位
     * @param timeoutProcedure 超时处理 Procedure，必须接受当前上下文类型 T
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> timeoutWithProcedure(long timeout, TimeUnit timeUnit, Procedure<?, ?, T> timeoutProcedure);
    
    /**
     * 开始 Saga 事务。
     * 
     * <p>Saga 模式用于管理分布式事务，当 Saga 中的任何步骤失败时，
     * 会自动执行已注册的补偿操作（按相反顺序）。</p>
     * 
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> sagaStart();
    
    /**
     * 结束 Saga 事务。
     * 
     * <p>标记 Saga 事务的结束。如果所有步骤都成功执行，则不会执行补偿操作。</p>
     * 
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> sagaEnd();
    
    /**
     * 为前一个步骤注册补偿操作。
     * 
     * <p>补偿操作会在 Saga 事务失败时自动执行，用于撤销前一个步骤的操作。
     * 补偿操作会按照与注册顺序相反的顺序执行。</p>
     * 
     * @param compensationFunction 补偿操作函数
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> withCompensation(Function<T, ?> compensationFunction);
    
    /**
     * 为前一个步骤添加熔断器保护。
     * 
     * <p>熔断器用于防止级联故障，当失败率超过阈值时，会打开熔断器，
     * 拒绝后续请求，直到等待时间过后进入半开状态。</p>
     * 
     * @param name 熔断器名称，用于标识和复用
     * @param config 熔断器配置
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> withCircuitBreaker(String name, CircuitBreakerConfig config);
    
    /**
     * 为前一个步骤添加隔离舱保护。
     * 
     * <p>隔离舱用于限制并发执行数量，防止资源耗尽。</p>
     * 
     * @param name 隔离舱名称，用于标识和复用
     * @param maxConcurrency 最大并发数
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> withBulkhead(String name, int maxConcurrency);
    
    /**
     * 为前一个步骤添加限流器保护。
     * 
     * <p>限流器用于限制请求速率，防止系统过载。</p>
     * 
     * @param name 限流器名称，用于标识和复用
     * @param config 限流器配置
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> withRateLimiter(String name, RateLimiterConfig config);
    
    /**
     * 为前一个步骤设置背压策略。
     * 
     * <p>背压策略用于处理生产者速度超过消费者的情况。</p>
     * 
     * @param strategy 背压策略
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> onBackpressure(BackpressureStrategy strategy);
    
    /**
     * 添加状态机步骤。
     * 
     * <p>状态机用于管理复杂对象的状态流转，支持事件驱动的状态转换。</p>
     * 
     * <p>使用示例：</p>
     * <pre>{@code
     * return composer.just(context)
     *     .stateMachine(OrderState.class, builder -> builder
     *         .initial(OrderState.CREATED)
     *         .transition(OrderState.CREATED, OrderCreatedEvent.class, OrderState.PENDING)
     *         .transition(OrderState.PENDING, PaymentCompletedEvent.class, OrderState.PAID)
     *         .terminateOn(OrderState.COMPLETED, OrderState.CANCELLED)
     *     );
     * }</pre>
     * 
     * @param <State> 状态类型
     * @param <Event> 事件类型
     * @param stateType 状态类型 Class 对象
     * @param builder 状态机构建器函数
     * @return StateMachineManager 实例，用于后续的状态转换操作
     */
    <State, Event> StateMachineManager<State, Event, T> stateMachine(
            Class<State> stateType,
            Function<StateMachineBuilder<State, Event, T>, StateMachine<State, Event, T>> builder);
    
    /**
     * 发布事件。
     * 
     * <p>在流程中发布事件，支持同步和异步发布。</p>
     * 
     * <p>使用示例：</p>
     * <pre>{@code
     * return composer.just(context)
     *     .sync(this::createOrder)
     *     .publish(ctx -> new OrderPlacedEvent(ctx.getOrder()))  // 异步发布，不阻塞流程
     *     .sync(this::notifyUser);
     * }</pre>
     * 
     * @param <E> 事件类型
     * @param eventSupplier 事件提供函数，从上下文生成事件
     * @return ProcedureManager 实例，支持链式调用
     */
    <E extends Event> ProcedureManager<T> publish(Function<T, E> eventSupplier);
    
    /**
     * 监听事件。
     * 
     * <p>在流程中等待指定类型的事件，支持超时设置。</p>
     * 
     * <p>使用示例：</p>
     * <pre>{@code
     * return composer.just(context)
     *     .sync(this::submitPaymentRequest)
     *     .onEvent(PaymentCallbackEvent.class, (ctx, event) -> {
     *         if (event.isSuccess()) {
     *             ctx.setPaymentId(event.getPaymentId());
     *         } else {
     *             throw new PaymentFailedException(event.getReason());
     *         }
     *     })
     *     .timeout(Duration.ofMinutes(30))
     *     .sync(this::finishOrder);
     * }</pre>
     * 
     * @param <E> 事件类型
     * @param eventType 要监听的事件类型
     * @param handler 事件处理函数，当收到事件时调用
     * @return ProcedureManager 实例，支持链式调用
     */
    <E extends Event> ProcedureManager<T> onEvent(Class<E> eventType, BiConsumer<T, E> handler);
    
    /**
     * 监听事件（带超时）。
     * 
     * @param <E> 事件类型
     * @param eventType 要监听的事件类型
     * @param handler 事件处理函数，当收到事件时调用
     * @param timeout 超时时间
     * @return ProcedureManager 实例，支持链式调用
     */
    <E extends Event> ProcedureManager<T> onEvent(Class<E> eventType, BiConsumer<T, E> handler, Duration timeout);
    
    /**
     * A/B 测试操作。
     * 
     * <p>根据流量分配算法，将流量分配到不同的变体，并执行对应的流程分支。</p>
     * 
     * <p>使用示例：</p>
     * <pre>{@code
     * return composer.just(context)
     *     .abTest("new-checkout-flow",  // 实验 ID
     *         ctx -> ctx.getUserId(),  // 用户 ID 提取器
     *         Arrays.asList(
     *             new Variant("A", 0.5),  // 50% 流量到变体 A
     *             new Variant("B", 0.5)  // 50% 流量到变体 B
     *         ),
     *         (variant, branch) -> {
     *             if ("A".equals(variant)) {
     *                 return branch.sync(this::processVariantA);
     *             } else {
     *                 return branch.sync(this::processVariantB);
     *             }
     *         }
     *     );
     * }</pre>
     * 
     * <p>注意事项：</p>
     * <ul>
     *   <li>同一用户/设备会始终分配到同一变体（通过持久化保证）</li>
     *   <li>变体权重之和必须等于 1.0</li>
     *   <li>变体名称必须唯一</li>
     *   <li>流量分配结果会被持久化，确保一致性</li>
     * </ul>
     * 
     * @param experimentId 实验 ID，用于标识 A/B 测试实验
     * @param userIdExtractor 从上下文中提取用户 ID 的函数
     * @param variants 变体列表，包含变体名称和权重
     * @param variantHandler 变体处理函数，根据分配的变体执行对应的流程分支
     * @return ProcedureManager 实例，支持链式调用
     * @throws NullPointerException 如果任何参数为 null
     * @throws IllegalArgumentException 如果变体配置无效
     */
    ProcedureManager<T> abTest(
            String experimentId,
            Function<T, String> userIdExtractor,
            List<Variant> variants,
            BiFunction<String, ProcedureManager<T>, Procedurable<T>> variantHandler);
    
    /**
     * A/B 测试操作（Procedure 版本）。
     * 
     * <p>根据流量分配算法，将流量分配到不同的变体，并执行对应的 Procedure。</p>
     * 
     * <p>使用示例：</p>
     * <pre>{@code
     * return composer.just(context)
     *     .abTest("checkout-flow-v2",
     *         ctx -> ctx.getCustomerId(),
     *         Arrays.asList(
     *             new Variant("A", 0.5),
     *             new Variant("B", 0.5)
     *         ),
     *         new CheckoutProcedureV1(),  // 变体 A
     *         new CheckoutProcedureV2()   // 变体 B
     *     );
     * }</pre>
     * 
     * @param experimentId 实验 ID
     * @param userIdExtractor 从上下文中提取用户 ID 的函数
     * @param variants 变体列表
     * @param procedures 对应每个变体的 Procedure 数组（顺序与 variants 一致），必须接受当前上下文类型 T
     * @return ProcedureManager 实例，支持链式调用
     */
    ProcedureManager<T> abTest(
            String experimentId,
            Function<T, String> userIdExtractor,
            List<Variant> variants,
            Procedure<?, ?, T>... procedures);
}

