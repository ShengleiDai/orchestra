package io.orchestra.core.abtest;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * 内存流量分配持久化实现。
 * 
 * <p>默认实现，适用于开发和测试环境。生产环境建议使用数据库或 Redis 实现。</p>
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
public class InMemoryTrafficAllocationPersistence implements TrafficAllocationPersistence {
    
    // 实验 ID -> (用户 ID -> 变体名称)
    private final ConcurrentMap<String, ConcurrentMap<String, String>> allocations = new ConcurrentHashMap<>();
    
    @Override
    public void saveAllocation(String experimentId, String userId, String variant) {
        if (experimentId == null || experimentId.trim().isEmpty()) {
            throw new IllegalArgumentException("Experiment ID cannot be null or empty");
        }
        if (userId == null || userId.trim().isEmpty()) {
            throw new IllegalArgumentException("User ID cannot be null or empty");
        }
        if (variant == null || variant.trim().isEmpty()) {
            throw new IllegalArgumentException("Variant cannot be null or empty");
        }
        
        allocations.computeIfAbsent(experimentId, k -> new ConcurrentHashMap<>())
                  .put(userId, variant);
    }
    
    @Override
    public String getAllocation(String experimentId, String userId) {
        if (experimentId == null || experimentId.trim().isEmpty()) {
            return null;
        }
        if (userId == null || userId.trim().isEmpty()) {
            return null;
        }
        
        ConcurrentMap<String, String> experimentAllocations = allocations.get(experimentId);
        if (experimentAllocations == null) {
            return null;
        }
        return experimentAllocations.get(userId);
    }
    
    @Override
    public Map<String, String> getAllAllocations(String experimentId) {
        if (experimentId == null || experimentId.trim().isEmpty()) {
            return Collections.emptyMap();
        }
        
        ConcurrentMap<String, String> experimentAllocations = allocations.get(experimentId);
        if (experimentAllocations == null) {
            return Collections.emptyMap();
        }
        return Collections.unmodifiableMap(new ConcurrentHashMap<>(experimentAllocations));
    }
    
    @Override
    public void clearAllocations(String experimentId) {
        if (experimentId == null || experimentId.trim().isEmpty()) {
            return;
        }
        allocations.remove(experimentId);
    }
    
    @Override
    public void removeAllocation(String experimentId, String userId) {
        if (experimentId == null || experimentId.trim().isEmpty()) {
            return;
        }
        if (userId == null || userId.trim().isEmpty()) {
            return;
        }
        
        ConcurrentMap<String, String> experimentAllocations = allocations.get(experimentId);
        if (experimentAllocations != null) {
            experimentAllocations.remove(userId);
            if (experimentAllocations.isEmpty()) {
                allocations.remove(experimentId);
            }
        }
    }
    
    /**
     * 清除所有分配结果（主要用于测试）。
     */
    public void clear() {
        allocations.clear();
    }
}

