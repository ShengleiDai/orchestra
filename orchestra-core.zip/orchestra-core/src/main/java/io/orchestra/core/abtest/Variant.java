package io.orchestra.core.abtest;

import java.util.Objects;

/**
 * A/B 测试变体。
 * 
 * <p>表示一个 A/B 测试的变体，包含变体名称和对应的流量比例。</p>
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
public class Variant {
    
    private final String name;
    private final double weight;  // 权重，0.0 到 1.0 之间
    
    /**
     * 创建变体。
     * 
     * @param name 变体名称
     * @param weight 权重（0.0 到 1.0 之间）
     * @throws IllegalArgumentException 如果 name 为空或 weight 不在有效范围内
     */
    public Variant(String name, double weight) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Variant name cannot be null or empty");
        }
        if (weight < 0.0 || weight > 1.0) {
            throw new IllegalArgumentException("Variant weight must be between 0.0 and 1.0");
        }
        this.name = name.trim();
        this.weight = weight;
    }
    
    /**
     * 获取变体名称。
     * 
     * @return 变体名称
     */
    public String getName() {
        return name;
    }
    
    /**
     * 获取权重。
     * 
     * @return 权重（0.0 到 1.0 之间）
     */
    public double getWeight() {
        return weight;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Variant variant = (Variant) o;
        return Double.compare(variant.weight, weight) == 0 &&
               Objects.equals(name, variant.name);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(name, weight);
    }
    
    @Override
    public String toString() {
        return "Variant{" +
               "name='" + name + '\'' +
               ", weight=" + weight +
               '}';
    }
}

