package io.orchestra.core;

/**
 * 业务流程接口，代表一个完整的业务流程定义。
 * 
 * <p>Procedure 是 Orchestra 框架的核心接口，用于定义业务流程。
 * 通过实现此接口，可以将业务逻辑组织成清晰的、可复用的流程单元。</p>
 * 
 * <p>泛型参数说明：</p>
 * <ul>
 *   <li>R: 请求类型，表示流程的输入</li>
 *   <li>S: 响应类型，表示流程的输出</li>
 *   <li>T: 运行时上下文类型，必须继承自 RuntimeContext&lt;R, S&gt;</li>
 * </ul>
 * 
 * <p>使用示例：</p>
 * <pre>{@code
 * public class OrderCreationProcedure implements Procedure<OrderRequest, OrderResponse, OrderContext> {
 *     @Override
 *     public Procedurable<OrderContext> execute(OrderContext context, Composer composer) {
 *         return composer.just(context)
 *             .sync(this::validateOrder)
 *             .async(this::processPayment)
 *             .sync(this::finalizeOrder);
 *     }
 * }
 * }</pre>
 * 
 * @param <R> 请求类型
 * @param <S> 响应类型
 * @param <T> 运行时上下文类型，必须继承自 RuntimeContext&lt;R, S&gt;
 * @author Orchestra Team
 * @since 1.0.0
 */
public interface Procedure<R, S, T extends RuntimeContext<R, S>> {
    
    /**
     * 执行业务流程。
     * 
     * <p>此方法是流程定义的入口点，通过 Composer 提供的 DSL 来定义流程步骤。
     * 流程的执行是延迟的，只有在 Applicator 调用时才会真正执行。</p>
     * 
     * @param context 运行时上下文，包含请求和流程状态信息
     * @param composer 流程编织器，用于构建流程 DSL
     * @return 可执行的流程对象，用于后续的链式调用
     */
    Procedurable<T> execute(T context, Composer composer);
}

