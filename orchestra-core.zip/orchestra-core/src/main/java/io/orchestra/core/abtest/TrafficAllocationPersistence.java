package io.orchestra.core.abtest;

import java.util.Map;

/**
 * 流量分配持久化接口。
 * 
 * <p>用于持久化流量分配结果，确保同一用户/设备始终分配到同一变体。</p>
 * 
 * <p>框架默认提供内存实现，用户可以实现此接口以支持数据库、Redis 等持久化方案。</p>
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
public interface TrafficAllocationPersistence {
    
    /**
     * 保存流量分配结果。
     * 
     * @param experimentId 实验 ID
     * @param userId 用户 ID（或其他唯一标识）
     * @param variant 分配的变体名称
     */
    void saveAllocation(String experimentId, String userId, String variant);
    
    /**
     * 获取流量分配结果。
     * 
     * @param experimentId 实验 ID
     * @param userId 用户 ID（或其他唯一标识）
     * @return 分配的变体名称，如果未分配则返回 null
     */
    String getAllocation(String experimentId, String userId);
    
    /**
     * 获取实验的所有分配结果。
     * 
     * @param experimentId 实验 ID
     * @return 用户 ID 到变体名称的映射
     */
    Map<String, String> getAllAllocations(String experimentId);
    
    /**
     * 删除实验的所有分配结果。
     * 
     * @param experimentId 实验 ID
     */
    void clearAllocations(String experimentId);
    
    /**
     * 删除指定用户的分配结果。
     * 
     * @param experimentId 实验 ID
     * @param userId 用户 ID
     */
    void removeAllocation(String experimentId, String userId);
}

