package io.orchestra.core.impl;

import io.orchestra.core.Case;
import io.orchestra.core.Procedure;
import io.orchestra.core.ProcedureCase;
import io.orchestra.core.Procedurable;
import io.orchestra.core.ProcedureManager;
import io.orchestra.core.RuntimeContext;
import io.orchestra.core.abtest.Variant;
import io.orchestra.core.config.BackpressureStrategy;
import io.orchestra.core.config.CircuitBreakerConfig;
import io.orchestra.core.config.RateLimiterConfig;
import io.orchestra.core.eventbus.Event;
import io.orchestra.core.statemachine.StateMachine;
import io.orchestra.core.statemachine.StateMachineBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * 流程步骤的内部表示。
 * 
 * <p>ProcedureStep 用于存储流程中的单个步骤信息，包括步骤类型和执行逻辑。
 * 这是流程执行引擎的内部实现细节。</p>
 * 
 * @param <T> 运行时上下文类型
 * @author Orchestra Team
 * @since 1.0.0
 */
class ProcedureStep<T extends RuntimeContext<?, ?>> {
    
    /**
     * 步骤类型枚举。
     */
    enum StepType {
        SYNC_CONSUMER,      // 同步 Consumer 步骤
        SYNC_FUNCTION,      // 同步 Function 步骤
        SYNC_PROCEDURE,     // 同步 Procedure 步骤
        ASYNC_SUPPLIER,     // 异步 Supplier 步骤
        ASYNC_FUNCTION,     // 异步 Function 步骤
        ASYNC_PROCEDURE,    // 异步 Procedure 步骤
        PARALLEL,          // 并行执行步骤
        PARALLEL_PROCEDURE, // 并行执行 Procedure 步骤
        BRANCH,            // 条件分支步骤
        BRANCH_SINGLE,     // 单分支条件步骤
        BRANCH_PROCEDURE,  // 条件分支 Procedure 步骤（双分支）
        BRANCH_PROCEDURE_SINGLE, // 条件分支 Procedure 步骤（单分支）
        ERROR_RETRY,       // 错误重试步骤
        ERROR_RESUME,      // 错误降级步骤
        ERROR_RESUME_PROCEDURE, // 错误降级 Procedure 步骤
        ERROR_HANDLER,     // 错误处理步骤
        TIMEOUT,           // 超时控制步骤
        TIMEOUT_PROCEDURE, // 超时控制 Procedure 步骤
        SAGA_START,        // Saga 事务开始
        SAGA_END,          // Saga 事务结束
        COMPENSATION,      // 补偿操作步骤
        CIRCUIT_BREAKER,   // 熔断器步骤
        BULKHEAD,          // 隔离舱步骤
        RATE_LIMITER,      // 限流器步骤
        BACKPRESSURE,      // 背压策略步骤
        STATE_MACHINE,     // 状态机步骤
        PUBLISH_EVENT,     // 发布事件步骤
        AWAIT_EVENT,       // 等待事件步骤
        SELECT,            // 多分支选择步骤
        SELECT_PROCEDURE,  // 多分支选择 Procedure 步骤
        AB_TEST,           // A/B 测试步骤
        AB_TEST_PROCEDURE  // A/B 测试 Procedure 步骤
    }
    
    private final StepType type;
    private Object action;  // 存储实际的执行逻辑
    
    // 用于并行执行
    private List<Function<ProcedureManager<T>, Procedurable<T>>> parallelStreams;
    
    // 用于条件分支
    private Predicate<T> condition;
    private Function<ProcedureManager<T>, Procedurable<T>> trueBranch;
    private Function<ProcedureManager<T>, Procedurable<T>> falseBranch;
    private Function<ProcedureManager<T>, Procedurable<T>> singleBranch;
    
    // 用于错误处理
    private Class<? extends Throwable> errorType;
    private int retryCount;
    private Function<Throwable, Procedurable<T>> errorResumeHandler;
    private Consumer<T> errorHandler;
    private long timeout;
    private TimeUnit timeUnit;
    private Consumer<T> timeoutHandler;
    
    // 用于 Saga 补偿
    private Function<T, ?> compensationFunction;
    
    // 用于性能控制
    private String circuitBreakerName;
    private CircuitBreakerConfig circuitBreakerConfig;
    private String bulkheadName;
    private int bulkheadMaxConcurrency;
    private String rateLimiterName;
    private RateLimiterConfig rateLimiterConfig;
    private BackpressureStrategy backpressureStrategy;
    
    // 用于状态机
    private StateMachine<?, ?, T> stateMachine;
    private Function<StateMachineBuilder<?, ?, T>, StateMachine<?, ?, T>> stateMachineBuilder;
    private Class<?> stateType;
    
    // 用于事件发布和等待
    private Function<T, ? extends Event> eventSupplier;  // 用于发布事件
    private Class<? extends Event> awaitEventType;        // 用于等待事件
    private BiConsumer<T, Event> awaitHandler;           // 等待事件的处理函数
    private long awaitTimeoutMillis;                     // 等待超时时间（毫秒）
    
    // 用于多分支选择
    private Function<RuntimeContext<?, ?>, ?> selectValueExtractor;  // 值提取器
    private List<Case<?, T>> selectCases;                            // 分支列表
    
    // 用于 A/B 测试
    private String abTestExperimentId;                               // 实验 ID
    private Function<RuntimeContext<?, ?>, String> abTestUserIdExtractor;  // 用户 ID 提取器
    private List<Variant> abTestVariants;                            // 变体列表
    private BiFunction<String, ProcedureManager<T>, Procedurable<T>> abTestVariantHandler;  // 变体处理函数
    private List<Procedure<?, ?, T>> abTestProcedures;                // A/B 测试 Procedure 列表
    
    // 用于 Procedure 步骤
    private Procedure<?, ?, T> procedure;                           // Procedure 实例
    private List<Procedure<?, ?, T>> parallelProcedures;             // 并行 Procedure 列表
    private Procedure<?, ?, T> trueProcedure;                        // 分支 true Procedure
    private Procedure<?, ?, T> falseProcedure;                       // 分支 false Procedure
    private Procedure<?, ?, T> singleProcedure;                      // 单分支 Procedure
    private Procedure<?, ?, T> fallbackProcedure;                    // 降级 Procedure
    private Procedure<?, ?, T> timeoutProcedure;                     // 超时处理 Procedure
    private List<ProcedureCase<?, ?, ?, T>> selectProcedureCases;    // select Procedure cases
    
    /**
     * 创建同步 Consumer 步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> syncConsumer(Consumer<T> consumer) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.SYNC_CONSUMER);
        step.action = consumer;
        return step;
    }
    
    /**
     * 创建同步 Function 步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> syncFunction(Function<T, ?> function) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.SYNC_FUNCTION);
        step.action = function;
        return step;
    }
    
    /**
     * 创建异步 Supplier 步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> asyncSupplier(Supplier<?> supplier) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.ASYNC_SUPPLIER);
        step.action = supplier;
        return step;
    }
    
    /**
     * 创建异步 Function 步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> asyncFunction(Function<T, CompletableFuture<?>> function) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.ASYNC_FUNCTION);
        step.action = function;
        return step;
    }
    
    /**
     * 创建并行执行步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> parallel(
            List<Function<ProcedureManager<T>, Procedurable<T>>> streams) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.PARALLEL);
        step.parallelStreams = streams;
        return step;
    }
    
    /**
     * 创建双分支条件步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> branch(
            Predicate<T> condition,
            Function<ProcedureManager<T>, Procedurable<T>> trueBranch,
            Function<ProcedureManager<T>, Procedurable<T>> falseBranch) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.BRANCH);
        step.condition = condition;
        step.trueBranch = trueBranch;
        step.falseBranch = falseBranch;
        return step;
    }
    
    /**
     * 创建单分支条件步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> branchSingle(
            Predicate<T> condition,
            Function<ProcedureManager<T>, Procedurable<T>> branch) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.BRANCH_SINGLE);
        step.condition = condition;
        step.singleBranch = branch;
        return step;
    }
    
    private ProcedureStep(StepType type) {
        this.type = type;
    }
    
    StepType getType() {
        return type;
    }
    
    @SuppressWarnings("unchecked")
    Consumer<T> getConsumer() {
        return (Consumer<T>) action;
    }
    
    @SuppressWarnings("unchecked")
    Function<T, ?> getFunction() {
        return (Function<T, ?>) action;
    }
    
    @SuppressWarnings("unchecked")
    Supplier<?> getSupplier() {
        return (Supplier<?>) action;
    }
    
    @SuppressWarnings("unchecked")
    Function<T, CompletableFuture<?>> getAsyncFunction() {
        return (Function<T, CompletableFuture<?>>) action;
    }
    
    List<Function<ProcedureManager<T>, Procedurable<T>>> getParallelStreams() {
        return parallelStreams;
    }
    
    Predicate<T> getCondition() {
        return condition;
    }
    
    Function<ProcedureManager<T>, Procedurable<T>> getTrueBranch() {
        return trueBranch;
    }
    
    Function<ProcedureManager<T>, Procedurable<T>> getFalseBranch() {
        return falseBranch;
    }
    
    Function<ProcedureManager<T>, Procedurable<T>> getSingleBranch() {
        return singleBranch;
    }
    
    /**
     * 创建错误重试步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> errorRetry(
            Class<? extends Throwable> errorType, int retryCount) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.ERROR_RETRY);
        step.errorType = errorType;
        step.retryCount = retryCount;
        return step;
    }
    
    /**
     * 创建错误降级步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> errorResume(
            Class<? extends Throwable> errorType,
            Function<Throwable, Procedurable<T>> handler) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.ERROR_RESUME);
        step.errorType = errorType;
        step.errorResumeHandler = handler;
        return step;
    }
    
    /**
     * 创建错误处理步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> errorHandler(
            Class<? extends Throwable> errorType,
            Consumer<T> handler) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.ERROR_HANDLER);
        step.errorType = errorType;
        step.errorHandler = handler;
        return step;
    }
    
    /**
     * 创建超时控制步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> timeout(
            long timeout, TimeUnit timeUnit, Consumer<T> handler) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.TIMEOUT);
        step.timeout = timeout;
        step.timeUnit = timeUnit;
        step.timeoutHandler = handler;
        return step;
    }
    
    Class<? extends Throwable> getErrorType() {
        return errorType;
    }
    
    int getRetryCount() {
        return retryCount;
    }
    
    Function<Throwable, Procedurable<T>> getErrorResumeHandler() {
        return errorResumeHandler;
    }
    
    Consumer<T> getErrorHandler() {
        return errorHandler;
    }
    
    long getTimeout() {
        return timeout;
    }
    
    TimeUnit getTimeUnit() {
        return timeUnit;
    }
    
    Consumer<T> getTimeoutHandler() {
        return timeoutHandler;
    }
    
    /**
     * 创建 Saga 开始步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> sagaStart() {
        return new ProcedureStep<>(StepType.SAGA_START);
    }
    
    /**
     * 创建 Saga 结束步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> sagaEnd() {
        return new ProcedureStep<>(StepType.SAGA_END);
    }
    
    /**
     * 创建补偿操作步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> compensation(Function<T, ?> compensationFunction) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.COMPENSATION);
        step.compensationFunction = compensationFunction;
        return step;
    }
    
    Function<T, ?> getCompensationFunction() {
        return compensationFunction;
    }
    
    /**
     * 创建熔断器步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> circuitBreaker(
            String name, CircuitBreakerConfig config) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.CIRCUIT_BREAKER);
        step.circuitBreakerName = name;
        step.circuitBreakerConfig = config;
        return step;
    }
    
    /**
     * 创建隔离舱步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> bulkhead(
            String name, int maxConcurrency) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.BULKHEAD);
        step.bulkheadName = name;
        step.bulkheadMaxConcurrency = maxConcurrency;
        return step;
    }
    
    /**
     * 创建限流器步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> rateLimiter(
            String name, RateLimiterConfig config) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.RATE_LIMITER);
        step.rateLimiterName = name;
        step.rateLimiterConfig = config;
        return step;
    }
    
    /**
     * 创建背压策略步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> backpressure(
            BackpressureStrategy strategy) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.BACKPRESSURE);
        step.backpressureStrategy = strategy;
        return step;
    }
    
    String getCircuitBreakerName() {
        return circuitBreakerName;
    }
    
    CircuitBreakerConfig getCircuitBreakerConfig() {
        return circuitBreakerConfig;
    }
    
    String getBulkheadName() {
        return bulkheadName;
    }
    
    int getBulkheadMaxConcurrency() {
        return bulkheadMaxConcurrency;
    }
    
    String getRateLimiterName() {
        return rateLimiterName;
    }
    
    RateLimiterConfig getRateLimiterConfig() {
        return rateLimiterConfig;
    }
    
    BackpressureStrategy getBackpressureStrategy() {
        return backpressureStrategy;
    }
    
    /**
     * 创建状态机步骤。
     */
    static <T extends RuntimeContext<?, ?>, State, Event> ProcedureStep<T> stateMachine(
            Class<State> stateType,
            Function<StateMachineBuilder<State, Event, T>, StateMachine<State, Event, T>> builder) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.STATE_MACHINE);
        step.stateType = stateType;
        @SuppressWarnings("unchecked")
        Function<StateMachineBuilder<?, ?, T>, StateMachine<?, ?, T>> builderWrapper = 
            (Function<StateMachineBuilder<?, ?, T>, StateMachine<?, ?, T>>) (Function<?, ?>) builder;
        step.stateMachineBuilder = builderWrapper;
        return step;
    }
    
    StateMachine<?, ?, T> getStateMachine() {
        return stateMachine;
    }
    
    void setStateMachine(StateMachine<?, ?, T> stateMachine) {
        this.stateMachine = stateMachine;
    }
    
    Function<StateMachineBuilder<?, ?, T>, StateMachine<?, ?, T>> getStateMachineBuilder() {
        return stateMachineBuilder;
    }
    
    Class<?> getStateType() {
        return stateType;
    }
    
    /**
     * 创建发布事件步骤。
     */
    static <T extends RuntimeContext<?, ?>, E extends Event> ProcedureStep<T> publishEvent(
            Function<T, E> eventSupplier) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.PUBLISH_EVENT);
        @SuppressWarnings("unchecked")
        Function<T, ? extends Event> supplier = (Function<T, ? extends Event>) eventSupplier;
        step.eventSupplier = supplier;
        return step;
    }
    
    /**
     * 创建等待事件步骤。
     */
    static <T extends RuntimeContext<?, ?>, E extends Event> ProcedureStep<T> awaitEvent(
            Class<E> eventType,
            BiConsumer<T, E> handler,
            long timeoutMillis) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.AWAIT_EVENT);
        @SuppressWarnings("unchecked")
        Class<? extends Event> type = (Class<? extends Event>) eventType;
        step.awaitEventType = type;
        @SuppressWarnings("unchecked")
        BiConsumer<T, Event> handlerWrapper = (BiConsumer<T, Event>) (BiConsumer<?, ?>) handler;
        step.awaitHandler = handlerWrapper;
        step.awaitTimeoutMillis = timeoutMillis;
        return step;
    }
    
    /**
     * 创建多分支选择步骤。
     */
    static <T extends RuntimeContext<?, ?>, V> ProcedureStep<T> select(
            Function<T, V> valueExtractor,
            List<Case<V, T>> cases) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.SELECT);
        @SuppressWarnings("unchecked")
        Function<RuntimeContext<?, ?>, ?> extractor = (Function<RuntimeContext<?, ?>, ?>) valueExtractor;
        step.selectValueExtractor = extractor;
        @SuppressWarnings("unchecked")
        List<Case<?, T>> caseList = (List<Case<?, T>>) (List<?>) cases;
        step.selectCases = new java.util.ArrayList<>(caseList);
        return step;
    }
    
    Function<T, ? extends Event> getEventSupplier() {
        return eventSupplier;
    }
    
    Class<? extends Event> getAwaitEventType() {
        return awaitEventType;
    }
    
    BiConsumer<T, Event> getAwaitHandler() {
        return awaitHandler;
    }
    
    long getAwaitTimeoutMillis() {
        return awaitTimeoutMillis;
    }
    
    Function<RuntimeContext<?, ?>, ?> getSelectValueExtractor() {
        return selectValueExtractor;
    }
    
    List<Case<?, T>> getSelectCases() {
        return selectCases;
    }
    
    /**
     * 创建 A/B 测试步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> abTest(
            String experimentId,
            Function<T, String> userIdExtractor,
            List<Variant> variants,
            BiFunction<String, ProcedureManager<T>, Procedurable<T>> variantHandler) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.AB_TEST);
        step.abTestExperimentId = experimentId;
        @SuppressWarnings("unchecked")
        Function<RuntimeContext<?, ?>, String> extractor = (Function<RuntimeContext<?, ?>, String>) userIdExtractor;
        step.abTestUserIdExtractor = extractor;
        step.abTestVariants = new ArrayList<>(variants);
        step.abTestVariantHandler = variantHandler;
        return step;
    }
    
    String getAbTestExperimentId() {
        return abTestExperimentId;
    }
    
    Function<RuntimeContext<?, ?>, String> getAbTestUserIdExtractor() {
        return abTestUserIdExtractor;
    }
    
    List<Variant> getAbTestVariants() {
        return abTestVariants;
    }
    
    BiFunction<String, ProcedureManager<T>, Procedurable<T>> getAbTestVariantHandler() {
        return abTestVariantHandler;
    }
    
    List<Procedure<?, ?, T>> getAbTestProcedures() {
        return abTestProcedures;
    }
    
    /**
     * 创建同步 Procedure 步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> syncProcedure(Procedure<?, ?, T> procedure) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.SYNC_PROCEDURE);
        step.procedure = procedure;
        return step;
    }
    
    /**
     * 创建异步 Procedure 步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> asyncProcedure(Procedure<?, ?, T> procedure) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.ASYNC_PROCEDURE);
        step.procedure = procedure;
        return step;
    }
    
    /**
     * 创建并行 Procedure 步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> parallelProcedure(
            List<Procedure<?, ?, T>> procedures) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.PARALLEL_PROCEDURE);
        step.parallelProcedures = procedures;
        return step;
    }
    
    /**
     * 创建双分支 Procedure 步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> branchProcedure(
            Predicate<T> condition,
            Procedure<?, ?, T> trueProcedure,
            Procedure<?, ?, T> falseProcedure) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.BRANCH_PROCEDURE);
        step.condition = condition;
        step.trueProcedure = trueProcedure;
        step.falseProcedure = falseProcedure;
        return step;
    }
    
    /**
     * 创建单分支 Procedure 步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> branchProcedureSingle(
            Predicate<T> condition,
            Procedure<?, ?, T> procedure) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.BRANCH_PROCEDURE_SINGLE);
        step.condition = condition;
        step.singleProcedure = procedure;
        return step;
    }
    
    /**
     * 创建错误降级 Procedure 步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> errorResumeProcedure(
            Class<? extends Throwable> errorType,
            Procedure<?, ?, T> fallbackProcedure) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.ERROR_RESUME_PROCEDURE);
        step.errorType = errorType;
        step.fallbackProcedure = fallbackProcedure;
        return step;
    }
    
    /**
     * 创建超时控制 Procedure 步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> timeoutProcedure(
            long timeout, TimeUnit timeUnit, Procedure<?, ?, T> timeoutProcedure) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.TIMEOUT_PROCEDURE);
        step.timeout = timeout;
        step.timeUnit = timeUnit;
        step.timeoutProcedure = timeoutProcedure;
        return step;
    }
    
    /**
     * 创建多分支选择 Procedure 步骤。
     */
    static <T extends RuntimeContext<?, ?>, V> ProcedureStep<T> selectProcedure(
            Function<T, V> valueExtractor,
            List<ProcedureCase<V, ?, ?, T>> cases) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.SELECT_PROCEDURE);
        @SuppressWarnings("unchecked")
        Function<RuntimeContext<?, ?>, ?> extractor = (Function<RuntimeContext<?, ?>, ?>) valueExtractor;
        step.selectValueExtractor = extractor;
        @SuppressWarnings("unchecked")
        List<ProcedureCase<?, ?, ?, T>> caseList = (List<ProcedureCase<?, ?, ?, T>>) (List<?>) cases;
        step.selectProcedureCases = caseList;
        return step;
    }
    
    /**
     * 创建 A/B 测试 Procedure 步骤。
     */
    static <T extends RuntimeContext<?, ?>> ProcedureStep<T> abTestProcedure(
            String experimentId,
            Function<T, String> userIdExtractor,
            List<Variant> variants,
            List<Procedure<?, ?, T>> procedures) {
        ProcedureStep<T> step = new ProcedureStep<>(StepType.AB_TEST_PROCEDURE);
        step.abTestExperimentId = experimentId;
        @SuppressWarnings("unchecked")
        Function<RuntimeContext<?, ?>, String> extractor = (Function<RuntimeContext<?, ?>, String>) userIdExtractor;
        step.abTestUserIdExtractor = extractor;
        step.abTestVariants = new ArrayList<>(variants);
        step.abTestProcedures = procedures;
        return step;
    }
    
    // Getters for Procedure steps
    Procedure<?, ?, T> getProcedure() {
        return procedure;
    }
    
    List<Procedure<?, ?, T>> getParallelProcedures() {
        return parallelProcedures;
    }
    
    Procedure<?, ?, T> getTrueProcedure() {
        return trueProcedure;
    }
    
    Procedure<?, ?, T> getFalseProcedure() {
        return falseProcedure;
    }
    
    Procedure<?, ?, T> getSingleProcedure() {
        return singleProcedure;
    }
    
    Procedure<?, ?, T> getFallbackProcedure() {
        return fallbackProcedure;
    }
    
    Procedure<?, ?, T> getTimeoutProcedure() {
        return timeoutProcedure;
    }
    
    List<ProcedureCase<?, ?, ?, T>> getSelectProcedureCases() {
        return selectProcedureCases;
    }
}

