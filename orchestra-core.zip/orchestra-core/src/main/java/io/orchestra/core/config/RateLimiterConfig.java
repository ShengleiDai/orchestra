package io.orchestra.core.config;

import java.time.Duration;

/**
 * 限流器配置。
 * 
 * <p>用于配置限流器的行为，包括速率限制、时间窗口等参数。</p>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
public class RateLimiterConfig {
    
    private final int limitForPeriod;          // 时间窗口内的限制数量
    private final Duration limitRefreshPeriod; // 时间窗口大小
    private final Duration timeoutDuration;    // 获取令牌的超时时间
    
    private RateLimiterConfig(Builder builder) {
        this.limitForPeriod = builder.limitForPeriod;
        this.limitRefreshPeriod = builder.limitRefreshPeriod;
        this.timeoutDuration = builder.timeoutDuration;
    }
    
    public int getLimitForPeriod() {
        return limitForPeriod;
    }
    
    public Duration getLimitRefreshPeriod() {
        return limitRefreshPeriod;
    }
    
    public Duration getTimeoutDuration() {
        return timeoutDuration;
    }
    
    /**
     * 创建默认配置。
     */
    public static RateLimiterConfig ofDefaults() {
        return new Builder()
            .limitForPeriod(100)
            .limitRefreshPeriod(Duration.ofMinutes(1))
            .timeoutDuration(Duration.ofSeconds(5))
            .build();
    }
    
    /**
     * 创建自定义配置的构建器。
     */
    public static Builder custom() {
        return new Builder();
    }
    
    /**
     * 限流器配置构建器。
     */
    public static class Builder {
        private int limitForPeriod = 100;
        private Duration limitRefreshPeriod = Duration.ofMinutes(1);
        private Duration timeoutDuration = Duration.ofSeconds(5);
        
        public Builder limitForPeriod(int limitForPeriod) {
            if (limitForPeriod <= 0) {
                throw new IllegalArgumentException("Limit for period must be positive");
            }
            this.limitForPeriod = limitForPeriod;
            return this;
        }
        
        public Builder limitRefreshPeriod(Duration limitRefreshPeriod) {
            if (limitRefreshPeriod == null || limitRefreshPeriod.isNegative() || limitRefreshPeriod.isZero()) {
                throw new IllegalArgumentException("Limit refresh period must be positive");
            }
            this.limitRefreshPeriod = limitRefreshPeriod;
            return this;
        }
        
        public Builder timeoutDuration(Duration timeoutDuration) {
            if (timeoutDuration == null || timeoutDuration.isNegative()) {
                throw new IllegalArgumentException("Timeout duration must be non-negative");
            }
            this.timeoutDuration = timeoutDuration;
            return this;
        }
        
        public RateLimiterConfig build() {
            return new RateLimiterConfig(this);
        }
    }
}

