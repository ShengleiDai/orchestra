package io.orchestra.core;

import java.util.Objects;
import java.util.function.Function;

/**
 * 分支选择辅助类。
 * 
 * <p>用于 {@link ProcedureManager#select} 方法，表示一个分支选择项。</p>
 * 
 * <p>使用示例：</p>
 * <pre>{@code
 * return composer.just(context)
 *     .select(ctx -> ctx.getOrderType(),
 *         Case.of("VIP", branch -> branch.sync(this::processVIP)),
 *         Case.of("NORMAL", branch -> branch.sync(this::processNormal)),
 *         Case.defaultCase(branch -> branch.sync(this::processDefault))
 *     );
 * }</pre>
 * 
 * @param <V> 匹配值的类型
 * @param <T> 运行时上下文类型
 * @author Orchestra Team
 * @since 2.0.0
 */
public class Case<V, T extends RuntimeContext<?, ?>> {
    
    private final V value;
    private final Function<ProcedureManager<T>, Procedurable<T>> branch;
    private final boolean isDefault;
    
    /**
     * 私有构造函数。
     * 
     * @param value 匹配值，null 表示默认分支
     * @param branch 分支处理函数
     * @param isDefault 是否为默认分支
     */
    private Case(V value, Function<ProcedureManager<T>, Procedurable<T>> branch, boolean isDefault) {
        this.value = value;
        this.branch = Objects.requireNonNull(branch, "Branch cannot be null");
        this.isDefault = isDefault;
    }
    
    /**
     * 创建值匹配分支。
     * 
     * @param value 要匹配的值
     * @param branch 分支处理函数
     * @param <V> 匹配值的类型
     * @param <T> 运行时上下文类型
     * @return Case 实例
     */
    public static <V, T extends RuntimeContext<?, ?>> Case<V, T> of(
            V value, 
            Function<ProcedureManager<T>, Procedurable<T>> branch) {
        return new Case<>(value, branch, false);
    }
    
    /**
     * 创建默认分支。
     * 
     * <p>默认分支会在没有其他分支匹配时执行。</p>
     * 
     * @param branch 分支处理函数
     * @param <V> 匹配值的类型
     * @param <T> 运行时上下文类型
     * @return Case 实例
     */
    public static <V, T extends RuntimeContext<?, ?>> Case<V, T> defaultCase(
            Function<ProcedureManager<T>, Procedurable<T>> branch) {
        return new Case<>(null, branch, true);
    }
    
    /**
     * 获取匹配值。
     * 
     * @return 匹配值，默认分支返回 null
     */
    public V getValue() {
        return value;
    }
    
    /**
     * 获取分支处理函数。
     * 
     * @return 分支处理函数
     */
    public Function<ProcedureManager<T>, Procedurable<T>> getBranch() {
        return branch;
    }
    
    /**
     * 是否为默认分支。
     * 
     * @return 如果是默认分支返回 true
     */
    public boolean isDefault() {
        return isDefault;
    }
    
    /**
     * 检查是否匹配给定的值。
     * 
     * @param targetValue 要匹配的目标值
     * @return 如果匹配返回 true
     */
    public boolean matches(V targetValue) {
        if (isDefault) {
            return true;
        }
        if (value == null) {
            return targetValue == null;
        }
        return value.equals(targetValue);
    }
}

