package io.orchestra.core.statemachine;

import java.util.List;

/**
 * 状态持久化接口。
 * 
 * <p>用于保存和恢复状态机的状态，支持状态快照和转换历史记录。</p>
 * 
 * @param <State> 状态类型
 * @param <Event> 事件类型
 * @author Orchestra Team
 * @since 2.0.0
 */
public interface StatePersistence<State, Event> {
    
    /**
     * 保存状态快照。
     * 
     * @param instanceId 状态机实例 ID
     * @param snapshot 状态快照
     */
    void saveState(String instanceId, StateMachineSnapshot<State, Event> snapshot);
    
    /**
     * 加载状态快照。
     * 
     * @param instanceId 状态机实例 ID
     * @return 状态快照，如果不存在则返回 null
     */
    StateMachineSnapshot<State, Event> loadState(String instanceId);
    
    /**
     * 删除状态快照。
     * 
     * @param instanceId 状态机实例 ID
     */
    void deleteState(String instanceId);
    
    /**
     * 保存状态转换记录。
     * 
     * @param instanceId 状态机实例 ID
     * @param transition 状态转换记录
     */
    void saveTransition(String instanceId, StateTransition<State, Event> transition);
    
    /**
     * 查询状态转换历史。
     * 
     * @param instanceId 状态机实例 ID
     * @return 状态转换历史列表，按时间顺序排列
     */
    List<StateTransition<State, Event>> getTransitionHistory(String instanceId);
    
    /**
     * 查询状态转换历史（限制数量）。
     * 
     * @param instanceId 状态机实例 ID
     * @param limit 限制数量
     * @return 状态转换历史列表，按时间顺序排列
     */
    List<StateTransition<State, Event>> getTransitionHistory(String instanceId, int limit);
}

