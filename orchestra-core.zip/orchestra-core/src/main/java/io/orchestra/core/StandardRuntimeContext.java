package io.orchestra.core;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * RuntimeContext 的标准实现类。
 * 
 * <p>StandardRuntimeContext 提供了 RuntimeContext 接口的默认实现，
 * 使用 HashMap 来存储属性，适合大多数使用场景。</p>
 * 
 * <p>使用示例：</p>
 * <pre>{@code
 * OrderContext context = new StandardRuntimeContext<>(new OrderRequest("order-123"));
 * context.setAttribute("userId", "user-456");
 * String userId = context.getAttribute("userId");
 * }</pre>
 * 
 * @param <R> 请求类型
 * @param <S> 响应类型
 * @author Orchestra Team
 * @since 1.0.0
 */
public class StandardRuntimeContext<R, S> implements RuntimeContext<R, S> {
    
    private final R request;
    private S response;
    private final Map<String, Object> attributes;
    
    /**
     * 构造一个 StandardRuntimeContext 实例。
     * 
     * @param request 请求对象，可以为 null
     */
    public StandardRuntimeContext(R request) {
        this.request = request;
        this.attributes = new HashMap<>();
    }
    
    /**
     * 构造一个 StandardRuntimeContext 实例，并初始化响应对象。
     * 
     * @param request 请求对象，可以为 null
     * @param response 响应对象，可以为 null
     */
    public StandardRuntimeContext(R request, S response) {
        this.request = request;
        this.response = response;
        this.attributes = new HashMap<>();
    }
    
    @Override
    public R getRequest() {
        return request;
    }
    
    @Override
    public S getResponse() {
        return response;
    }
    
    @Override
    public void setResponse(S response) {
        this.response = response;
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public <T> T getAttribute(String key) {
        Objects.requireNonNull(key, "Attribute key cannot be null");
        return (T) attributes.get(key);
    }
    
    @Override
    public <T> void setAttribute(String key, T value) {
        Objects.requireNonNull(key, "Attribute key cannot be null");
        if (value == null) {
            attributes.remove(key);
        } else {
            attributes.put(key, value);
        }
    }
    
    @Override
    @SuppressWarnings("unchecked")
    public <T> T removeAttribute(String key) {
        Objects.requireNonNull(key, "Attribute key cannot be null");
        return (T) attributes.remove(key);
    }
    
    @Override
    public void clearAttributes() {
        attributes.clear();
    }
    
    @Override
    public String toString() {
        return "StandardRuntimeContext{" +
                "request=" + request +
                ", response=" + response +
                ", attributes=" + attributes +
                '}';
    }
}

