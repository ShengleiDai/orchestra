package io.orchestra.core.abtest;

import java.util.List;
import java.util.Objects;

/**
 * 默认流量分配器实现。
 * 
 * <p>基于哈希的一致性分配算法，确保同一用户始终分配到同一变体。</p>
 * 
 * <p>分配算法：</p>
 * <ol>
 *   <li>首先检查持久化中是否已有分配结果，如果有则直接返回</li>
 *   <li>如果没有，则使用哈希算法计算分配</li>
 *   <li>将分配结果保存到持久化中</li>
 * </ol>
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
public class DefaultTrafficAllocator implements TrafficAllocator {
    
    @Override
    public String allocate(String experimentId, String userId, List<Variant> variants, 
                          TrafficAllocationPersistence persistence) {
        if (experimentId == null || experimentId.trim().isEmpty()) {
            throw new IllegalArgumentException("Experiment ID cannot be null or empty");
        }
        if (userId == null || userId.trim().isEmpty()) {
            throw new IllegalArgumentException("User ID cannot be null or empty");
        }
        if (variants == null || variants.isEmpty()) {
            throw new IllegalArgumentException("Variants cannot be null or empty");
        }
        if (persistence == null) {
            throw new NullPointerException("Persistence cannot be null");
        }
        
        // 验证变体配置
        if (!validateVariants(variants)) {
            throw new IllegalArgumentException("Invalid variants configuration: weights must sum to 1.0 and names must be unique");
        }
        
        // 首先检查持久化中是否已有分配结果
        String existingAllocation = persistence.getAllocation(experimentId, userId);
        if (existingAllocation != null) {
            // 验证分配的变体是否仍然存在
            for (Variant variant : variants) {
                if (variant.getName().equals(existingAllocation)) {
                    return existingAllocation;
                }
            }
            // 如果分配的变体不存在了，重新分配
        }
        
        // 使用哈希算法计算分配
        String allocatedVariant = calculateAllocation(experimentId, userId, variants);
        
        // 保存分配结果
        persistence.saveAllocation(experimentId, userId, allocatedVariant);
        
        return allocatedVariant;
    }
    
    /**
     * 使用哈希算法计算流量分配。
     * 
     * <p>算法：</p>
     * <ol>
     *   <li>计算 experimentId + userId 的哈希值</li>
     *   <li>将哈希值映射到 [0, 1) 区间</li>
     *   <li>根据变体权重区间选择变体</li>
     * </ol>
     * 
     * @param experimentId 实验 ID
     * @param userId 用户 ID
     * @param variants 变体列表
     * @return 分配的变体名称
     */
    private String calculateAllocation(String experimentId, String userId, List<Variant> variants) {
        // 计算哈希值
        String key = experimentId + ":" + userId;
        int hashCode = key.hashCode();
        
        // 将哈希值映射到 [0, 1) 区间
        // 使用 Math.abs 确保为正数，然后取模 10000 再除以 10000.0
        double hashValue = (Math.abs(hashCode) % 10000) / 10000.0;
        
        // 根据变体权重区间选择变体
        double cumulativeWeight = 0.0;
        for (Variant variant : variants) {
            cumulativeWeight += variant.getWeight();
            if (hashValue < cumulativeWeight) {
                return variant.getName();
            }
        }
        
        // 理论上不应该到达这里，但为了安全起见，返回最后一个变体
        return variants.get(variants.size() - 1).getName();
    }
}

