package io.orchestra.core;

import java.util.Objects;
import java.util.function.Function;

/**
 * 分支选择辅助类（Procedure 版本）。
 * 
 * <p>用于 {@link ProcedureManager#select} 方法，表示一个包含 Procedure 的分支选择项。</p>
 * 
 * <p>使用示例：</p>
 * <pre>{@code
 * return composer.just(context)
 *     .select(ctx -> ctx.getOrderType(),
 *         ProcedureCase.of("VIP", new VIPOrderProcedure()),
 *         ProcedureCase.of("NORMAL", new NormalOrderProcedure()),
 *         ProcedureCase.defaultCase(new DefaultOrderProcedure())
 *     );
 * }</pre>
 * 
 * @param <V> 匹配值的类型
 * @param <R> Procedure 的请求类型
 * @param <S> Procedure 的响应类型
 * @param <T> 运行时上下文类型
 * @author Orchestra Team
 * @since 2.0.0
 */
public class ProcedureCase<V, R, S, T extends RuntimeContext<?, ?>> {
    
    private final V value;
    private final Procedure<?, ?, T> procedure;
    private final boolean isDefault;
    
    /**
     * 私有构造函数。
     * 
     * @param value 匹配值，null 表示默认分支
     * @param procedure 要执行的 Procedure
     * @param isDefault 是否为默认分支
     */
    private ProcedureCase(V value, Procedure<?, ?, T> procedure, boolean isDefault) {
        this.value = value;
        this.procedure = Objects.requireNonNull(procedure, "Procedure cannot be null");
        this.isDefault = isDefault;
    }
    
    /**
     * 创建值匹配分支。
     * 
     * @param value 要匹配的值
     * @param procedure 要执行的 Procedure
     * @param <V> 匹配值的类型
     * @param <R> Procedure 的请求类型
     * @param <S> Procedure 的响应类型
     * @param <T> 运行时上下文类型
     * @return ProcedureCase 实例
     */
    public static <V, R, S, T extends RuntimeContext<?, ?>> ProcedureCase<V, R, S, T> of(
            V value, 
            Procedure<?, ?, T> procedure) {
        @SuppressWarnings("unchecked")
        ProcedureCase<V, R, S, T> result = (ProcedureCase<V, R, S, T>) new ProcedureCase<>(value, procedure, false);
        return result;
    }
    
    /**
     * 创建默认分支。
     * 
     * <p>默认分支会在没有其他分支匹配时执行。</p>
     * 
     * @param procedure 要执行的 Procedure
     * @param <V> 匹配值的类型
     * @param <R> Procedure 的请求类型
     * @param <S> Procedure 的响应类型
     * @param <T> 运行时上下文类型
     * @return ProcedureCase 实例
     */
    public static <V, R, S, T extends RuntimeContext<?, ?>> ProcedureCase<V, R, S, T> defaultCase(
            Procedure<?, ?, T> procedure) {
        @SuppressWarnings("unchecked")
        ProcedureCase<V, R, S, T> result = (ProcedureCase<V, R, S, T>) new ProcedureCase<>(null, procedure, true);
        return result;
    }
    
    /**
     * 获取匹配值。
     * 
     * @return 匹配值，默认分支返回 null
     */
    public V getValue() {
        return value;
    }
    
    /**
     * 获取 Procedure。
     * 
     * @return Procedure 实例
     */
    public Procedure<?, ?, T> getProcedure() {
        return procedure;
    }
    
    /**
     * 是否为默认分支。
     * 
     * @return 如果是默认分支返回 true
     */
    public boolean isDefault() {
        return isDefault;
    }
    
    /**
     * 检查是否匹配给定的值。
     * 
     * @param targetValue 要匹配的目标值
     * @return 如果匹配返回 true
     */
    public boolean matches(V targetValue) {
        if (isDefault) {
            return true;
        }
        if (value == null) {
            return targetValue == null;
        }
        return value.equals(targetValue);
    }
}

