package io.orchestra.core.saga;

import io.orchestra.core.RuntimeContext;

/**
 * Saga 管理器注册表。
 * 
 * <p>用于管理全局的 SagaManager 实例，支持默认实例和自定义实例。</p>
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
public class SagaManagerRegistry {
    
    private static volatile SagaManager<? extends RuntimeContext<?, ?>> defaultSagaManager;
    
    /**
     * 获取默认的 SagaManager 实例。
     * 
     * <p>如果未设置，则创建一个 LocalSagaManager 实例。</p>
     * 
     * @param <T> 运行时上下文类型
     * @return 默认的 SagaManager 实例
     */
    @SuppressWarnings("unchecked")
    public static <T extends RuntimeContext<?, ?>> SagaManager<T> getDefault() {
        if (defaultSagaManager == null) {
            synchronized (SagaManagerRegistry.class) {
                if (defaultSagaManager == null) {
                    defaultSagaManager = new LocalSagaManager<>();
                }
            }
        }
        return (SagaManager<T>) defaultSagaManager;
    }
    
    /**
     * 设置默认的 SagaManager 实例。
     * 
     * @param sagaManager SagaManager 实例
     */
    public static void setDefault(SagaManager<? extends RuntimeContext<?, ?>> sagaManager) {
        synchronized (SagaManagerRegistry.class) {
            defaultSagaManager = sagaManager;
        }
    }
    
    /**
     * 重置默认的 SagaManager 实例。
     * 
     * <p>主要用于测试。</p>
     */
    public static void reset() {
        synchronized (SagaManagerRegistry.class) {
            defaultSagaManager = null;
        }
    }
}

