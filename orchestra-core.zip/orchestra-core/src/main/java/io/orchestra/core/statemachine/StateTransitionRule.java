package io.orchestra.core.statemachine;

import io.orchestra.core.RuntimeContext;

import java.util.function.BiConsumer;
import java.util.function.Predicate;

/**
 * 状态转换规则。
 * 
 * @param <State> 状态类型
 * @param <Event> 事件类型
 * @param <T> 运行时上下文类型
 * @author Orchestra Team
 * @since 2.0.0
 */
class StateTransitionRule<State, Event, T extends RuntimeContext<?, ?>> {
    
    private final State fromState;
    private final Class<? extends Event> eventType;
    private final State toState;
    private Predicate<T> condition;
    private BiConsumer<T, Event> action;
    
    public StateTransitionRule(State fromState, Class<? extends Event> eventType, State toState) {
        if (fromState == null) {
            throw new NullPointerException("From state cannot be null");
        }
        if (eventType == null) {
            throw new NullPointerException("Event type cannot be null");
        }
        if (toState == null) {
            throw new NullPointerException("To state cannot be null");
        }
        this.fromState = fromState;
        this.eventType = eventType;
        this.toState = toState;
    }
    
    public State getFromState() {
        return fromState;
    }
    
    public Class<? extends Event> getEventType() {
        return eventType;
    }
    
    public State getToState() {
        return toState;
    }
    
    public Predicate<T> getCondition() {
        return condition;
    }
    
    public void setCondition(Predicate<T> condition) {
        this.condition = condition;
    }
    
    public BiConsumer<T, Event> getAction() {
        return action;
    }
    
    public void setAction(BiConsumer<T, Event> action) {
        this.action = action;
    }
    
    /**
     * 检查是否匹配该转换规则。
     */
    public boolean matches(State currentState, Event event, T context) {
        if (!fromState.equals(currentState)) {
            return false;
        }
        if (!eventType.isInstance(event)) {
            return false;
        }
        if (condition != null && !condition.test(context)) {
            return false;
        }
        return true;
    }
}

