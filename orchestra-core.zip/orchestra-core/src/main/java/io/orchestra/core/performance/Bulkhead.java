package io.orchestra.core.performance;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * 隔离舱实现。
 * 
 * <p>用于限制并发执行数量，防止资源耗尽。</p>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
public class Bulkhead {
    
    private final String name;
    private final Semaphore semaphore;
    private final int maxConcurrency;
    
    public Bulkhead(String name, int maxConcurrency) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Bulkhead name cannot be null or empty");
        }
        if (maxConcurrency <= 0) {
            throw new IllegalArgumentException("Max concurrency must be positive");
        }
        this.name = name;
        this.maxConcurrency = maxConcurrency;
        this.semaphore = new Semaphore(maxConcurrency);
    }
    
    /**
     * 尝试执行操作。
     * 
     * @param operation 要执行的操作
     * @return 操作结果
     * @throws BulkheadFullException 如果隔离舱已满
     */
    public <T> T execute(java.util.function.Supplier<T> operation) {
        if (!semaphore.tryAcquire()) {
            throw new BulkheadFullException("Bulkhead is full: " + name + " (max: " + maxConcurrency + ")");
        }
        
        try {
            return operation.get();
        } finally {
            semaphore.release();
        }
    }
    
    /**
     * 执行操作（带超时）。
     */
    public <T> T execute(java.util.function.Supplier<T> operation, long timeout, TimeUnit unit) {
        try {
            if (!semaphore.tryAcquire(timeout, unit)) {
                throw new BulkheadFullException("Bulkhead acquire timeout: " + name);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new BulkheadFullException("Bulkhead acquire interrupted: " + name, e);
        }
        
        try {
            return operation.get();
        } finally {
            semaphore.release();
        }
    }
    
    /**
     * 执行操作（无返回值）。
     */
    public void execute(Runnable operation) {
        execute(() -> {
            operation.run();
            return null;
        });
    }
    
    public String getName() {
        return name;
    }
    
    public int getMaxConcurrency() {
        return maxConcurrency;
    }
    
    public int getAvailablePermits() {
        return semaphore.availablePermits();
    }
    
    /**
     * 隔离舱已满异常。
     */
    public static class BulkheadFullException extends RuntimeException {
        public BulkheadFullException(String message) {
            super(message);
        }
        
        public BulkheadFullException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}

