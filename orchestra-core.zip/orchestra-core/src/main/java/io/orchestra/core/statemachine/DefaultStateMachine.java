package io.orchestra.core.statemachine;

import io.orchestra.core.RuntimeContext;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;

/**
 * 状态机默认实现。
 * 
 * @param <State> 状态类型
 * @param <Event> 事件类型
 * @param <T> 运行时上下文类型
 * @author Orchestra Team
 * @since 2.0.0
 */
class DefaultStateMachine<State, Event, T extends RuntimeContext<?, ?>> implements StateMachine<State, Event, T> {
    
    private final State initialState;
    private final List<StateTransitionRule<State, Event, T>> transitionRules;
    private final java.util.Set<State> terminalStates;
    private final BiConsumer<T, Event> globalAction;
    private final StatePersistence<State, Event> persistence;
    private final String instanceId;
    
    private volatile State currentState;  // 使用 volatile 保证可见性
    private StateMachineSnapshot<State, Event> snapshot;
    private final ReentrantLock transitionLock = new ReentrantLock();  // 状态转换锁
    
    public DefaultStateMachine(
            State initialState,
            List<StateTransitionRule<State, Event, T>> transitionRules,
            java.util.Set<State> terminalStates,
            BiConsumer<T, Event> globalAction,
            StatePersistence<State, Event> persistence,
            String instanceId) {
        
        this.initialState = initialState;
        this.transitionRules = new ArrayList<>(transitionRules);
        this.terminalStates = new java.util.HashSet<>(terminalStates);
        this.globalAction = globalAction;
        this.persistence = persistence;
        this.instanceId = instanceId != null ? instanceId : UUID.randomUUID().toString();
        
        // 初始化状态
        this.currentState = initialState;
        
        // 尝试从持久化中恢复状态
        restoreState();
    }
    
    @Override
    public State getCurrentState() {
        return currentState;
    }
    
    @Override
    public State transition(T context, Event event) {
        if (context == null) {
            throw new NullPointerException("Context cannot be null");
        }
        if (event == null) {
            throw new NullPointerException("Event cannot be null");
        }
        
        // 使用锁保证状态转换的原子性
        transitionLock.lock();
        try {
            // 重新加载状态快照以获取最新版本（乐观锁检查）
            StateMachineSnapshot<State, Event> latestSnapshot = persistence.loadState(instanceId);
            if (latestSnapshot != null) {
                // 检查版本冲突
                if (snapshot != null && latestSnapshot.getVersion() > snapshot.getVersion()) {
                    // 检测到并发修改，更新本地状态
                    this.snapshot = latestSnapshot;
                    this.currentState = latestSnapshot.getCurrentState();
                } else if (snapshot == null) {
                    // 首次加载
                    this.snapshot = latestSnapshot;
                    this.currentState = latestSnapshot.getCurrentState();
                }
            } else if (snapshot == null) {
                // 创建初始快照
                snapshot = new StateMachineSnapshot<>(instanceId, initialState);
                persistence.saveState(instanceId, snapshot);
            }
            
            // 检查是否在终止状态
            if (isTerminalState(currentState)) {
                throw new IllegalStateException("Cannot transition from terminal state: " + currentState);
            }
            
            // 查找匹配的转换规则
            StateTransitionRule<State, Event, T> matchedRule = null;
            for (StateTransitionRule<State, Event, T> rule : transitionRules) {
                if (rule.matches(currentState, event, context)) {
                    matchedRule = rule;
                    break;
                }
            }
            
            if (matchedRule == null) {
                throw new IllegalStateException(
                    String.format("No transition rule found for state %s with event %s", 
                                 currentState, event.getClass().getSimpleName()));
            }
            
            State fromState = currentState;
            State toState = matchedRule.getToState();
            int expectedVersion = snapshot.getVersion();
            
            try {
                // 执行转换动作
                if (matchedRule.getAction() != null) {
                    matchedRule.getAction().accept(context, event);
                }
                
                // 执行全局动作
                if (globalAction != null) {
                    globalAction.accept(context, event);
                }
                
                // 再次检查版本（双重检查，防止在动作执行期间状态被修改）
                StateMachineSnapshot<State, Event> finalCheckSnapshot = persistence.loadState(instanceId);
                if (finalCheckSnapshot != null && finalCheckSnapshot.getVersion() > expectedVersion) {
                    // 版本冲突，说明在转换过程中状态被其他线程修改
                    throw new IllegalStateException(
                        String.format("State transition conflict: expected version %d, but current version is %d. " +
                                     "State may have been modified by another thread during transition execution.",
                                     expectedVersion, finalCheckSnapshot.getVersion()));
                }
                
                // 使用乐观锁更新状态
                if (!snapshot.updateWithVersion(expectedVersion, toState)) {
                    // 版本冲突（虽然已经检查过，但双重保险）
                    throw new IllegalStateException(
                        String.format("State transition conflict: expected version %d, but current version is %d.",
                                     expectedVersion, snapshot.getVersion()));
                }
                
                // 更新当前状态
                currentState = toState;
                
                // 保存状态转换记录
                StateTransition<State, Event> transition = new StateTransition<>(
                    instanceId, fromState, toState, event);
                transition.setSuccess(true);
                persistence.saveTransition(instanceId, transition);
                
                // 保存状态快照（带版本检查）
                saveStateWithVersionCheck(context, expectedVersion);
                
                return toState;
                
            } catch (Exception e) {
                // 记录失败的转换
                StateTransition<State, Event> transition = new StateTransition<>(
                    instanceId, fromState, toState, event);
                transition.setSuccess(false);
                transition.setErrorMessage(e.getMessage());
                persistence.saveTransition(instanceId, transition);
                
                throw new RuntimeException("State transition failed", e);
            }
        } finally {
            transitionLock.unlock();
        }
    }
    
    @Override
    public boolean canTransition(State fromState, Event event) {
        if (fromState == null || event == null) {
            return false;
        }
        
        // 创建临时上下文用于条件检查
        // 注意：这里无法真正检查条件，只能检查是否有匹配的规则
        for (StateTransitionRule<State, Event, T> rule : transitionRules) {
            if (rule.getFromState().equals(fromState) && 
                rule.getEventType().isInstance(event)) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public List<State> getPossibleNextStates(State currentState) {
        return transitionRules.stream()
            .filter(rule -> rule.getFromState().equals(currentState))
            .map(StateTransitionRule::getToState)
            .distinct()
            .collect(Collectors.toList());
    }
    
    @Override
    public boolean isTerminalState(State state) {
        return terminalStates.contains(state);
    }
    
    @Override
    public State getInitialState() {
        return initialState;
    }
    
    @Override
    public String getInstanceId() {
        return instanceId;
    }
    
    /**
     * 保存状态快照。
     */
    private void saveState(T context) {
        if (snapshot == null) {
            snapshot = new StateMachineSnapshot<>(instanceId, currentState);
        } else {
            snapshot.setCurrentState(currentState);
            snapshot.incrementVersion();
        }
        
        // 保存上下文数据
        // 注意：这里简化处理，实际可能需要序列化上下文
        java.util.Map<String, Object> contextData = new java.util.HashMap<>();
        // 可以保存关键属性到 contextData
        snapshot.setContextData(contextData);
        
        persistence.saveState(instanceId, snapshot);
    }
    
    /**
     * 保存状态快照（带版本检查）。
     */
    private void saveStateWithVersionCheck(T context, int expectedVersion) {
        // 创建新的快照副本以避免并发修改
        StateMachineSnapshot<State, Event> snapshotToSave = new StateMachineSnapshot<>();
        snapshotToSave.setInstanceId(instanceId);
        snapshotToSave.setCurrentState(currentState);
        snapshotToSave.setVersion(snapshot.getVersion());
        snapshotToSave.setTimestamp(snapshot.getTimestamp());
        
        // 保存上下文数据
        java.util.Map<String, Object> contextData = new java.util.HashMap<>();
        // 可以保存关键属性到 contextData
        snapshotToSave.setContextData(contextData);
        
        persistence.saveState(instanceId, snapshotToSave);
        
        // 更新本地快照引用
        this.snapshot = snapshotToSave;
    }
    
    /**
     * 从持久化中恢复状态。
     */
    private void restoreState() {
        StateMachineSnapshot<State, Event> savedSnapshot = persistence.loadState(instanceId);
        if (savedSnapshot != null) {
            this.snapshot = savedSnapshot;
            this.currentState = savedSnapshot.getCurrentState();
        } else {
            // 创建初始快照
            snapshot = new StateMachineSnapshot<>(instanceId, initialState);
            persistence.saveState(instanceId, snapshot);
        }
    }
}

