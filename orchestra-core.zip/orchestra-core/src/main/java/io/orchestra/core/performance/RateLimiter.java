package io.orchestra.core.performance;

import io.orchestra.core.config.RateLimiterConfig;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 限流器实现（基于令牌桶算法）。
 * 
 * <p>用于限制请求速率，防止系统过载。</p>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
public class RateLimiter {
    
    private final String name;
    private final RateLimiterConfig config;
    
    private final AtomicInteger tokens;
    private final AtomicLong lastRefillTime;
    private final long refillPeriodMillis;
    private final int tokensPerPeriod;
    
    public RateLimiter(String name, RateLimiterConfig config) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Rate limiter name cannot be null or empty");
        }
        if (config == null) {
            throw new NullPointerException("Rate limiter config cannot be null");
        }
        this.name = name;
        this.config = config;
        this.tokensPerPeriod = config.getLimitForPeriod();
        this.refillPeriodMillis = config.getLimitRefreshPeriod().toMillis();
        this.tokens = new AtomicInteger(tokensPerPeriod);
        this.lastRefillTime = new AtomicLong(System.currentTimeMillis());
    }
    
    /**
     * 尝试获取令牌并执行操作。
     * 
     * @param operation 要执行的操作
     * @return 操作结果
     * @throws RateLimitExceededException 如果限流器已满
     */
    public <T> T execute(java.util.function.Supplier<T> operation) {
        if (!tryAcquire()) {
            throw new RateLimitExceededException("Rate limit exceeded: " + name);
        }
        
        try {
            return operation.get();
        } catch (Exception e) {
            // 操作失败，不释放令牌（令牌已被消耗）
            throw e;
        }
    }
    
    /**
     * 执行操作（无返回值）。
     */
    public void execute(Runnable operation) {
        execute(() -> {
            operation.run();
            return null;
        });
    }
    
    /**
     * 尝试获取令牌。
     * 
     * @return 如果成功获取令牌返回 true，否则返回 false
     */
    private boolean tryAcquire() {
        refillTokens();
        
        int current;
        do {
            current = tokens.get();
            if (current <= 0) {
                return false;
            }
        } while (!tokens.compareAndSet(current, current - 1));
        
        return true;
    }
    
    /**
     * 补充令牌。
     */
    private void refillTokens() {
        long now = System.currentTimeMillis();
        long lastRefill = lastRefillTime.get();
        long elapsed = now - lastRefill;
        
        if (elapsed >= refillPeriodMillis) {
            // 计算应该补充的令牌数
            int periods = (int) (elapsed / refillPeriodMillis);
            int tokensToAdd = periods * tokensPerPeriod;
            
            if (tokensToAdd > 0) {
                int current;
                int newValue;
                do {
                    current = tokens.get();
                    newValue = Math.min(current + tokensToAdd, tokensPerPeriod);
                } while (!tokens.compareAndSet(current, newValue));
                
                lastRefillTime.set(now);
            }
        }
    }
    
    public String getName() {
        return name;
    }
    
    public int getAvailableTokens() {
        refillTokens();
        return tokens.get();
    }
    
    /**
     * 限流异常。
     */
    public static class RateLimitExceededException extends RuntimeException {
        public RateLimitExceededException(String message) {
            super(message);
        }
    }
}

