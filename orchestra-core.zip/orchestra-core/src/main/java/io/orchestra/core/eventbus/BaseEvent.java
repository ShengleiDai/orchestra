package io.orchestra.core.eventbus;

import java.util.UUID;

/**
 * 事件基类，提供默认实现。
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
public abstract class BaseEvent implements Event {
    
    private final String eventId;
    private final long timestamp;
    
    public BaseEvent() {
        this.eventId = UUID.randomUUID().toString();
        this.timestamp = System.currentTimeMillis();
    }
    
    public BaseEvent(String eventId) {
        this.eventId = eventId != null ? eventId : UUID.randomUUID().toString();
        this.timestamp = System.currentTimeMillis();
    }
    
    @Override
    public String getEventId() {
        return eventId;
    }
    
    @Override
    public long getTimestamp() {
        return timestamp;
    }
    
    @Override
    public String toString() {
        return getClass().getSimpleName() + "{" +
                "eventId='" + eventId + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }
}

