package io.orchestra.core;

/**
 * 运行时上下文接口，封装流程执行期间的上下文信息。
 * 
 * <p>RuntimeContext 是 Orchestra 框架的核心抽象，用于在流程执行过程中传递和存储状态信息。
 * 它支持泛型参数，分别表示请求类型（R）和响应类型（S）。</p>
 * 
 * <p>主要功能包括：</p>
 * <ul>
 *   <li>Request/Response 管理：存储和访问请求、响应对象</li>
 *   <li>属性管理：支持动态属性的存储、获取和删除</li>
 * </ul>
 * 
 * @param <R> 请求类型
 * @param <S> 响应类型
 * @author Orchestra Team
 * @since 1.0.0
 */
public interface RuntimeContext<R, S> {
    
    /**
     * 获取请求对象。
     * 
     * @return 请求对象，可能为 null
     */
    R getRequest();
    
    /**
     * 获取响应对象。
     * 
     * @return 响应对象，可能为 null
     */
    S getResponse();
    
    /**
     * 设置响应对象。
     * 
     * @param response 响应对象
     */
    void setResponse(S response);
    
    /**
     * 获取指定键的属性值。
     * 
     * @param <T> 属性值的类型
     * @param key 属性键，不能为 null
     * @return 属性值，如果不存在则返回 null
     * @throws ClassCastException 如果属性值的类型与期望的类型不匹配
     */
    <T> T getAttribute(String key);
    
    /**
     * 设置指定键的属性值。
     * 
     * @param <T> 属性值的类型
     * @param key 属性键，不能为 null
     * @param value 属性值，可以为 null
     */
    <T> void setAttribute(String key, T value);
    
    /**
     * 移除指定键的属性。
     * 
     * @param <T> 属性值的类型
     * @param key 属性键，不能为 null
     * @return 被移除的属性值，如果不存在则返回 null
     */
    <T> T removeAttribute(String key);
    
    /**
     * 清空所有属性。
     */
    void clearAttributes();
}

