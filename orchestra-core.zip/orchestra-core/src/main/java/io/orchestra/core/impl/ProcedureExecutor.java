package io.orchestra.core.impl;

import io.orchestra.core.Case;
import io.orchestra.core.Composer;
import io.orchestra.core.Procedure;
import io.orchestra.core.ProcedureCase;
import io.orchestra.core.Procedurable;
import io.orchestra.core.ProcedureManager;
import io.orchestra.core.RuntimeContext;
import io.orchestra.core.abtest.TrafficAllocator;
import io.orchestra.core.abtest.TrafficAllocationPersistence;
import io.orchestra.core.abtest.TrafficAllocatorRegistry;
import io.orchestra.core.abtest.Variant;
import io.orchestra.core.eventbus.Event;
import io.orchestra.core.performance.Bulkhead;
import io.orchestra.core.performance.CircuitBreaker;
import io.orchestra.core.performance.PerformanceControlRegistry;
import io.orchestra.core.performance.RateLimiter;
import io.orchestra.core.saga.SagaManager;
import io.orchestra.core.saga.SagaManagerRegistry;
import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.schedulers.Schedulers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * 流程步骤执行器。
 * 
 * <p>ProcedureExecutor 负责执行流程步骤列表，支持同步、异步、并行和分支等操作。</p>
 * 
 * @param <T> 运行时上下文类型
 * @author Orchestra Team
 * @since 1.0.0
 */
public class ProcedureExecutor<T extends RuntimeContext<?, ?>> {
    
    private SagaManager<T> sagaManager;
    
    /**
     * 构造一个 ProcedureExecutor 实例，使用默认的 SagaManager。
     */
    public ProcedureExecutor() {
        this.sagaManager = SagaManagerRegistry.getDefault();
    }
    
    /**
     * 构造一个 ProcedureExecutor 实例，使用指定的 SagaManager。
     * 
     * @param sagaManager Saga 事务管理器
     */
    public ProcedureExecutor(SagaManager<T> sagaManager) {
        this.sagaManager = sagaManager != null ? sagaManager : SagaManagerRegistry.getDefault();
    }
    
    /**
     * 设置 SagaManager 实例。
     * 
     * @param sagaManager Saga 事务管理器
     */
    public void setSagaManager(SagaManager<T> sagaManager) {
        this.sagaManager = sagaManager != null ? sagaManager : SagaManagerRegistry.getDefault();
    }
    
    /**
     * 获取 SagaManager 实例。
     * 
     * @return Saga 事务管理器
     */
    public SagaManager<T> getSagaManager() {
        return sagaManager;
    }
    
    /**
     * 执行流程步骤列表。
     * 
     * @param steps 步骤列表
     * @param context 运行时上下文
     * @param manager 流程管理器，用于创建子管理器
     */
    public void executeSteps(List<ProcedureStep<T>> steps, T context, DefaultProcedureManager<T> manager) {
        // 从上下文获取或使用默认的 SagaManager
        SagaManager<T> sagaManager = getSagaManager(context);
        String sagaId = null;
        
        int i = 0;
        while (i < steps.size()) {
            ProcedureStep<T> step = steps.get(i);
            
            // 处理 Saga 步骤
            if (step.getType() == ProcedureStep.StepType.SAGA_START) {
                sagaId = sagaManager.startSaga(context);
                i++;
                continue;
            }
            
            if (step.getType() == ProcedureStep.StepType.SAGA_END) {
                if (sagaId != null) {
                    sagaManager.endSaga(context, sagaId);
                    sagaId = null;
                }
                i++;
                continue;
            }
            
            // 处理补偿操作步骤
            if (step.getType() == ProcedureStep.StepType.COMPENSATION) {
                // 补偿操作应该注册到前一个步骤
                // 这里跳过，补偿操作会在执行前一个步骤时注册
                i++;
                continue;
            }
            
            // 检查是否是错误处理步骤或性能控制步骤
            if (isErrorHandlingStep(step) || isPerformanceControlStep(step)) {
                // 这些步骤应该应用到前一个步骤
                // 如果前一个步骤已经执行，这里跳过这些步骤
                // 因为它们会在执行前一个步骤时被应用
                i++;
                continue;
            }
            
            // 检查后续是否有错误处理步骤、性能控制步骤和补偿操作
            List<ProcedureStep<T>> errorHandlers = collectErrorHandlers(steps, i);
            List<ProcedureStep<T>> performanceControls = collectPerformanceControls(steps, i);
            ProcedureStep<T> compensationStep = findCompensationStep(steps, i);
            
            // 执行步骤（带错误处理和性能控制）
            try {
                executeStepWithPerformanceControl(step, context, manager, errorHandlers, performanceControls);
                
                // 步骤成功执行后，如果后续有补偿操作，注册它
                if (compensationStep != null && sagaId != null && sagaManager.isInSaga(context, sagaId)) {
                    @SuppressWarnings("unchecked")
                    Function<T, ?> compensation = 
                        (Function<T, ?>) compensationStep.getCompensationFunction();
                    sagaManager.registerCompensation(context, sagaId, compensation);
                }
            } catch (Throwable e) {
                // 如果 Saga 事务中发生错误，执行补偿操作
                if (sagaId != null && sagaManager.isInSaga(context, sagaId)) {
                    sagaManager.executeCompensations(context, sagaId, e);
                }
                throw e;
            }
            
            // 跳过已应用的错误处理步骤、性能控制步骤和补偿步骤
            int skipCount = 1 + errorHandlers.size() + performanceControls.size();
            if (compensationStep != null) {
                skipCount++;
            }
            i += skipCount;
        }
    }
    
    /**
     * 获取 SagaManager 实例。
     * 
     * <p>首先尝试从上下文获取，如果没有则使用默认的。</p>
     * 
     * @param context 运行时上下文
     * @return SagaManager 实例
     */
    private SagaManager<T> getSagaManager(T context) {
        // 首先尝试从上下文获取
        Object sagaManagerObj = context.getAttribute("sagaManager");
        if (sagaManagerObj instanceof SagaManager) {
            @SuppressWarnings("unchecked")
            SagaManager<T> manager = (SagaManager<T>) sagaManagerObj;
            return manager;
        }
        
        // 使用实例字段或默认的
        return this.sagaManager != null ? this.sagaManager : SagaManagerRegistry.getDefault();
    }
    
    /**
     * 检查是否是错误处理步骤。
     */
    private boolean isErrorHandlingStep(ProcedureStep<T> step) {
        ProcedureStep.StepType type = step.getType();
        return type == ProcedureStep.StepType.ERROR_RETRY ||
               type == ProcedureStep.StepType.ERROR_RESUME ||
               type == ProcedureStep.StepType.ERROR_RESUME_PROCEDURE ||
               type == ProcedureStep.StepType.ERROR_HANDLER ||
               type == ProcedureStep.StepType.TIMEOUT ||
               type == ProcedureStep.StepType.TIMEOUT_PROCEDURE;
    }
    
    /**
     * 检查是否是性能控制步骤。
     */
    private boolean isPerformanceControlStep(ProcedureStep<T> step) {
        ProcedureStep.StepType type = step.getType();
        return type == ProcedureStep.StepType.CIRCUIT_BREAKER ||
               type == ProcedureStep.StepType.BULKHEAD ||
               type == ProcedureStep.StepType.RATE_LIMITER ||
               type == ProcedureStep.StepType.BACKPRESSURE;
    }
    
    /**
     * 收集后续的性能控制步骤。
     */
    private List<ProcedureStep<T>> collectPerformanceControls(List<ProcedureStep<T>> steps, int currentIndex) {
        List<ProcedureStep<T>> controls = new java.util.ArrayList<>();
        for (int i = currentIndex + 1; i < steps.size(); i++) {
            ProcedureStep<T> step = steps.get(i);
            if (isPerformanceControlStep(step)) {
                controls.add(step);
            } else if (isErrorHandlingStep(step)) {
                // 跳过错误处理步骤，继续查找性能控制步骤
                continue;
            } else {
                // 遇到其他类型的步骤，停止收集
                break;
            }
        }
        return controls;
    }
    
    /**
     * 执行步骤（带性能控制和错误处理）。
     */
    private void executeStepWithPerformanceControl(
            ProcedureStep<T> step,
            T context,
            DefaultProcedureManager<T> manager,
            List<ProcedureStep<T>> errorHandlers,
            List<ProcedureStep<T>> performanceControls) {
        
        // 应用性能控制
        java.util.function.Supplier<Object> operation = () -> {
            executeStepWithErrorHandling(step, context, manager, errorHandlers);
            return new Object();
        };
        
        // 按顺序应用性能控制：熔断器 -> 隔离舱 -> 限流器
        for (ProcedureStep<T> control : performanceControls) {
            if (control.getType() == ProcedureStep.StepType.CIRCUIT_BREAKER) {
                CircuitBreaker circuitBreaker = PerformanceControlRegistry.getInstance()
                    .getOrCreateCircuitBreaker(control.getCircuitBreakerName(), control.getCircuitBreakerConfig());
                operation = () -> {
                    circuitBreaker.execute(() -> {
                        executeStepWithErrorHandling(step, context, manager, errorHandlers);
                        return new Object();
                    });
                    return new Object();
                };
            } else if (control.getType() == ProcedureStep.StepType.BULKHEAD) {
                Bulkhead bulkhead = PerformanceControlRegistry.getInstance()
                    .getOrCreateBulkhead(control.getBulkheadName(), control.getBulkheadMaxConcurrency());
                final java.util.function.Supplier<Object> prevOperation = operation;
                operation = () -> {
                    bulkhead.execute(() -> {
                        prevOperation.get();
                        return new Object();
                    });
                    return new Object();
                };
            } else if (control.getType() == ProcedureStep.StepType.RATE_LIMITER) {
                RateLimiter rateLimiter = PerformanceControlRegistry.getInstance()
                    .getOrCreateRateLimiter(control.getRateLimiterName(), control.getRateLimiterConfig());
                final java.util.function.Supplier<Object> prevOperation = operation;
                operation = () -> {
                    rateLimiter.execute(() -> {
                        prevOperation.get();
                        return new Object();
                    });
                    return new Object();
                };
            }
            // 背压策略在异步操作中处理，这里暂时跳过
        }
        
        // 执行操作
        operation.get();
    }
    
    /**
     * 查找后续的补偿操作步骤。
     * 
     * <p>补偿操作应该紧跟在可执行步骤之后，可能在错误处理步骤之后。
     * 例如：.sync(...).onErrorRetry(...).withCompensation(...)</p>
     */
    private ProcedureStep<T> findCompensationStep(List<ProcedureStep<T>> steps, int currentIndex) {
        // 从下一个位置开始查找
        int nextIndex = currentIndex + 1;
        while (nextIndex < steps.size()) {
            ProcedureStep<T> step = steps.get(nextIndex);
            if (step.getType() == ProcedureStep.StepType.COMPENSATION) {
                return step;
            }
            if (isErrorHandlingStep(step)) {
                // 跳过错误处理步骤，继续查找补偿操作
                nextIndex++;
                continue;
            }
            // 遇到其他类型的步骤（如 SAGA_START, SAGA_END, 或其他可执行步骤），停止查找
            break;
        }
        return null;
    }
    
    /**
     * 收集后续的错误处理步骤。
     */
    private List<ProcedureStep<T>> collectErrorHandlers(List<ProcedureStep<T>> steps, int currentIndex) {
        List<ProcedureStep<T>> handlers = new java.util.ArrayList<>();
        for (int i = currentIndex + 1; i < steps.size(); i++) {
            ProcedureStep<T> step = steps.get(i);
            if (isErrorHandlingStep(step)) {
                handlers.add(step);
            } else {
                // 遇到非错误处理步骤，停止收集
                break;
            }
        }
        return handlers;
    }
    
    /**
     * 执行步骤（带错误处理）。
     */
    private void executeStepWithErrorHandling(
            ProcedureStep<T> step, 
            T context, 
            DefaultProcedureManager<T> manager,
            List<ProcedureStep<T>> errorHandlers) {
        
        // 跳过超时步骤（超时会在执行时应用）
        List<ProcedureStep<T>> nonTimeoutHandlers = new java.util.ArrayList<>();
        ProcedureStep<T> timeoutStep = null;
        for (ProcedureStep<T> handler : errorHandlers) {
            if (handler.getType() == ProcedureStep.StepType.TIMEOUT || 
                handler.getType() == ProcedureStep.StepType.TIMEOUT_PROCEDURE) {
                timeoutStep = handler;
            } else {
                nonTimeoutHandlers.add(handler);
            }
        }
        
        // 检查是否有重试处理
        ProcedureStep<T> retryStep = findRetryHandler(nonTimeoutHandlers);
        
        if (retryStep != null) {
            // 有重试处理，执行带重试的步骤
            executeStepWithRetry(step, context, manager, retryStep, timeoutStep, nonTimeoutHandlers);
        } else {
            // 没有重试处理，正常执行
            try {
                // 检查是否有超时控制
                if (timeoutStep != null) {
                    executeStepWithTimeout(step, context, manager, timeoutStep);
                } else {
                    executeStep(step, context, manager);
                }
            } catch (Throwable e) {
                // 处理异常
                handleError(e, context, manager, nonTimeoutHandlers);
            }
        }
    }
    
    /**
     * 查找超时处理步骤。
     */
    private ProcedureStep<T> findTimeoutHandler(List<ProcedureStep<T>> handlers) {
        for (ProcedureStep<T> handler : handlers) {
            if (handler.getType() == ProcedureStep.StepType.TIMEOUT ||
                handler.getType() == ProcedureStep.StepType.TIMEOUT_PROCEDURE) {
                return handler;
            }
        }
        return null;
    }
    
    /**
     * 查找重试处理步骤。
     */
    private ProcedureStep<T> findRetryHandler(List<ProcedureStep<T>> handlers) {
        for (ProcedureStep<T> handler : handlers) {
            if (handler.getType() == ProcedureStep.StepType.ERROR_RETRY) {
                return handler;
            }
        }
        return null;
    }
    
    /**
     * 执行步骤（带重试）。
     */
    private void executeStepWithRetry(
            ProcedureStep<T> step,
            T context,
            DefaultProcedureManager<T> manager,
            ProcedureStep<T> retryStep,
            ProcedureStep<T> timeoutStep,
            List<ProcedureStep<T>> errorHandlers) {
        
        int retryCount = retryStep.getRetryCount();
        Class<? extends Throwable> errorType = retryStep.getErrorType();
        
        // 移除重试步骤，避免重复处理
        List<ProcedureStep<T>> otherHandlers = new java.util.ArrayList<>(errorHandlers);
        otherHandlers.remove(retryStep);
        
        // 执行重试
        for (int i = 0; i <= retryCount; i++) { // 包括初始执行
            try {
                // 检查是否有超时控制
                if (timeoutStep != null) {
                    executeStepWithTimeout(step, context, manager, timeoutStep);
                } else {
                    executeStep(step, context, manager);
                }
                // 执行成功，返回
                return;
            } catch (Throwable e) {
                // 检查异常类型是否匹配
                if (!matchesErrorType(e, errorType)) {
                    // 异常类型不匹配，不再重试，处理错误
                    handleError(e, context, manager, otherHandlers);
                    return;
                }
                
                // 重试失败
                if (i == retryCount) {
                    // 最后一次重试失败，处理错误
                    handleError(e, context, manager, otherHandlers);
                }
                // 继续重试
            }
        }
    }
    
    /**
     * 执行步骤（带超时控制）。
     */
    private void executeStepWithTimeout(
            ProcedureStep<T> step,
            T context,
            DefaultProcedureManager<T> manager,
            ProcedureStep<T> timeoutStep) {
        
        long timeout = timeoutStep.getTimeout();
        TimeUnit timeUnit = timeoutStep.getTimeUnit();
        
        try {
            // 使用 RXJava 的 Single 来实现超时控制
            Single.fromCallable(() -> {
                executeStep(step, context, manager);
                return new Object();
            })
            .subscribeOn(Schedulers.io())
            .timeout(timeout, timeUnit)
            .blockingGet();
        } catch (RuntimeException e) {
            // 检查是否是超时异常
            Throwable cause = e.getCause();
            if (cause instanceof TimeoutException) {
                // 超时处理
                handleTimeout(timeoutStep, context, manager);
                throw new RuntimeException("Step execution timeout", cause);
            }
            throw e;
        } catch (Exception e) {
            // 处理其他异常
            if (e instanceof TimeoutException) {
                // 超时处理
                handleTimeout(timeoutStep, context, manager);
                throw new RuntimeException("Step execution timeout", e);
            }
            throw new RuntimeException("Failed to execute step with timeout", e);
        }
    }
    
    /**
     * 处理超时。
     */
    private void handleTimeout(ProcedureStep<T> timeoutStep, T context, DefaultProcedureManager<T> manager) {
        if (timeoutStep.getType() == ProcedureStep.StepType.TIMEOUT) {
            Consumer<T> timeoutHandler = timeoutStep.getTimeoutHandler();
            if (timeoutHandler != null) {
                timeoutHandler.accept(context);
            }
        } else if (timeoutStep.getType() == ProcedureStep.StepType.TIMEOUT_PROCEDURE) {
            Procedure<?, ?, T> timeoutProcedure = timeoutStep.getTimeoutProcedure();
            if (timeoutProcedure != null) {
                // 获取 Composer
                Composer composer = manager.getComposer();
                
                // 执行超时处理 Procedure
                Procedurable<T> procedurable = timeoutProcedure.execute(context, composer);
                
                if (procedurable instanceof DefaultProcedureManager) {
                    @SuppressWarnings("unchecked")
                    DefaultProcedureManager<T> timeoutManager = (DefaultProcedureManager<T>) procedurable;
                    ProcedureExecutor<T> executor = new ProcedureExecutor<>();
                    executor.executeSteps(timeoutManager.getSteps(), context, timeoutManager);
                }
            }
        }
    }
    
    /**
     * 处理错误。
     */
    private void handleError(
            Throwable error,
            T context,
            DefaultProcedureManager<T> manager,
            List<ProcedureStep<T>> errorHandlers) {
        
        // 将异常存储到上下文中
        context.setAttribute("exception", error);
        
        // 按顺序检查错误处理步骤
        for (ProcedureStep<T> handler : errorHandlers) {
            if (matchesErrorType(error, handler.getErrorType())) {
                switch (handler.getType()) {
                    case ERROR_RETRY:
                        // 重试已经在 executeStepWithRetry 中处理
                        // 这里不应该到达，如果到达说明逻辑有问题
                        throw new IllegalStateException("Retry should be handled in executeStepWithRetry method");
                    case ERROR_RESUME:
                        handleErrorResume(error, context, manager, handler);
                        return; // 降级后返回，不抛出异常
                    case ERROR_RESUME_PROCEDURE:
                        handleErrorResumeProcedure(error, context, manager, handler);
                        return; // 降级后返回，不抛出异常
                    case ERROR_HANDLER:
                        handleErrorHandler(error, context, handler);
                        // 错误处理后，继续检查其他错误处理步骤
                        // 注意：onError 不会阻止异常传播，除非处理函数抛出新的异常
                        break;
                    default:
                        break;
                }
            }
        }
        
        // 如果没有匹配的错误处理，或者错误处理没有阻止异常传播，抛出异常
        if (error instanceof RuntimeException) {
            throw (RuntimeException) error;
        } else {
            throw new RuntimeException(error);
        }
    }
    
    /**
     * 检查异常类型是否匹配。
     */
    private boolean matchesErrorType(Throwable error, Class<? extends Throwable> errorType) {
        return errorType != null && errorType.isAssignableFrom(error.getClass());
    }
    
    
    /**
     * 处理错误降级。
     */
    private void handleErrorResume(
            Throwable error,
            T context,
            DefaultProcedureManager<T> manager,
            ProcedureStep<T> resumeStep) {
        
        Function<Throwable, Procedurable<T>> fallbackHandler = resumeStep.getErrorResumeHandler();
        if (fallbackHandler != null) {
            Procedurable<T> fallback = fallbackHandler.apply(error);
            if (fallback instanceof DefaultProcedureManager) {
                @SuppressWarnings("unchecked")
                DefaultProcedureManager<T> fallbackManager = (DefaultProcedureManager<T>) fallback;
                ProcedureExecutor<T> executor = new ProcedureExecutor<>();
                executor.executeSteps(fallbackManager.getSteps(), context, fallbackManager);
            }
        }
    }
    
    /**
     * 处理错误降级（Procedure 版本）。
     */
    private void handleErrorResumeProcedure(
            Throwable error,
            T context,
            DefaultProcedureManager<T> manager,
            ProcedureStep<T> resumeStep) {
        
        Procedure<?, ?, T> fallbackProcedure = resumeStep.getFallbackProcedure();
        if (fallbackProcedure == null) {
            throw new IllegalStateException("Fallback procedure is null");
        }
        
        // 获取 Composer
        Composer composer = manager.getComposer();
        
        // 执行降级 Procedure
        Procedurable<T> procedurable = fallbackProcedure.execute(context, composer);
        
        if (procedurable instanceof DefaultProcedureManager) {
            @SuppressWarnings("unchecked")
            DefaultProcedureManager<T> fallbackManager = (DefaultProcedureManager<T>) procedurable;
            ProcedureExecutor<T> executor = new ProcedureExecutor<>();
            executor.executeSteps(fallbackManager.getSteps(), context, fallbackManager);
        }
    }
    
    /**
     * 处理错误处理。
     */
    private void handleErrorHandler(
            Throwable error,
            T context,
            ProcedureStep<T> handlerStep) {
        
        Consumer<T> handler = handlerStep.getErrorHandler();
        if (handler != null) {
            handler.accept(context);
        }
    }
    
    /**
     * 执行单个步骤。
     */
    private void executeStep(ProcedureStep<T> step, T context, DefaultProcedureManager<T> manager) {
        switch (step.getType()) {
            case SYNC_CONSUMER:
                executeSyncConsumer(step, context);
                break;
            case SYNC_FUNCTION:
                executeSyncFunction(step, context);
                break;
            case SYNC_PROCEDURE:
                executeSyncProcedure(step, context, manager);
                break;
            case ASYNC_SUPPLIER:
                executeAsyncSupplier(step, context);
                break;
            case ASYNC_FUNCTION:
                executeAsyncFunction(step, context);
                break;
            case ASYNC_PROCEDURE:
                executeAsyncProcedure(step, context, manager);
                break;
            case PARALLEL:
                executeParallel(step, context, manager);
                break;
            case PARALLEL_PROCEDURE:
                executeParallelProcedure(step, context, manager);
                break;
            case BRANCH:
                executeBranch(step, context, manager);
                break;
            case BRANCH_SINGLE:
                executeBranchSingle(step, context, manager);
                break;
            case BRANCH_PROCEDURE:
                executeBranchProcedure(step, context, manager);
                break;
            case BRANCH_PROCEDURE_SINGLE:
                executeBranchProcedureSingle(step, context, manager);
                break;
            case ERROR_RETRY:
            case ERROR_RESUME:
            case ERROR_RESUME_PROCEDURE:
            case ERROR_HANDLER:
            case TIMEOUT:
            case TIMEOUT_PROCEDURE:
                // 错误处理步骤在 executeStepWithErrorHandling 中处理
                break;
            case SAGA_START:
            case SAGA_END:
            case COMPENSATION:
                // Saga 步骤在 executeSteps 中处理
                break;
            case CIRCUIT_BREAKER:
            case BULKHEAD:
            case RATE_LIMITER:
            case BACKPRESSURE:
                // 性能控制步骤在 executeStepWithPerformanceControl 中处理
                break;
            case STATE_MACHINE:
                executeStateMachine(step, context);
                break;
            case PUBLISH_EVENT:
                executePublishEvent(step, context);
                break;
            case AWAIT_EVENT:
                executeAwaitEvent(step, context);
                break;
            case SELECT:
                executeSelect(step, context, manager);
                break;
            case SELECT_PROCEDURE:
                executeSelectProcedure(step, context, manager);
                break;
            case AB_TEST:
                executeAbTest(step, context, manager);
                break;
            case AB_TEST_PROCEDURE:
                executeAbTestProcedure(step, context, manager);
                break;
            default:
                throw new IllegalStateException("Unknown step type: " + step.getType());
        }
    }
    
    /**
     * 执行同步 Consumer 步骤。
     */
    private void executeSyncConsumer(ProcedureStep<T> step, T context) {
        step.getConsumer().accept(context);
    }
    
    /**
     * 执行同步 Function 步骤。
     */
    private void executeSyncFunction(ProcedureStep<T> step, T context) {
        step.getFunction().apply(context);
    }
    
    /**
     * 执行异步 Supplier 步骤。
     */
    private void executeAsyncSupplier(ProcedureStep<T> step, T context) {
        // 使用 RXJava 的 Single 来执行异步操作
        // 确保返回非 null 值
        Object result = Single.fromSupplier(() -> {
            Object value = step.getSupplier().get();
            return value != null ? value : new Object(); // 如果为 null，返回一个占位对象
        })
        .subscribeOn(Schedulers.io())
        .blockingGet();
    }
    
    /**
     * 执行异步 Function 步骤。
     */
    private void executeAsyncFunction(ProcedureStep<T> step, T context) {
        try {
            CompletableFuture<?> future = step.getAsyncFunction().apply(context);
            if (future != null) {
                future.get(); // 等待异步操作完成
            }
        } catch (InterruptedException | ExecutionException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Failed to execute async function", e);
        }
    }
    
    /**
     * 执行并行步骤。
     */
    private void executeParallel(ProcedureStep<T> step, T context, DefaultProcedureManager<T> manager) {
        List<Function<ProcedureManager<T>, Procedurable<T>>> streams = step.getParallelStreams();
        
        // 创建多个 Single，每个对应一个并行流
        @SuppressWarnings("unchecked")
        Single<?>[] singles = streams.stream()
                .map(streamBuilder -> {
                    ProcedureManager<T> subManager = manager.createSubManager();
                    Procedurable<T> procedurable = streamBuilder.apply(subManager);
                    return Single.fromCallable(() -> {
                        if (procedurable instanceof DefaultProcedureManager) {
                            @SuppressWarnings("unchecked")
                            DefaultProcedureManager<T> subProcManager = (DefaultProcedureManager<T>) procedurable;
                            ProcedureExecutor<T> executor = new ProcedureExecutor<>();
                            executor.executeSteps(subProcManager.getSteps(), context, subProcManager);
                        }
                        return new Object(); // 返回非 null 值
                    }).subscribeOn(Schedulers.io());
                })
                .toArray(Single[]::new);
        
        // 等待所有并行流完成
        Single.zipArray(args -> new Object(), singles)
                .blockingGet();
    }
    
    /**
     * 执行双分支步骤。
     */
    private void executeBranch(ProcedureStep<T> step, T context, DefaultProcedureManager<T> manager) {
        boolean condition = step.getCondition().test(context);
        Function<ProcedureManager<T>, Procedurable<T>> branchHandler = 
                condition ? step.getTrueBranch() : step.getFalseBranch();
        
        ProcedureManager<T> subManager = manager.createSubManager();
        Procedurable<T> procedurable = branchHandler.apply(subManager);
        
        if (procedurable instanceof DefaultProcedureManager) {
            @SuppressWarnings("unchecked")
            DefaultProcedureManager<T> subProcManager = (DefaultProcedureManager<T>) procedurable;
            ProcedureExecutor<T> executor = new ProcedureExecutor<>();
            executor.executeSteps(subProcManager.getSteps(), context, subProcManager);
        }
    }
    
    /**
     * 执行单分支步骤。
     */
    private void executeBranchSingle(ProcedureStep<T> step, T context, DefaultProcedureManager<T> manager) {
        if (step.getCondition().test(context)) {
            ProcedureManager<T> subManager = manager.createSubManager();
            Procedurable<T> procedurable = step.getSingleBranch().apply(subManager);
            
            if (procedurable instanceof DefaultProcedureManager) {
                @SuppressWarnings("unchecked")
                DefaultProcedureManager<T> subProcManager = (DefaultProcedureManager<T>) procedurable;
                ProcedureExecutor<T> executor = new ProcedureExecutor<>();
                executor.executeSteps(subProcManager.getSteps(), context, subProcManager);
            }
        }
    }
    
    /**
     * 执行状态机步骤。
     * 
     * <p>状态机步骤主要用于初始化状态机。实际的状态转换通过 StateMachineManager.trigger() 方法触发。</p>
     */
    private void executeStateMachine(ProcedureStep<T> step, T context) {
        // 状态机已经在 DefaultProcedureManager 中创建并设置
        // 这里只需要确保状态机已初始化
        // 状态转换通过 StateMachineManager.trigger() 方法触发，不在流程步骤中执行
        // 如果需要，可以在这里保存状态机引用到上下文中
        if (step.getStateMachine() != null) {
            // 状态机已创建，可以在这里执行初始化逻辑
            // 例如：保存状态机到上下文
            context.setAttribute("stateMachine", step.getStateMachine());
        }
    }
    
    /**
     * 执行发布事件步骤。
     */
    private void executePublishEvent(ProcedureStep<T> step, T context) {
        Function<T, ? extends Event> eventSupplier = step.getEventSupplier();
        if (eventSupplier == null) {
            throw new IllegalStateException("Event supplier is null");
        }
        
        // 生成事件
        Event event = eventSupplier.apply(context);
        if (event == null) {
            throw new IllegalStateException("Event supplier returned null");
        }
        
        // 获取 EventBus（从上下文或使用默认的）
        io.orchestra.core.eventbus.EventBus eventBus = getEventBus(context);
        
        // 异步发布事件（不阻塞流程）
        eventBus.publishAsync(event);
    }
    
    /**
     * 执行等待事件步骤。
     */
    private void executeAwaitEvent(ProcedureStep<T> step, T context) {
        Class<? extends Event> eventType = step.getAwaitEventType();
        BiConsumer<T, Event> handler = step.getAwaitHandler();
        long timeoutMillis = step.getAwaitTimeoutMillis();
        
        if (eventType == null) {
            throw new IllegalStateException("Event type is null");
        }
        if (handler == null) {
            throw new IllegalStateException("Event handler is null");
        }
        
        // 获取 EventBus
        io.orchestra.core.eventbus.EventBus eventBus = getEventBus(context);
        
        try {
            // 等待事件
            Event event = eventBus.await(eventType, timeoutMillis);
            
            if (event == null) {
                // 超时
                throw new java.util.concurrent.TimeoutException(
                    String.format("Timeout waiting for event: %s (timeout: %d ms)", 
                                 eventType.getSimpleName(), timeoutMillis));
            }
            
            // 处理事件
            handler.accept(context, event);
            
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Interrupted while waiting for event: " + eventType.getSimpleName(), e);
        } catch (java.util.concurrent.TimeoutException e) {
            throw new RuntimeException("Timeout waiting for event: " + eventType.getSimpleName(), e);
        }
    }
    
    /**
     * 获取 EventBus 实例。
     */
    private io.orchestra.core.eventbus.EventBus getEventBus(T context) {
        // 首先尝试从上下文获取
        Object eventBusObj = context.getAttribute("eventBus");
        if (eventBusObj instanceof io.orchestra.core.eventbus.EventBus) {
            return (io.orchestra.core.eventbus.EventBus) eventBusObj;
        }
        
        // 使用默认的 EventBus
        return io.orchestra.core.eventbus.EventBusRegistry.getDefault();
    }
    
    /**
     * 执行多分支选择步骤。
     */
    private <V> void executeSelect(ProcedureStep<T> step, T context, DefaultProcedureManager<T> manager) {
        @SuppressWarnings("unchecked")
        Function<T, V> valueExtractor = (Function<T, V>) step.getSelectValueExtractor();
        V value = valueExtractor.apply(context);
        
        @SuppressWarnings("unchecked")
        List<Case<V, T>> cases = (List<Case<V, T>>) (List<?>) step.getSelectCases();
        
        // 查找匹配的分支
        Case<V, T> matchedCase = null;
        for (Case<V, T> caseItem : cases) {
            if (caseItem.matches(value)) {
                matchedCase = caseItem;
                break;
            }
        }
        
        // 如果没有匹配的，使用默认分支
        if (matchedCase == null) {
            matchedCase = cases.stream()
                .filter(Case::isDefault)
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                    "No matching case found for value: " + value + " and no default case provided"));
        }
        
        // 执行匹配的分支
        ProcedureManager<T> subManager = manager.createSubManager();
        Procedurable<T> procedurable = matchedCase.getBranch().apply(subManager);
        
        if (procedurable instanceof DefaultProcedureManager) {
            @SuppressWarnings("unchecked")
            DefaultProcedureManager<T> subProcManager = (DefaultProcedureManager<T>) procedurable;
            ProcedureExecutor<T> executor = new ProcedureExecutor<>();
            executor.executeSteps(subProcManager.getSteps(), context, subProcManager);
        }
    }
    
    /**
     * 执行 A/B 测试步骤。
     */
    private void executeAbTest(ProcedureStep<T> step, T context, DefaultProcedureManager<T> manager) {
        String experimentId = step.getAbTestExperimentId();
        @SuppressWarnings("unchecked")
        Function<T, String> userIdExtractor = (Function<T, String>) step.getAbTestUserIdExtractor();
        String userId = userIdExtractor.apply(context);
        List<Variant> variants = step.getAbTestVariants();
        BiFunction<String, ProcedureManager<T>, Procedurable<T>> variantHandler = step.getAbTestVariantHandler();
        
        // 获取流量分配器和持久化实例
        TrafficAllocator allocator = getTrafficAllocator(context);
        TrafficAllocationPersistence persistence = getTrafficAllocationPersistence(context);
        
        // 分配流量
        String allocatedVariant = allocator.allocate(experimentId, userId, variants, persistence);
        
        // 执行对应的变体分支
        ProcedureManager<T> subManager = manager.createSubManager();
        Procedurable<T> procedurable = variantHandler.apply(allocatedVariant, subManager);
        
        if (procedurable instanceof DefaultProcedureManager) {
            @SuppressWarnings("unchecked")
            DefaultProcedureManager<T> subProcManager = (DefaultProcedureManager<T>) procedurable;
            ProcedureExecutor<T> executor = new ProcedureExecutor<>();
            executor.executeSteps(subProcManager.getSteps(), context, subProcManager);
        }
        
        // 将分配的变体保存到上下文，供后续步骤使用
        context.setAttribute("abTest:" + experimentId, allocatedVariant);
    }
    
    /**
     * 获取 TrafficAllocator 实例。
     * 
     * <p>首先尝试从上下文获取，如果没有则使用默认的。</p>
     * 
     * @param context 运行时上下文
     * @return TrafficAllocator 实例
     */
    private TrafficAllocator getTrafficAllocator(T context) {
        Object allocatorObj = context.getAttribute("trafficAllocator");
        if (allocatorObj instanceof TrafficAllocator) {
            return (TrafficAllocator) allocatorObj;
        }
        return TrafficAllocatorRegistry.getDefaultAllocator();
    }
    
    /**
     * 获取 TrafficAllocationPersistence 实例。
     * 
     * <p>首先尝试从上下文获取，如果没有则使用默认的。</p>
     * 
     * @param context 运行时上下文
     * @return TrafficAllocationPersistence 实例
     */
    private TrafficAllocationPersistence getTrafficAllocationPersistence(T context) {
        Object persistenceObj = context.getAttribute("trafficAllocationPersistence");
        if (persistenceObj instanceof TrafficAllocationPersistence) {
            return (TrafficAllocationPersistence) persistenceObj;
        }
        return TrafficAllocatorRegistry.getDefaultPersistence();
    }
    
    /**
     * 执行同步 Procedure 步骤。
     */
    private void executeSyncProcedure(ProcedureStep<T> step, T context, DefaultProcedureManager<T> manager) {
        Procedure<?, ?, T> procedure = step.getProcedure();
        if (procedure == null) {
            throw new IllegalStateException("Procedure is null");
        }
        
        // 获取 Composer（从 manager 中获取）
        Composer composer = manager.getComposer();
        
        // 执行 Procedure
        Procedurable<T> procedurable = procedure.execute(context, composer);
        
        // 如果返回的是 DefaultProcedureManager，执行其步骤
        if (procedurable instanceof DefaultProcedureManager) {
            @SuppressWarnings("unchecked")
            DefaultProcedureManager<T> subProcManager = (DefaultProcedureManager<T>) procedurable;
            ProcedureExecutor<T> executor = new ProcedureExecutor<>();
            executor.executeSteps(subProcManager.getSteps(), context, subProcManager);
        }
    }
    
    /**
     * 执行异步 Procedure 步骤。
     */
    private void executeAsyncProcedure(ProcedureStep<T> step, T context, DefaultProcedureManager<T> manager) {
        Procedure<?, ?, T> procedure = step.getProcedure();
        if (procedure == null) {
            throw new IllegalStateException("Procedure is null");
        }
        
        // 获取 Composer
        Composer composer = manager.getComposer();
        
        // 在异步线程中执行 Procedure
        try {
            CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {
                Procedurable<T> procedurable = procedure.execute(context, composer);
                
                if (procedurable instanceof DefaultProcedureManager) {
                    @SuppressWarnings("unchecked")
                    DefaultProcedureManager<T> subProcManager = (DefaultProcedureManager<T>) procedurable;
                    ProcedureExecutor<T> executor = new ProcedureExecutor<>();
                    executor.executeSteps(subProcManager.getSteps(), context, subProcManager);
                }
            });
            
            // 等待异步操作完成
            future.get();
        } catch (InterruptedException | ExecutionException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Failed to execute async procedure", e);
        }
    }
    
    /**
     * 执行并行 Procedure 步骤。
     */
    private void executeParallelProcedure(ProcedureStep<T> step, T context, DefaultProcedureManager<T> manager) {
        List<Procedure<?, ?, T>> procedures = step.getParallelProcedures();
        if (procedures == null || procedures.isEmpty()) {
            throw new IllegalStateException("Procedures list is null or empty");
        }
        
        // 获取 Composer
        Composer composer = manager.getComposer();
        
        // 创建多个 Single，每个对应一个 Procedure
        @SuppressWarnings("unchecked")
        Single<?>[] singles = procedures.stream()
                .map(procedure -> {
                    return Single.fromCallable(() -> {
                        Procedurable<T> procedurable = procedure.execute(context, composer);
                        
                        if (procedurable instanceof DefaultProcedureManager) {
                            @SuppressWarnings("unchecked")
                            DefaultProcedureManager<T> subProcManager = (DefaultProcedureManager<T>) procedurable;
                            ProcedureExecutor<T> executor = new ProcedureExecutor<>();
                            executor.executeSteps(subProcManager.getSteps(), context, subProcManager);
                        }
                        return new Object(); // 返回非 null 值
                    }).subscribeOn(Schedulers.io());
                })
                .toArray(Single[]::new);
        
        // 等待所有并行 Procedure 完成
        Single.zipArray(args -> new Object(), singles)
                .blockingGet();
    }
    
    /**
     * 执行双分支 Procedure 步骤。
     */
    private void executeBranchProcedure(ProcedureStep<T> step, T context, DefaultProcedureManager<T> manager) {
        boolean condition = step.getCondition().test(context);
        Procedure<?, ?, T> procedure = condition ? step.getTrueProcedure() : step.getFalseProcedure();
        
        if (procedure == null) {
            throw new IllegalStateException("Procedure is null");
        }
        
        // 获取 Composer
        Composer composer = manager.getComposer();
        
        // 执行选中的 Procedure
        Procedurable<T> procedurable = procedure.execute(context, composer);
        
        if (procedurable instanceof DefaultProcedureManager) {
            @SuppressWarnings("unchecked")
            DefaultProcedureManager<T> subProcManager = (DefaultProcedureManager<T>) procedurable;
            ProcedureExecutor<T> executor = new ProcedureExecutor<>();
            executor.executeSteps(subProcManager.getSteps(), context, subProcManager);
        }
    }
    
    /**
     * 执行单分支 Procedure 步骤。
     */
    private void executeBranchProcedureSingle(ProcedureStep<T> step, T context, DefaultProcedureManager<T> manager) {
        if (step.getCondition().test(context)) {
            Procedure<?, ?, T> procedure = step.getSingleProcedure();
            
            if (procedure == null) {
                throw new IllegalStateException("Procedure is null");
            }
            
            // 获取 Composer
            Composer composer = manager.getComposer();
            
            // 执行 Procedure
            Procedurable<T> procedurable = procedure.execute(context, composer);
            
            if (procedurable instanceof DefaultProcedureManager) {
                @SuppressWarnings("unchecked")
                DefaultProcedureManager<T> subProcManager = (DefaultProcedureManager<T>) procedurable;
                ProcedureExecutor<T> executor = new ProcedureExecutor<>();
                executor.executeSteps(subProcManager.getSteps(), context, subProcManager);
            }
        }
    }
    
    /**
     * 执行多分支选择 Procedure 步骤。
     */
    private <V> void executeSelectProcedure(ProcedureStep<T> step, T context, DefaultProcedureManager<T> manager) {
        @SuppressWarnings("unchecked")
        Function<T, V> valueExtractor = (Function<T, V>) step.getSelectValueExtractor();
        V value = valueExtractor.apply(context);
        
        @SuppressWarnings("unchecked")
        List<ProcedureCase<V, ?, ?, T>> cases = (List<ProcedureCase<V, ?, ?, T>>) (List<?>) step.getSelectProcedureCases();
        
        // 查找匹配的分支
        ProcedureCase<V, ?, ?, T> matchedCase = null;
        for (ProcedureCase<V, ?, ?, T> caseItem : cases) {
            if (caseItem.matches(value)) {
                matchedCase = caseItem;
                break;
            }
        }
        
        // 如果没有匹配的，使用默认分支
        if (matchedCase == null) {
            matchedCase = cases.stream()
                .filter(ProcedureCase::isDefault)
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                    "No matching case found for value: " + value + " and no default case provided"));
        }
        
        // 获取匹配的 Procedure
        Procedure<?, ?, T> procedure = matchedCase.getProcedure();
        if (procedure == null) {
            throw new IllegalStateException("Procedure in matched case is null");
        }
        
        // 获取 Composer
        Composer composer = manager.getComposer();
        
        // 执行匹配的 Procedure
        Procedurable<T> procedurable = procedure.execute(context, composer);
        
        if (procedurable instanceof DefaultProcedureManager) {
            @SuppressWarnings("unchecked")
            DefaultProcedureManager<T> subProcManager = (DefaultProcedureManager<T>) procedurable;
            ProcedureExecutor<T> executor = new ProcedureExecutor<>();
            executor.executeSteps(subProcManager.getSteps(), context, subProcManager);
        }
    }
    
    /**
     * 执行 A/B 测试 Procedure 步骤。
     */
    private void executeAbTestProcedure(ProcedureStep<T> step, T context, DefaultProcedureManager<T> manager) {
        String experimentId = step.getAbTestExperimentId();
        @SuppressWarnings("unchecked")
        Function<T, String> userIdExtractor = (Function<T, String>) step.getAbTestUserIdExtractor();
        String userId = userIdExtractor.apply(context);
        List<Variant> variants = step.getAbTestVariants();
        List<Procedure<?, ?, T>> procedures = step.getAbTestProcedures();
        
        if (procedures == null || procedures.isEmpty()) {
            throw new IllegalStateException("Procedures list is null or empty");
        }
        
        if (variants.size() != procedures.size()) {
            throw new IllegalStateException("Variants size (" + variants.size() + 
                ") does not match procedures size (" + procedures.size() + ")");
        }
        
        // 获取流量分配器和持久化实例
        TrafficAllocator allocator = getTrafficAllocator(context);
        TrafficAllocationPersistence persistence = getTrafficAllocationPersistence(context);
        
        // 分配流量
        String allocatedVariant = allocator.allocate(experimentId, userId, variants, persistence);
        
        // 找到对应的 Procedure
        int variantIndex = -1;
        for (int i = 0; i < variants.size(); i++) {
            if (variants.get(i).getName().equals(allocatedVariant)) {
                variantIndex = i;
                break;
            }
        }
        
        if (variantIndex < 0 || variantIndex >= procedures.size()) {
            throw new IllegalStateException("Invalid variant index: " + variantIndex + 
                " for variant: " + allocatedVariant);
        }
        
        Procedure<?, ?, T> procedure = procedures.get(variantIndex);
        if (procedure == null) {
            throw new IllegalStateException("Procedure at index " + variantIndex + " is null");
        }
        
        // 获取 Composer
        Composer composer = manager.getComposer();
        
        // 执行对应的 Procedure
        Procedurable<T> procedurable = procedure.execute(context, composer);
        
        if (procedurable instanceof DefaultProcedureManager) {
            @SuppressWarnings("unchecked")
            DefaultProcedureManager<T> subProcManager = (DefaultProcedureManager<T>) procedurable;
            ProcedureExecutor<T> executor = new ProcedureExecutor<>();
            executor.executeSteps(subProcManager.getSteps(), context, subProcManager);
        }
        
        // 将分配的变体保存到上下文，供后续步骤使用
        context.setAttribute("abTest:" + experimentId, allocatedVariant);
    }
}

