package io.orchestra.core.eventbus;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.*;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.function.Consumer;

/**
 * 内存事件总线实现。
 * 
 * <p>默认实现，适用于单机应用。基于内存的事件存储和分发，支持同步和异步事件发布。</p>
 * 
 * <p>生产环境如需跨进程通信，建议使用 Redis、Kafka 或 RabbitMQ 实现。</p>
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
public class InMemoryEventBus implements EventBus {
    
    // 事件订阅者映射：事件类型 -> 订阅者列表
    private final ConcurrentHashMap<Class<? extends Event>, List<Subscription>> subscribers = new ConcurrentHashMap<>();
    
    // 等待事件的队列：事件类型 -> 等待队列
    private final ConcurrentHashMap<Class<? extends Event>, BlockingQueue<Event>> awaitQueues = new ConcurrentHashMap<>();
    
    // 读写锁，用于保护订阅者列表的并发修改
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    
    // 异步执行器
    private final ExecutorService asyncExecutor;
    
    // 是否已关闭
    private volatile boolean shutdown = false;
    
    public InMemoryEventBus() {
        this(Executors.newCachedThreadPool(r -> {
            Thread t = new Thread(r, "EventBus-Async-" + UUID.randomUUID().toString().substring(0, 8));
            t.setDaemon(true);
            return t;
        }));
    }
    
    public InMemoryEventBus(ExecutorService asyncExecutor) {
        this.asyncExecutor = asyncExecutor;
    }
    
    @Override
    public void publish(Event event) throws EventBusException {
        if (event == null) {
            throw new NullPointerException("Event cannot be null");
        }
        if (shutdown) {
            throw new EventBusException("EventBus has been shut down");
        }
        
        Class<? extends Event> eventType = event.getClass();
        
        // 获取订阅者列表（读锁）
        lock.readLock().lock();
        try {
            List<Subscription> handlers = subscribers.get(eventType);
            if (handlers != null && !handlers.isEmpty()) {
                // 同步执行所有订阅者
                for (Subscription subscription : new ArrayList<>(handlers)) {
                    try {
                        @SuppressWarnings("unchecked")
                        EventHandler<Event> handler = (EventHandler<Event>) subscription.getHandler();
                        handler.handle(event);
                    } catch (Exception e) {
                        throw new EventBusException("Error handling event: " + eventType.getSimpleName(), e);
                    }
                }
            }
        } finally {
            lock.readLock().unlock();
        }
        
        // 通知等待该事件的线程
        notifyAwaiters(eventType, event);
    }
    
    @Override
    public CompletableFuture<Void> publishAsync(Event event) {
        CompletableFuture<Void> future = new CompletableFuture<>();
        
        if (event == null) {
            future.completeExceptionally(new NullPointerException("Event cannot be null"));
            return future;
        }
        if (shutdown) {
            future.completeExceptionally(new EventBusException("EventBus has been shut down"));
            return future;
        }
        
        return CompletableFuture.runAsync(() -> {
            try {
                publish(event);
            } catch (EventBusException e) {
                throw new RuntimeException(e);
            }
        }, asyncExecutor);
    }
    
    @Override
    public <E extends Event> String subscribe(Class<E> eventType, EventHandler<E> handler) {
        if (eventType == null) {
            throw new NullPointerException("Event type cannot be null");
        }
        if (handler == null) {
            throw new NullPointerException("Event handler cannot be null");
        }
        if (shutdown) {
            throw new EventBusException("EventBus has been shut down");
        }
        
        String subscriptionId = UUID.randomUUID().toString();
        Subscription subscription = new Subscription<>(subscriptionId, eventType, handler);
        
        // 添加订阅者（写锁）
        lock.writeLock().lock();
        try {
            subscribers.computeIfAbsent(eventType, k -> new CopyOnWriteArrayList<>()).add(subscription);
        } finally {
            lock.writeLock().unlock();
        }
        
        return subscriptionId;
    }
    
    @Override
    public void unsubscribe(String subscriptionId) {
        if (subscriptionId == null || subscriptionId.trim().isEmpty()) {
            return;
        }
        
        lock.writeLock().lock();
        try {
            subscribers.values().forEach(handlers -> {
                handlers.removeIf(sub -> sub.getId().equals(subscriptionId));
            });
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    @Override
    public void unsubscribe(Class<? extends Event> eventType) {
        if (eventType == null) {
            return;
        }
        
        lock.writeLock().lock();
        try {
            subscribers.remove(eventType);
        } finally {
            lock.writeLock().unlock();
        }
    }
    
    @Override
    public <E extends Event> E await(Class<E> eventType, long timeoutMillis) throws InterruptedException {
        if (eventType == null) {
            throw new NullPointerException("Event type cannot be null");
        }
        if (shutdown) {
            throw new EventBusException("EventBus has been shut down");
        }
        
        BlockingQueue<Event> queue = awaitQueues.computeIfAbsent(eventType, k -> new LinkedBlockingQueue<>());
        
        if (timeoutMillis <= 0) {
            // 无限等待
            @SuppressWarnings("unchecked")
            E event = (E) queue.take();
            return event;
        } else {
            // 超时等待
            @SuppressWarnings("unchecked")
            E event = (E) queue.poll(timeoutMillis, TimeUnit.MILLISECONDS);
            return event;
        }
    }
    
    @Override
    public void shutdown() {
        if (shutdown) {
            return;
        }
        
        shutdown = true;
        
        // 清除所有订阅者
        lock.writeLock().lock();
        try {
            subscribers.clear();
        } finally {
            lock.writeLock().unlock();
        }
        
        // 清除所有等待队列
        awaitQueues.clear();
        
        // 关闭异步执行器
        if (asyncExecutor != null && !asyncExecutor.isShutdown()) {
            asyncExecutor.shutdown();
            try {
                if (!asyncExecutor.awaitTermination(5, TimeUnit.SECONDS)) {
                    asyncExecutor.shutdownNow();
                }
            } catch (InterruptedException e) {
                asyncExecutor.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
    }
    
    /**
     * 通知等待该事件的线程。
     */
    private void notifyAwaiters(Class<? extends Event> eventType, Event event) {
        BlockingQueue<Event> queue = awaitQueues.get(eventType);
        if (queue != null) {
            queue.offer(event);
        }
    }
    
    /**
     * 订阅信息。
     */
    private static class Subscription<E extends Event> {
        private final String id;
        private final Class<E> eventType;
        private final EventHandler<E> handler;
        
        public Subscription(String id, Class<E> eventType, EventHandler<E> handler) {
            this.id = id;
            this.eventType = eventType;
            this.handler = handler;
        }
        
        public String getId() {
            return id;
        }
        
        public Class<E> getEventType() {
            return eventType;
        }
        
        public EventHandler<E> getHandler() {
            return handler;
        }
    }
}

