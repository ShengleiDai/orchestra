package io.orchestra.core.abtest;

import java.util.List;

/**
 * 流量分配器接口。
 * 
 * <p>用于将流量分配到不同的变体。框架默认提供基于哈希的分配器，
 * 用户可以实现此接口以支持自定义的分配算法。</p>
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
public interface TrafficAllocator {
    
    /**
     * 分配流量到变体。
     * 
     * <p>根据用户 ID 和变体配置，决定将流量分配到哪个变体。</p>
     * 
     * @param experimentId 实验 ID
     * @param userId 用户 ID（或其他唯一标识）
     * @param variants 变体列表
     * @param persistence 持久化接口，用于查询和保存分配结果
     * @return 分配的变体名称
     * @throws IllegalArgumentException 如果参数无效
     */
    String allocate(String experimentId, String userId, List<Variant> variants, 
                    TrafficAllocationPersistence persistence);
    
    /**
     * 验证变体配置是否有效。
     * 
     * <p>检查变体权重之和是否等于 1.0，以及是否有重复的变体名称。</p>
     * 
     * @param variants 变体列表
     * @return 如果配置有效返回 true，否则返回 false
     */
    default boolean validateVariants(List<Variant> variants) {
        if (variants == null || variants.isEmpty()) {
            return false;
        }
        
        double totalWeight = 0.0;
        java.util.Set<String> names = new java.util.HashSet<>();
        
        for (Variant variant : variants) {
            if (variant == null) {
                return false;
            }
            if (names.contains(variant.getName())) {
                return false;  // 重复的变体名称
            }
            names.add(variant.getName());
            totalWeight += variant.getWeight();
        }
        
        // 允许小的浮点误差（0.001）
        return Math.abs(totalWeight - 1.0) < 0.001;
    }
}

