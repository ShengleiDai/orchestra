package io.orchestra.core.saga;

import io.orchestra.core.RuntimeContext;

import java.util.function.Function;

/**
 * Saga 事务管理器接口。
 * 
 * <p>SagaManager 用于管理分布式事务的补偿操作。框架默认提供本地实现，
 * 用户可以通过实现此接口来集成分布式事务中间件（如 Seata、TCC 等）。</p>
 * 
 * <p>实现类应该提供线程安全的事务管理机制。</p>
 * 
 * @param <T> 运行时上下文类型
 * @author Orchestra Team
 * @since 2.0.0
 */
public interface SagaManager<T extends RuntimeContext<?, ?>> {
    
    /**
     * 开始 Saga 事务。
     * 
     * <p>标记一个 Saga 事务的开始。在此之后注册的补偿操作会在事务失败时执行。</p>
     * 
     * @param context 运行时上下文
     * @return Saga 事务 ID，用于标识和追踪事务
     */
    String startSaga(T context);
    
    /**
     * 结束 Saga 事务。
     * 
     * <p>标记 Saga 事务的结束。如果所有步骤都成功执行，则不会执行补偿操作。</p>
     * 
     * @param context 运行时上下文
     * @param sagaId Saga 事务 ID
     */
    void endSaga(T context, String sagaId);
    
    /**
     * 注册补偿操作。
     * 
     * <p>为前一个步骤注册补偿操作。补偿操作会在 Saga 事务失败时自动执行，
     * 按照与注册顺序相反的顺序执行。</p>
     * 
     * @param context 运行时上下文
     * @param sagaId Saga 事务 ID
     * @param compensationFunction 补偿操作函数
     */
    void registerCompensation(T context, String sagaId, Function<T, ?> compensationFunction);
    
    /**
     * 执行补偿操作。
     * 
     * <p>当 Saga 事务中的任何步骤失败时，会自动调用此方法执行已注册的补偿操作。</p>
     * 
     * @param context 运行时上下文
     * @param sagaId Saga 事务 ID
     * @param error 导致事务失败的错误
     */
    void executeCompensations(T context, String sagaId, Throwable error);
    
    /**
     * 检查是否在 Saga 事务中。
     * 
     * @param context 运行时上下文
     * @param sagaId Saga 事务 ID
     * @return 如果在 Saga 事务中返回 true，否则返回 false
     */
    boolean isInSaga(T context, String sagaId);
}

