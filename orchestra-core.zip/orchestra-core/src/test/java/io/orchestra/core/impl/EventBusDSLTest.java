package io.orchestra.core.impl;

import io.orchestra.core.*;
import io.orchestra.core.eventbus.BaseEvent;
import io.orchestra.core.eventbus.Event;
import io.orchestra.core.eventbus.EventBus;
import io.orchestra.core.eventbus.EventBusRegistry;
import io.orchestra.core.eventbus.InMemoryEventBus;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 事件总线 DSL 的集成测试。
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
class EventBusDSLTest {
    
    static class OrderPlacedEvent extends BaseEvent {
        private final String orderId;
        
        public OrderPlacedEvent(String orderId) {
            this.orderId = orderId;
        }
        
        public String getOrderId() {
            return orderId;
        }
    }
    
    static class PaymentCompletedEvent extends BaseEvent {
        private final String paymentId;
        private final boolean success;
        
        public PaymentCompletedEvent(String paymentId, boolean success) {
            this.paymentId = paymentId;
            this.success = success;
        }
        
        public String getPaymentId() {
            return paymentId;
        }
        
        public boolean isSuccess() {
            return success;
        }
    }
    
    private ReactiveApplicator<String, String, StandardRuntimeContext<String, String>> applicator;
    private EventBus eventBus;
    
    @BeforeEach
    void setUp() {
        eventBus = new InMemoryEventBus();
        EventBusRegistry.setDefault(eventBus);
        applicator = new ReactiveApplicator<>();
    }
    
    @AfterEach
    void tearDown() {
        EventBusRegistry.reset();
        if (eventBus != null) {
            eventBus.shutdown();
        }
    }
    
    @Test
    void testPublishEvent() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger eventReceived = new AtomicInteger(0);
        
        // 订阅事件
        eventBus.subscribe(OrderPlacedEvent.class, event -> {
            eventReceived.incrementAndGet();
        });
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> c.setAttribute("orderId", "ORDER-123"))
                .publish(c -> new OrderPlacedEvent((String) c.getAttribute("orderId")))
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> c.setAttribute("published", true));
        
        // When
        applicator.apply(context, procedure);
        
        // Then
        try {
            Thread.sleep(200); // 等待异步事件发布完成
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        assertEquals(1, eventReceived.get());
        assertTrue(Boolean.TRUE.equals(context.getAttribute("published")));
    }
    
    @Test
    void testOnEvent_Success() throws Exception {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        String orderId = "ORDER-123";
        
        // 在另一个线程中发布事件
        CountDownLatch latch = new CountDownLatch(1);
        new Thread(() -> {
            try {
                latch.await(1, TimeUnit.SECONDS);
                Thread.sleep(100);
                eventBus.publish(new PaymentCompletedEvent("PAY-456", true));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }).start();
        
        AtomicReference<String> receivedPaymentId = new AtomicReference<>();
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> c.setAttribute("orderId", orderId))
                .onEvent(PaymentCompletedEvent.class, (c, event) -> {
                    receivedPaymentId.set(event.getPaymentId());
                    c.setAttribute("paymentId", event.getPaymentId());
                    c.setAttribute("paymentSuccess", event.isSuccess());
                }, Duration.ofSeconds(5));
        
        // When
        latch.countDown();
        applicator.apply(context, procedure);
        
        // Then
        assertEquals("PAY-456", receivedPaymentId.get());
        assertEquals("PAY-456", context.getAttribute("paymentId"));
        assertTrue(Boolean.TRUE.equals(context.getAttribute("paymentSuccess")));
    }
    
    @Test
    void testOnEvent_Timeout() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .onEvent(PaymentCompletedEvent.class, (c, event) -> {
                    c.setAttribute("received", true);
                }, Duration.ofMillis(100));
        
        // When & Then
        assertThrows(RuntimeException.class, () -> {
            applicator.apply(context, procedure);
        });
    }
    
    @Test
    void testPublishAndOnEvent_Integration() throws Exception {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger publishCount = new AtomicInteger(0);
        AtomicInteger awaitCount = new AtomicInteger(0);
        
        // 订阅发布的事件
        eventBus.subscribe(OrderPlacedEvent.class, event -> {
            publishCount.incrementAndGet();
            // 模拟处理完成后发布支付完成事件
            try {
                Thread.sleep(50);
                eventBus.publish(new PaymentCompletedEvent("PAY-" + event.getOrderId(), true));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> c.setAttribute("orderId", "ORDER-789"))
                .publish(c -> new OrderPlacedEvent((String) c.getAttribute("orderId")))
                .onEvent(PaymentCompletedEvent.class, (c, event) -> {
                    awaitCount.incrementAndGet();
                    c.setAttribute("paymentId", event.getPaymentId());
                }, Duration.ofSeconds(2));
        
        // When
        applicator.apply(context, procedure);
        
        // Then
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        assertEquals(1, publishCount.get());
        assertEquals(1, awaitCount.get());
        assertNotNull(context.getAttribute("paymentId"));
    }
}

