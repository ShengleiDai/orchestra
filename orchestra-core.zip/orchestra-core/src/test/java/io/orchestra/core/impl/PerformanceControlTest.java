package io.orchestra.core.impl;

import io.orchestra.core.*;
import io.orchestra.core.config.CircuitBreakerConfig;
import io.orchestra.core.config.RateLimiterConfig;
import io.orchestra.core.performance.Bulkhead;
import io.orchestra.core.performance.CircuitBreaker;
import io.orchestra.core.performance.PerformanceControlRegistry;
import io.orchestra.core.performance.RateLimiter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 性能控制的单元测试。
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
class PerformanceControlTest {
    
    private ReactiveApplicator<String, String, StandardRuntimeContext<String, String>> applicator;
    
    @BeforeEach
    void setUp() {
        applicator = new ReactiveApplicator<>();
        // 清除注册表中的组件，确保测试隔离
        PerformanceControlRegistry.getInstance().clear();
    }
    
    @Test
    void testCircuitBreaker_Success() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger executionCount = new AtomicInteger(0);
        
        CircuitBreakerConfig config = CircuitBreakerConfig.custom()
            .failureRateThreshold(0.5f)
            .slidingWindowSize(5)
            .waitDurationInOpenState(1000L)
            .minimumNumberOfCalls(3)
            .build();
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    executionCount.incrementAndGet();
                })
                .withCircuitBreaker("test-circuit-breaker", config);
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(1, executionCount.get());
        assertNotNull(result);
    }
    
    @Test
    void testCircuitBreaker_OpenAfterFailures() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger executionCount = new AtomicInteger(0);
        
        CircuitBreakerConfig config = CircuitBreakerConfig.custom()
            .failureRateThreshold(0.5f)
            .slidingWindowSize(5)
            .waitDurationInOpenState(1000L)
            .minimumNumberOfCalls(3)
            .build();
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    int count = executionCount.incrementAndGet();
                    if (count <= 3) {
                        throw new RuntimeException("Simulated failure");
                    }
                })
                .withCircuitBreaker("test-circuit-breaker-2", config);
        
        // When & Then - 前3次应该失败
        for (int i = 0; i < 3; i++) {
            assertThrows(RuntimeException.class, () -> {
                applicator.apply(context, procedure);
            });
        }
        
        // Then - 熔断器应该打开，后续请求应该被拒绝
        RuntimeException exception = assertThrows(
            RuntimeException.class,
            () -> applicator.apply(context, procedure)
        );
        Throwable cause = exception.getCause();
        assertTrue(cause instanceof CircuitBreaker.CircuitBreakerOpenException ||
                   exception.getMessage().contains("Circuit breaker is OPEN"));
    }
    
    @Test
    void testBulkhead_MaxConcurrency() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger concurrentExecutions = new AtomicInteger(0);
        AtomicInteger maxConcurrent = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    int current = concurrentExecutions.incrementAndGet();
                    maxConcurrent.updateAndGet(prev -> Math.max(prev, current));
                    try {
                        Thread.sleep(10); // 模拟耗时操作
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    concurrentExecutions.decrementAndGet();
                })
                .withBulkhead("test-bulkhead", 2);
        
        // When - 并发执行多个请求
        Thread[] threads = new Thread[5];
        for (int i = 0; i < 5; i++) {
            threads[i] = new Thread(() -> {
                try {
                    applicator.apply(context, procedure);
                } catch (Exception e) {
                    // 某些请求可能因为隔离舱满而失败
                }
            });
            threads[i].start();
        }
        
        // Wait for all threads
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        
        // Then - 最大并发数应该不超过2
        assertTrue(maxConcurrent.get() <= 2, 
            "Max concurrent executions should not exceed 2, but was: " + maxConcurrent.get());
    }
    
    @Test
    void testRateLimiter_LimitExceeded() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger executionCount = new AtomicInteger(0);
        
        RateLimiterConfig config = RateLimiterConfig.custom()
            .limitForPeriod(2)
            .limitRefreshPeriod(Duration.ofSeconds(1))
            .timeoutDuration(Duration.ofSeconds(1))
            .build();
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    executionCount.incrementAndGet();
                })
                .withRateLimiter("test-rate-limiter", config);
        
        // When - 快速执行多个请求
        int successCount = 0;
        int failureCount = 0;
        for (int i = 0; i < 5; i++) {
            try {
                applicator.apply(context, procedure);
                successCount++;
            } catch (RuntimeException e) {
                // 检查是否是限流异常
                Throwable cause = e.getCause();
                if (cause instanceof RateLimiter.RateLimitExceededException ||
                    e.getMessage().contains("Rate limit exceeded")) {
                    failureCount++;
                } else {
                    throw e;
                }
            }
        }
        
        // Then - 应该只有部分请求成功（限流器限制为每秒2个）
        assertTrue(successCount <= 2, 
            "Success count should not exceed rate limit, but was: " + successCount);
        assertTrue(failureCount > 0, 
            "Some requests should be rate limited");
    }
    
    @Test
    void testPerformanceControls_Combined() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger executionCount = new AtomicInteger(0);
        
        CircuitBreakerConfig circuitBreakerConfig = CircuitBreakerConfig.ofDefaults();
        RateLimiterConfig rateLimiterConfig = RateLimiterConfig.custom()
            .limitForPeriod(10)
            .limitRefreshPeriod(Duration.ofSeconds(1))
            .build();
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    executionCount.incrementAndGet();
                })
                .withCircuitBreaker("combined-circuit-breaker", circuitBreakerConfig)
                .withBulkhead("combined-bulkhead", 5)
                .withRateLimiter("combined-rate-limiter", rateLimiterConfig);
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(1, executionCount.get());
        assertNotNull(result);
    }
    
    @Test
    void testBulkhead_FullException() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                })
                .withBulkhead("test-bulkhead-full", 1);
        
        // When - 同时执行两个请求，第二个应该因为隔离舱满而失败
        Thread thread1 = new Thread(() -> {
            try {
                applicator.apply(context, procedure);
            } catch (Exception e) {
                // Ignore
            }
        });
        thread1.start();
        
        // 等待一小段时间确保第一个请求已经开始
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // Then - 第二个请求应该失败
        RuntimeException exception = assertThrows(
            RuntimeException.class,
            () -> applicator.apply(context, procedure)
        );
        Throwable cause = exception.getCause();
        assertTrue(cause instanceof Bulkhead.BulkheadFullException ||
                   exception.getMessage().contains("Bulkhead is full"));
        
        // Cleanup
        try {
            thread1.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}

