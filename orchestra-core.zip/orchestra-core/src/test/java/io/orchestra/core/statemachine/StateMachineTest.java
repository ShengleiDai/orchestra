package io.orchestra.core.statemachine;

import io.orchestra.core.StandardRuntimeContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 状态机核心功能的单元测试。
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
class StateMachineTest {
    
    // 测试用的状态枚举
    enum TestState {
        INITIAL,
        PROCESSING,
        COMPLETED,
        FAILED
    }
    
    // 测试用的事件类
    static class StartEvent {}
    static class CompleteEvent {}
    static class FailEvent {}
    
    private StateMachineBuilder<TestState, Object, StandardRuntimeContext<String, String>> builder;
    
    @BeforeEach
    void setUp() {
        builder = new StateMachineBuilder<>();
    }
    
    @Test
    void testStateMachine_BasicTransition() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        StateMachine<TestState, Object, StandardRuntimeContext<String, String>> stateMachine = builder
            .initial(TestState.INITIAL)
            .transition(TestState.INITIAL, StartEvent.class, TestState.PROCESSING)
            .transition(TestState.PROCESSING, CompleteEvent.class, TestState.COMPLETED)
            .terminateOn(TestState.COMPLETED, TestState.FAILED)
            .build();
        
        // When
        TestState state1 = stateMachine.getCurrentState();
        TestState state2 = stateMachine.transition(context, new StartEvent());
        TestState state3 = stateMachine.transition(context, new CompleteEvent());
        
        // Then
        assertEquals(TestState.INITIAL, state1);
        assertEquals(TestState.PROCESSING, state2);
        assertEquals(TestState.COMPLETED, state3);
        assertEquals(TestState.COMPLETED, stateMachine.getCurrentState());
    }
    
    @Test
    void testStateMachine_InvalidTransition() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        StateMachine<TestState, Object, StandardRuntimeContext<String, String>> stateMachine = builder
            .initial(TestState.INITIAL)
            .transition(TestState.INITIAL, StartEvent.class, TestState.PROCESSING)
            .build();
        
        // When & Then
        assertThrows(IllegalStateException.class, () -> {
            stateMachine.transition(context, new CompleteEvent());
        });
    }
    
    @Test
    void testStateMachine_TerminalState() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        StateMachine<TestState, Object, StandardRuntimeContext<String, String>> stateMachine = builder
            .initial(TestState.INITIAL)
            .transition(TestState.INITIAL, StartEvent.class, TestState.COMPLETED)
            .terminateOn(TestState.COMPLETED)
            .build();
        
        // When
        stateMachine.transition(context, new StartEvent());
        
        // Then
        assertTrue(stateMachine.isTerminalState(TestState.COMPLETED));
        assertTrue(stateMachine.isTerminalState(stateMachine.getCurrentState()));
        
        // 尝试从终止状态转换应该失败
        assertThrows(IllegalStateException.class, () -> {
            stateMachine.transition(context, new StartEvent());
        });
    }
    
    @Test
    void testStateMachine_ConditionalTransition() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        context.setAttribute("shouldComplete", true);
        
        StateMachine<TestState, Object, StandardRuntimeContext<String, String>> stateMachine = builder
            .initial(TestState.INITIAL)
            .transition(TestState.INITIAL, StartEvent.class, TestState.PROCESSING)
            .transition(TestState.PROCESSING, CompleteEvent.class, TestState.COMPLETED, 
                       ctx -> Boolean.TRUE.equals(ctx.getAttribute("shouldComplete")))
            .transition(TestState.PROCESSING, FailEvent.class, TestState.FAILED,
                       ctx -> !Boolean.TRUE.equals(ctx.getAttribute("shouldComplete")))
            .build();
        
        // When
        stateMachine.transition(context, new StartEvent());
        TestState finalState = stateMachine.transition(context, new CompleteEvent());
        
        // Then
        assertEquals(TestState.COMPLETED, finalState);
    }
    
    @Test
    void testStateMachine_TransitionAction() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        final boolean[] actionExecuted = {false};
        
        StateMachine<TestState, Object, StandardRuntimeContext<String, String>> stateMachine = builder
            .initial(TestState.INITIAL)
            .transition(TestState.INITIAL, StartEvent.class, TestState.PROCESSING)
            .onTransition((ctx, event) -> {
                actionExecuted[0] = true;
                ctx.setAttribute("lastEvent", event);
            })
            .build();
        
        // When
        stateMachine.transition(context, new StartEvent());
        
        // Then
        assertTrue(actionExecuted[0]);
        assertNotNull(context.getAttribute("lastEvent"));
    }
    
    @Test
    void testStateMachine_GetPossibleNextStates() {
        // Given
        StateMachine<TestState, Object, StandardRuntimeContext<String, String>> stateMachine = builder
            .initial(TestState.INITIAL)
            .transition(TestState.INITIAL, StartEvent.class, TestState.PROCESSING)
            .transition(TestState.INITIAL, FailEvent.class, TestState.FAILED)
            .build();
        
        // When
        List<TestState> possibleStates = stateMachine.getPossibleNextStates(TestState.INITIAL);
        
        // Then
        assertEquals(2, possibleStates.size());
        assertTrue(possibleStates.contains(TestState.PROCESSING));
        assertTrue(possibleStates.contains(TestState.FAILED));
    }
    
    @Test
    void testStateMachine_CanTransition() {
        // Given
        StateMachine<TestState, Object, StandardRuntimeContext<String, String>> stateMachine = builder
            .initial(TestState.INITIAL)
            .transition(TestState.INITIAL, StartEvent.class, TestState.PROCESSING)
            .build();
        
        // When & Then
        assertTrue(stateMachine.canTransition(TestState.INITIAL, new StartEvent()));
        assertFalse(stateMachine.canTransition(TestState.INITIAL, new CompleteEvent()));
        assertFalse(stateMachine.canTransition(TestState.PROCESSING, new StartEvent()));
    }
}

