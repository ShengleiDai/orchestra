package io.orchestra.core.impl;

import io.orchestra.core.ProcedureManager;
import io.orchestra.core.RuntimeContext;
import io.orchestra.core.StandardRuntimeContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * DefaultComposer 的单元测试。
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
class DefaultComposerTest {
    
    private DefaultComposer composer;
    
    @BeforeEach
    void setUp() {
        composer = new DefaultComposer();
    }
    
    @Test
    void testJust_WithValidContext_ReturnsProcedureManager() {
        // Given
        RuntimeContext<String, String> context = new StandardRuntimeContext<>("request");
        
        // When
        ProcedureManager<RuntimeContext<String, String>> manager = composer.just(context);
        
        // Then
        assertNotNull(manager);
        assertTrue(manager instanceof DefaultProcedureManager);
    }
    
    @Test
    void testJust_WithNullContext_ThrowsNullPointerException() {
        // When & Then
        assertThrows(NullPointerException.class, () -> {
            composer.just(null);
        });
    }
    
    @Test
    void testJust_ReturnsManagerWithCorrectContext() {
        // Given
        String request = "test-request";
        RuntimeContext<String, String> context = new StandardRuntimeContext<>(request);
        
        // When
        DefaultProcedureManager<RuntimeContext<String, String>> manager = 
            (DefaultProcedureManager<RuntimeContext<String, String>>) composer.just(context);
        
        // Then
        assertNotNull(manager.getContext());
        assertEquals(request, manager.getContext().getRequest());
    }
}

