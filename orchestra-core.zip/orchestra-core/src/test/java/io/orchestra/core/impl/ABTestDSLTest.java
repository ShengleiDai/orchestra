package io.orchestra.core.impl;

import io.orchestra.core.Procedure;
import io.orchestra.core.ReactiveApplicator;
import io.orchestra.core.RuntimeContext;
import io.orchestra.core.StandardRuntimeContext;
import io.orchestra.core.abtest.InMemoryTrafficAllocationPersistence;
import io.orchestra.core.abtest.TrafficAllocatorRegistry;
import io.orchestra.core.abtest.Variant;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.*;

/**
 * A/B 测试 DSL 集成测试。
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
class ABTestDSLTest {
    
    private ReactiveApplicator<String, String, StandardRuntimeContext<String, String>> applicator;
    
    @BeforeEach
    void setUp() {
        applicator = new ReactiveApplicator<>();
        // 重置注册表以确保测试隔离
        TrafficAllocatorRegistry.reset();
    }
    
    @Test
    void testAbTest_Basic() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("user-123");
        AtomicInteger variantACount = new AtomicInteger(0);
        AtomicInteger variantBCount = new AtomicInteger(0);
        
        List<Variant> variants = Arrays.asList(
            new Variant("A", 0.5),
            new Variant("B", 0.5)
        );
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure =
            (ctx, comp) -> comp.just(ctx)
                .abTest(
                    "test-experiment",
                    c -> c.getRequest(),  // 使用请求作为用户 ID
                    variants,
                    (variant, branch) -> {
                        if ("A".equals(variant)) {
                            return branch.sync((Consumer<StandardRuntimeContext<String, String>>) c -> variantACount.incrementAndGet());
                        } else {
                            return branch.sync((Consumer<StandardRuntimeContext<String, String>>) c -> variantBCount.incrementAndGet());
                        }
                    }
                );
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(context, result);
        // 应该只执行一个变体
        assertTrue((variantACount.get() == 1 && variantBCount.get() == 0) ||
                   (variantACount.get() == 0 && variantBCount.get() == 1));
        
        // 验证分配的变体被保存到上下文
        String allocatedVariant = (String) context.getAttribute("abTest:test-experiment");
        assertNotNull(allocatedVariant);
        assertTrue(allocatedVariant.equals("A") || allocatedVariant.equals("B"));
    }
    
    @Test
    void testAbTest_ConsistentAllocation() {
        // Given
        StandardRuntimeContext<String, String> context1 = new StandardRuntimeContext<>("user-123");
        StandardRuntimeContext<String, String> context2 = new StandardRuntimeContext<>("user-123");
        AtomicInteger variantACount = new AtomicInteger(0);
        AtomicInteger variantBCount = new AtomicInteger(0);
        
        List<Variant> variants = Arrays.asList(
            new Variant("A", 0.5),
            new Variant("B", 0.5)
        );
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure =
            (ctx, comp) -> comp.just(ctx)
                .abTest(
                    "test-experiment",
                    c -> c.getRequest(),
                    variants,
                    (variant, branch) -> {
                        if ("A".equals(variant)) {
                            return branch.sync((Consumer<StandardRuntimeContext<String, String>>) c -> variantACount.incrementAndGet());
                        } else {
                            return branch.sync((Consumer<StandardRuntimeContext<String, String>>) c -> variantBCount.incrementAndGet());
                        }
                    }
                );
        
        // When - 同一用户执行两次
        applicator.apply(context1, procedure);
        applicator.apply(context2, procedure);
        
        // Then - 应该分配到同一个变体
        String variant1 = (String) context1.getAttribute("abTest:test-experiment");
        String variant2 = (String) context2.getAttribute("abTest:test-experiment");
        assertEquals(variant1, variant2);
    }
    
    @Test
    void testAbTest_ThreeVariants() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("user-123");
        AtomicInteger variantACount = new AtomicInteger(0);
        AtomicInteger variantBCount = new AtomicInteger(0);
        AtomicInteger variantCCount = new AtomicInteger(0);
        
        List<Variant> variants = Arrays.asList(
            new Variant("A", 0.33),
            new Variant("B", 0.33),
            new Variant("C", 0.34)
        );
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure =
            (ctx, comp) -> comp.just(ctx)
                .abTest(
                    "test-experiment",
                    c -> c.getRequest(),
                    variants,
                    (variant, branch) -> {
                        if ("A".equals(variant)) {
                            return branch.sync((Consumer<StandardRuntimeContext<String, String>>) c -> variantACount.incrementAndGet());
                        } else if ("B".equals(variant)) {
                            return branch.sync((Consumer<StandardRuntimeContext<String, String>>) c -> variantBCount.incrementAndGet());
                        } else {
                            return branch.sync((Consumer<StandardRuntimeContext<String, String>>) c -> variantCCount.incrementAndGet());
                        }
                    }
                );
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(context, result);
        // 应该只执行一个变体
        assertTrue((variantACount.get() == 1 && variantBCount.get() == 0 && variantCCount.get() == 0) ||
                   (variantACount.get() == 0 && variantBCount.get() == 1 && variantCCount.get() == 0) ||
                   (variantACount.get() == 0 && variantBCount.get() == 0 && variantCCount.get() == 1));
    }
    
    @Test
    void testAbTest_ChainedWithOtherOperations() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("user-123");
        AtomicInteger beforeCount = new AtomicInteger(0);
        AtomicInteger variantACount = new AtomicInteger(0);
        AtomicInteger variantBCount = new AtomicInteger(0);
        AtomicInteger afterCount = new AtomicInteger(0);
        
        List<Variant> variants = Arrays.asList(
            new Variant("A", 0.5),
            new Variant("B", 0.5)
        );
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure =
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> beforeCount.incrementAndGet())
                .abTest(
                    "test-experiment",
                    c -> c.getRequest(),
                    variants,
                    (variant, branch) -> {
                        if ("A".equals(variant)) {
                            return branch.sync((Consumer<StandardRuntimeContext<String, String>>) c -> variantACount.incrementAndGet());
                        } else {
                            return branch.sync((Consumer<StandardRuntimeContext<String, String>>) c -> variantBCount.incrementAndGet());
                        }
                    }
                )
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> afterCount.incrementAndGet());
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(context, result);
        assertEquals(1, beforeCount.get());
        assertEquals(1, afterCount.get());
        assertTrue((variantACount.get() == 1 && variantBCount.get() == 0) ||
                   (variantACount.get() == 0 && variantBCount.get() == 1));
    }
    
    @Test
    void testAbTest_InvalidParameters() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("user-123");
        List<Variant> variants = Arrays.asList(
            new Variant("A", 0.5),
            new Variant("B", 0.5)
        );
        
        // When & Then - 实验 ID 为空
        RuntimeException exception1 = assertThrows(RuntimeException.class, () -> {
            Procedure<String, String, StandardRuntimeContext<String, String>> procedure =
                (ctx, comp) -> comp.just(ctx)
                    .abTest("", c -> c.getRequest(), variants, (v, b) -> b);
            applicator.apply(context, procedure);
        });
        assertTrue(exception1.getCause() instanceof IllegalArgumentException);
        assertTrue(exception1.getCause().getMessage().contains("Experiment ID"));
        
        // When & Then - 变体列表为空
        RuntimeException exception2 = assertThrows(RuntimeException.class, () -> {
            Procedure<String, String, StandardRuntimeContext<String, String>> procedure =
                (ctx, comp) -> comp.just(ctx)
                    .abTest("exp", c -> c.getRequest(), Arrays.asList(), (v, b) -> b);
            applicator.apply(context, procedure);
        });
        assertTrue(exception2.getCause() instanceof IllegalArgumentException);
        assertTrue(exception2.getCause().getMessage().contains("Variants"));
    }
}

