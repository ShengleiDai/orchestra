package io.orchestra.core.saga;

import io.orchestra.core.StandardRuntimeContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

class SagaManagerTest {

    private LocalSagaManager<StandardRuntimeContext<String, String>> sagaManager;
    private StandardRuntimeContext<String, String> context;

    @BeforeEach
    void setUp() {
        sagaManager = new LocalSagaManager<>();
        context = new StandardRuntimeContext<>("test-request");
    }

    @Test
    void testStartSaga() {
        String sagaId = sagaManager.startSaga(context);
        assertNotNull(sagaId);
        assertTrue(sagaManager.isInSaga(context, sagaId));
        assertEquals(sagaId, context.getAttribute("sagaId"));
    }

    @Test
    void testEndSaga() {
        String sagaId = sagaManager.startSaga(context);
        assertTrue(sagaManager.isInSaga(context, sagaId));
        
        sagaManager.endSaga(context, sagaId);
        assertFalse(sagaManager.isInSaga(context, sagaId));
        assertNull(context.getAttribute("sagaId"));
    }

    @Test
    void testRegisterCompensation() {
        AtomicInteger compensationCount = new AtomicInteger(0);
        
        String sagaId = sagaManager.startSaga(context);
        sagaManager.registerCompensation(context, sagaId, ctx -> {
            compensationCount.incrementAndGet();
            return null;
        });
        
        // 补偿操作已注册，但尚未执行
        assertEquals(0, compensationCount.get());
    }

    @Test
    void testExecuteCompensations() {
        AtomicInteger compensation1 = new AtomicInteger(0);
        AtomicInteger compensation2 = new AtomicInteger(0);
        AtomicInteger compensation3 = new AtomicInteger(0);
        
        String sagaId = sagaManager.startSaga(context);
        
        // 注册三个补偿操作
        sagaManager.registerCompensation(context, sagaId, ctx -> {
            compensation1.incrementAndGet();
            return null;
        });
        sagaManager.registerCompensation(context, sagaId, ctx -> {
            compensation2.incrementAndGet();
            return null;
        });
        sagaManager.registerCompensation(context, sagaId, ctx -> {
            compensation3.incrementAndGet();
            return null;
        });
        
        // 执行补偿操作
        sagaManager.executeCompensations(context, sagaId, new RuntimeException("Test error"));
        
        // 验证所有补偿操作都已执行（按相反顺序）
        assertEquals(1, compensation1.get());
        assertEquals(1, compensation2.get());
        assertEquals(1, compensation3.get());
        
        // 验证 Saga 事务已结束
        assertFalse(sagaManager.isInSaga(context, sagaId));
    }

    @Test
    void testExecuteCompensations_ReverseOrder() {
        StringBuilder executionOrder = new StringBuilder();
        
        String sagaId = sagaManager.startSaga(context);
        
        // 注册三个补偿操作
        sagaManager.registerCompensation(context, sagaId, ctx -> {
            executionOrder.append("1");
            return null;
        });
        sagaManager.registerCompensation(context, sagaId, ctx -> {
            executionOrder.append("2");
            return null;
        });
        sagaManager.registerCompensation(context, sagaId, ctx -> {
            executionOrder.append("3");
            return null;
        });
        
        // 执行补偿操作
        sagaManager.executeCompensations(context, sagaId, new RuntimeException("Test error"));
        
        // 验证补偿操作按相反顺序执行（3 -> 2 -> 1）
        assertEquals("321", executionOrder.toString());
    }

    @Test
    void testExecuteCompensations_CompensationFailure() {
        AtomicInteger compensation1 = new AtomicInteger(0);
        AtomicInteger compensation2 = new AtomicInteger(0);
        
        String sagaId = sagaManager.startSaga(context);
        
        // 注册两个补偿操作，第一个会失败
        sagaManager.registerCompensation(context, sagaId, ctx -> {
            compensation1.incrementAndGet();
            throw new RuntimeException("Compensation 1 failed");
        });
        sagaManager.registerCompensation(context, sagaId, ctx -> {
            compensation2.incrementAndGet();
            return null;
        });
        
        // 执行补偿操作，即使第一个失败，第二个也应该执行
        sagaManager.executeCompensations(context, sagaId, new RuntimeException("Test error"));
        
        // 验证两个补偿操作都已执行
        assertEquals(1, compensation1.get());
        assertEquals(1, compensation2.get());
    }

    @Test
    void testIsInSaga_NotStarted() {
        assertFalse(sagaManager.isInSaga(context, "non-existent-saga-id"));
    }

    @Test
    void testEndSaga_ClearsCompensations() {
        AtomicInteger compensationCount = new AtomicInteger(0);
        
        String sagaId = sagaManager.startSaga(context);
        sagaManager.registerCompensation(context, sagaId, ctx -> {
            compensationCount.incrementAndGet();
            return null;
        });
        
        // 正常结束 Saga，不应该执行补偿
        sagaManager.endSaga(context, sagaId);
        
        // 手动执行补偿（不应该有任何补偿）
        sagaManager.executeCompensations(context, sagaId, new RuntimeException("Test error"));
        
        // 验证补偿操作未执行
        assertEquals(0, compensationCount.get());
    }
}

