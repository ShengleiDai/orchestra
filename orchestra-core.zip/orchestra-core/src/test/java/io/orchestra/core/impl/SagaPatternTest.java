package io.orchestra.core.impl;

import io.orchestra.core.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Saga 模式的单元测试。
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
class SagaPatternTest {
    
    private ReactiveApplicator<String, String, StandardRuntimeContext<String, String>> applicator;
    
    @BeforeEach
    void setUp() {
        applicator = new ReactiveApplicator<>();
    }
    
    @Test
    void testSaga_SuccessfulExecution_NoCompensation() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger step1Executed = new AtomicInteger(0);
        AtomicInteger step2Executed = new AtomicInteger(0);
        AtomicInteger compensation1Executed = new AtomicInteger(0);
        AtomicInteger compensation2Executed = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sagaStart()
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    step1Executed.incrementAndGet();
                    c.setAttribute("step1", "executed");
                })
                .withCompensation((Function<StandardRuntimeContext<String, String>, ?>) c -> {
                    compensation1Executed.incrementAndGet();
                    return null;
                })
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    step2Executed.incrementAndGet();
                    c.setAttribute("step2", "executed");
                })
                .withCompensation((Function<StandardRuntimeContext<String, String>, ?>) c -> {
                    compensation2Executed.incrementAndGet();
                    return null;
                })
                .sagaEnd();
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(1, step1Executed.get());
        assertEquals(1, step2Executed.get());
        assertEquals(0, compensation1Executed.get()); // 成功执行，不执行补偿
        assertEquals(0, compensation2Executed.get()); // 成功执行，不执行补偿
        assertEquals("executed", result.getAttribute("step1"));
        assertEquals("executed", result.getAttribute("step2"));
    }
    
    @Test
    void testSaga_FailureInMiddle_ExecuteCompensationsInReverseOrder() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger step1Executed = new AtomicInteger(0);
        AtomicInteger step2Executed = new AtomicInteger(0);
        AtomicInteger step3Executed = new AtomicInteger(0);
        List<Integer> compensationOrder = new ArrayList<>();
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sagaStart()
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    step1Executed.incrementAndGet();
                    c.setAttribute("step1", "executed");
                })
                .withCompensation((Function<StandardRuntimeContext<String, String>, ?>) c -> {
                    compensationOrder.add(1);
                    return null;
                })
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    step2Executed.incrementAndGet();
                    c.setAttribute("step2", "executed");
                })
                .withCompensation((Function<StandardRuntimeContext<String, String>, ?>) c -> {
                    compensationOrder.add(2);
                    return null;
                })
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    step3Executed.incrementAndGet();
                    throw new RuntimeException("Step 3 failed");
                })
                .withCompensation((Function<StandardRuntimeContext<String, String>, ?>) c -> {
                    compensationOrder.add(3);
                    return null;
                })
                .sagaEnd();
        
        // When & Then
        assertThrows(RuntimeException.class, () -> {
            applicator.apply(context, procedure);
        });
        
        // Then - 验证步骤执行
        assertEquals(1, step1Executed.get());
        assertEquals(1, step2Executed.get());
        assertEquals(1, step3Executed.get());
        
        // Then - 验证补偿操作按相反顺序执行（2, 1）
        assertEquals(2, compensationOrder.size());
        assertEquals(2, compensationOrder.get(0)); // 先执行 step2 的补偿
        assertEquals(1, compensationOrder.get(1)); // 再执行 step1 的补偿
        // step3 的补偿不应该执行，因为 step3 失败了
    }
    
    @Test
    void testSaga_FailureInFirstStep_NoCompensation() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger step1Executed = new AtomicInteger(0);
        AtomicInteger compensation1Executed = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sagaStart()
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    step1Executed.incrementAndGet();
                    throw new RuntimeException("Step 1 failed");
                })
                .withCompensation((Function<StandardRuntimeContext<String, String>, ?>) c -> {
                    compensation1Executed.incrementAndGet();
                    return null;
                })
                .sagaEnd();
        
        // When & Then
        assertThrows(RuntimeException.class, () -> {
            applicator.apply(context, procedure);
        });
        
        // Then
        assertEquals(1, step1Executed.get());
        assertEquals(0, compensation1Executed.get()); // 第一步失败，没有已完成的步骤需要补偿
    }
    
    @Test
    void testSaga_WithErrorHandling_CompensationStillExecutes() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger step1Executed = new AtomicInteger(0);
        AtomicInteger step2Executed = new AtomicInteger(0);
        AtomicInteger compensation1Executed = new AtomicInteger(0);
        AtomicInteger compensation2Executed = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sagaStart()
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    step1Executed.incrementAndGet();
                    c.setAttribute("step1", "executed");
                })
                .withCompensation((Function<StandardRuntimeContext<String, String>, ?>) c -> {
                    compensation1Executed.incrementAndGet();
                    return null;
                })
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    step2Executed.incrementAndGet();
                    throw new RuntimeException("Step 2 failed");
                })
                .onError(RuntimeException.class, c -> {
                    c.setAttribute("error", "handled");
                })
                .withCompensation((Function<StandardRuntimeContext<String, String>, ?>) c -> {
                    compensation2Executed.incrementAndGet();
                    return null;
                })
                .sagaEnd();
        
        // When & Then
        assertThrows(RuntimeException.class, () -> {
            applicator.apply(context, procedure);
        });
        
        // Then
        assertEquals(1, step1Executed.get());
        assertEquals(1, step2Executed.get());
        assertEquals(1, compensation1Executed.get()); // 补偿应该执行
        assertEquals(0, compensation2Executed.get()); // step2 失败，不需要补偿
        assertEquals("handled", context.getAttribute("error"));
    }
    
    @Test
    void testSaga_MultipleSteps_AllCompensationsExecute() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        List<Integer> executedSteps = new ArrayList<>();
        List<Integer> executedCompensations = new ArrayList<>();
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sagaStart()
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    executedSteps.add(1);
                })
                .withCompensation((Function<StandardRuntimeContext<String, String>, ?>) c -> {
                    executedCompensations.add(1);
                    return null;
                })
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    executedSteps.add(2);
                })
                .withCompensation((Function<StandardRuntimeContext<String, String>, ?>) c -> {
                    executedCompensations.add(2);
                    return null;
                })
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    executedSteps.add(3);
                })
                .withCompensation((Function<StandardRuntimeContext<String, String>, ?>) c -> {
                    executedCompensations.add(3);
                    return null;
                })
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    executedSteps.add(4);
                    throw new RuntimeException("Step 4 failed");
                })
                .withCompensation((Function<StandardRuntimeContext<String, String>, ?>) c -> {
                    executedCompensations.add(4);
                    return null;
                })
                .sagaEnd();
        
        // When & Then
        assertThrows(RuntimeException.class, () -> {
            applicator.apply(context, procedure);
        });
        
        // Then
        assertEquals(4, executedSteps.size());
        assertEquals(3, executedCompensations.size()); // 只有前3个步骤的补偿应该执行
        assertEquals(3, executedCompensations.get(0)); // 按相反顺序：3
        assertEquals(2, executedCompensations.get(1)); // 2
        assertEquals(1, executedCompensations.get(2)); // 1
    }
    
    @Test
    void testSaga_WithoutSagaStart_NoCompensationTracking() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger compensationExecuted = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    throw new RuntimeException("Step failed");
                })
                .withCompensation((Function<StandardRuntimeContext<String, String>, ?>) c -> {
                    compensationExecuted.incrementAndGet();
                    return null;
                });
        
        // When & Then
        assertThrows(RuntimeException.class, () -> {
            applicator.apply(context, procedure);
        });
        
        // Then - 没有 sagaStart，补偿不应该执行
        assertEquals(0, compensationExecuted.get());
    }
    
    @Test
    void testSaga_WithCompensationFunction_ReturnsValue() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger compensationExecuted = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sagaStart()
                .sync((Function<StandardRuntimeContext<String, String>, String>) c -> {
                    c.setAttribute("value", "created");
                    return "result";
                })
                .withCompensation((Function<StandardRuntimeContext<String, String>, ?>) c -> {
                    compensationExecuted.incrementAndGet();
                    return "compensated";
                })
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    throw new RuntimeException("Step 2 failed");
                })
                .sagaEnd();
        
        // When & Then
        assertThrows(RuntimeException.class, () -> {
            applicator.apply(context, procedure);
        });
        
        // Then
        assertEquals(1, compensationExecuted.get());
    }
}

