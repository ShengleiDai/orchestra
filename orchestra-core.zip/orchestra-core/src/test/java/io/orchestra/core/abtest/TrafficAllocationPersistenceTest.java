package io.orchestra.core.abtest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 流量分配持久化测试。
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
class TrafficAllocationPersistenceTest {
    
    private InMemoryTrafficAllocationPersistence persistence;
    
    @BeforeEach
    void setUp() {
        persistence = new InMemoryTrafficAllocationPersistence();
    }
    
    @Test
    void testSaveAndGetAllocation() {
        // Given
        String experimentId = "test-experiment";
        String userId = "user-123";
        String variant = "A";
        
        // When
        persistence.saveAllocation(experimentId, userId, variant);
        String retrieved = persistence.getAllocation(experimentId, userId);
        
        // Then
        assertEquals(variant, retrieved);
    }
    
    @Test
    void testGetAllocation_NotExists() {
        // When
        String retrieved = persistence.getAllocation("non-existent", "user-123");
        
        // Then
        assertNull(retrieved);
    }
    
    @Test
    void testGetAllAllocations() {
        // Given
        String experimentId = "test-experiment";
        persistence.saveAllocation(experimentId, "user-1", "A");
        persistence.saveAllocation(experimentId, "user-2", "B");
        persistence.saveAllocation(experimentId, "user-3", "A");
        
        // When
        Map<String, String> allocations = persistence.getAllAllocations(experimentId);
        
        // Then
        assertEquals(3, allocations.size());
        assertEquals("A", allocations.get("user-1"));
        assertEquals("B", allocations.get("user-2"));
        assertEquals("A", allocations.get("user-3"));
    }
    
    @Test
    void testClearAllocations() {
        // Given
        String experimentId = "test-experiment";
        persistence.saveAllocation(experimentId, "user-1", "A");
        persistence.saveAllocation(experimentId, "user-2", "B");
        
        // When
        persistence.clearAllocations(experimentId);
        
        // Then
        assertNull(persistence.getAllocation(experimentId, "user-1"));
        assertNull(persistence.getAllocation(experimentId, "user-2"));
        assertTrue(persistence.getAllAllocations(experimentId).isEmpty());
    }
    
    @Test
    void testRemoveAllocation() {
        // Given
        String experimentId = "test-experiment";
        persistence.saveAllocation(experimentId, "user-1", "A");
        persistence.saveAllocation(experimentId, "user-2", "B");
        
        // When
        persistence.removeAllocation(experimentId, "user-1");
        
        // Then
        assertNull(persistence.getAllocation(experimentId, "user-1"));
        assertEquals("B", persistence.getAllocation(experimentId, "user-2"));
    }
    
    @Test
    void testSaveAllocation_InvalidParameters() {
        // When & Then
        assertThrows(IllegalArgumentException.class, () -> {
            persistence.saveAllocation(null, "user-1", "A");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            persistence.saveAllocation("", "user-1", "A");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            persistence.saveAllocation("exp", null, "A");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            persistence.saveAllocation("exp", "", "A");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            persistence.saveAllocation("exp", "user-1", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            persistence.saveAllocation("exp", "user-1", "");
        });
    }
}

