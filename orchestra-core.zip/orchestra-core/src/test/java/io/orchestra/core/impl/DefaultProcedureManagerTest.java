package io.orchestra.core.impl;

import io.orchestra.core.Composer;
import io.orchestra.core.ProcedureManager;
import io.orchestra.core.RuntimeContext;
import io.orchestra.core.StandardRuntimeContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * DefaultProcedureManager 的单元测试。
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
class DefaultProcedureManagerTest {
    
    private RuntimeContext<String, String> context;
    private Composer composer;
    
    @BeforeEach
    void setUp() {
        context = new StandardRuntimeContext<>("test-request");
        composer = new DefaultComposer();
    }
    
    @Test
    void testConstructor_WithValidContext_CreatesInstance() {
        // When
        DefaultProcedureManager<RuntimeContext<String, String>> manager = 
            new DefaultProcedureManager<>(context, composer);
        
        // Then
        assertNotNull(manager);
        assertEquals(context, manager.getContext());
    }
    
    @Test
    void testConstructor_WithNullContext_ThrowsNullPointerException() {
        // When & Then
        assertThrows(NullPointerException.class, () -> {
            new DefaultProcedureManager<>(null, composer);
        });
    }
    
    @Test
    void testConstructor_WithNullComposer_ThrowsNullPointerException() {
        // When & Then
        assertThrows(NullPointerException.class, () -> {
            new DefaultProcedureManager<>(context, null);
        });
    }
    
    @Test
    void testGetContext_ReturnsCorrectContext() {
        // Given
        DefaultProcedureManager<RuntimeContext<String, String>> manager = 
            new DefaultProcedureManager<>(context, composer);
        
        // When
        RuntimeContext<String, String> retrievedContext = manager.getContext();
        
        // Then
        assertNotNull(retrievedContext);
        assertEquals(context, retrievedContext);
        assertEquals("test-request", retrievedContext.getRequest());
    }
    
    @Test
    void testImplementsProcedureManager() {
        // Given
        DefaultProcedureManager<RuntimeContext<String, String>> manager = 
            new DefaultProcedureManager<>(context, composer);
        
        // Then
        assertTrue(manager instanceof ProcedureManager);
    }
}

