package io.orchestra.core.impl;

import io.orchestra.core.Case;
import io.orchestra.core.Procedure;
import io.orchestra.core.ReactiveApplicator;
import io.orchestra.core.RuntimeContext;
import io.orchestra.core.StandardRuntimeContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 多分支选择操作（select）的单元测试。
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
class SelectOperationTest {
    
    private ReactiveApplicator<String, String, StandardRuntimeContext<String, String>> applicator;
    
    @BeforeEach
    void setUp() {
        applicator = new ReactiveApplicator<>();
    }
    
    @Test
    void testSelect_StringValue_MatchFirstCase() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("VIP");
        AtomicInteger vipCounter = new AtomicInteger(0);
        AtomicInteger normalCounter = new AtomicInteger(0);
        AtomicInteger defaultCounter = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure =
            (ctx, comp) -> comp.just(ctx)
                .select(
                    c -> c.getRequest(),  // 提取订单类型
                    Case.of("VIP", branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> vipCounter.incrementAndGet())),
                    Case.of("NORMAL", branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> normalCounter.incrementAndGet())),
                    Case.defaultCase(branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> defaultCounter.incrementAndGet()))
                );
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(1, vipCounter.get());
        assertEquals(0, normalCounter.get());
        assertEquals(0, defaultCounter.get());
        assertEquals(context, result);
    }
    
    @Test
    void testSelect_StringValue_MatchSecondCase() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("NORMAL");
        AtomicInteger vipCounter = new AtomicInteger(0);
        AtomicInteger normalCounter = new AtomicInteger(0);
        AtomicInteger defaultCounter = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure =
            (ctx, comp) -> comp.just(ctx)
                .select(
                    c -> c.getRequest(),
                    Case.of("VIP", branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> vipCounter.incrementAndGet())),
                    Case.of("NORMAL", branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> normalCounter.incrementAndGet())),
                    Case.defaultCase(branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> defaultCounter.incrementAndGet()))
                );
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(0, vipCounter.get());
        assertEquals(1, normalCounter.get());
        assertEquals(0, defaultCounter.get());
        assertEquals(context, result);
    }
    
    @Test
    void testSelect_StringValue_MatchDefaultCase() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("UNKNOWN");
        AtomicInteger vipCounter = new AtomicInteger(0);
        AtomicInteger normalCounter = new AtomicInteger(0);
        AtomicInteger defaultCounter = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure =
            (ctx, comp) -> comp.just(ctx)
                .select(
                    c -> c.getRequest(),
                    Case.of("VIP", branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> vipCounter.incrementAndGet())),
                    Case.of("NORMAL", branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> normalCounter.incrementAndGet())),
                    Case.defaultCase(branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> defaultCounter.incrementAndGet()))
                );
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(0, vipCounter.get());
        assertEquals(0, normalCounter.get());
        assertEquals(1, defaultCounter.get());
        assertEquals(context, result);
    }
    
    @Test
    void testSelect_IntegerValue() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        context.setAttribute("amount", 1500);
        AtomicInteger highCounter = new AtomicInteger(0);
        AtomicInteger mediumCounter = new AtomicInteger(0);
        AtomicInteger lowCounter = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure =
            (ctx, comp) -> comp.just(ctx)
                .select(
                    c -> (Integer) c.getAttribute("amount"),
                    Case.of(1000, branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> highCounter.incrementAndGet())),
                    Case.of(500, branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> mediumCounter.incrementAndGet())),
                    Case.of(100, branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> lowCounter.incrementAndGet())),
                    Case.defaultCase(branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                            // 默认分支不执行任何操作
                        }))
                );
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(0, highCounter.get());
        assertEquals(0, mediumCounter.get());
        assertEquals(0, lowCounter.get());
        // 因为 1500 不匹配任何 case，所以执行默认分支（什么都不做）
        assertEquals(context, result);
    }
    
    @Test
    void testSelect_EnumValue() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        context.setAttribute("orderType", TestOrderType.BULK);
        AtomicInteger vipCounter = new AtomicInteger(0);
        AtomicInteger normalCounter = new AtomicInteger(0);
        AtomicInteger bulkCounter = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure =
            (ctx, comp) -> comp.just(ctx)
                .select(
                    c -> (TestOrderType) c.getAttribute("orderType"),
                    Case.of(TestOrderType.VIP, branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> vipCounter.incrementAndGet())),
                    Case.of(TestOrderType.NORMAL, branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> normalCounter.incrementAndGet())),
                    Case.of(TestOrderType.BULK, branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> bulkCounter.incrementAndGet())),
                    Case.defaultCase(branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                            // 默认分支
                        }))
                );
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(0, vipCounter.get());
        assertEquals(0, normalCounter.get());
        assertEquals(1, bulkCounter.get());
        assertEquals(context, result);
    }
    
    /**
     * 测试用的订单类型枚举。
     */
    enum TestOrderType { VIP, NORMAL, BULK }
    
    @Test
    void testSelect_NoMatch_NoDefault_ThrowsException() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("UNKNOWN");
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure =
            (ctx, comp) -> comp.just(ctx)
                .select(
                    c -> c.getRequest(),
                    Case.of("VIP", branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {})),
                    Case.of("NORMAL", branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {}))
                    // 没有默认分支
                );
        
        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            applicator.apply(context, procedure);
        });
        
        assertTrue(exception.getCause() instanceof IllegalStateException);
        assertTrue(exception.getCause().getMessage().contains("No matching case found"));
    }
    
    @Test
    void testSelect_NullValue() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        context.setAttribute("value", null);
        AtomicInteger nullCounter = new AtomicInteger(0);
        AtomicInteger defaultCounter = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure =
            (ctx, comp) -> comp.just(ctx)
                .select(
                    c -> (String) c.getAttribute("value"),
                    Case.of(null, branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> nullCounter.incrementAndGet())),
                    Case.of("NOT_NULL", branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {})),
                    Case.defaultCase(branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> defaultCounter.incrementAndGet()))
                );
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(1, nullCounter.get());
        assertEquals(0, defaultCounter.get());
        assertEquals(context, result);
    }
    
    @Test
    void testSelect_ComplexBranch() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("VIP");
        AtomicInteger step1 = new AtomicInteger(0);
        AtomicInteger step2 = new AtomicInteger(0);
        AtomicInteger step3 = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure =
            (ctx, comp) -> comp.just(ctx)
                .select(
                    c -> c.getRequest(),
                    Case.of("VIP", branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> step1.incrementAndGet())
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> step2.incrementAndGet())
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> step3.incrementAndGet())),
                    Case.of("NORMAL", branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> step1.incrementAndGet())),
                    Case.defaultCase(branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> step1.incrementAndGet()))
                );
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(1, step1.get());
        assertEquals(1, step2.get());
        assertEquals(1, step3.get());
        assertEquals(context, result);
    }
    
    @Test
    void testSelect_ChainedWithOtherOperations() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("VIP");
        AtomicInteger beforeCounter = new AtomicInteger(0);
        AtomicInteger vipCounter = new AtomicInteger(0);
        AtomicInteger afterCounter = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure =
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> beforeCounter.incrementAndGet())
                .select(
                    c -> c.getRequest(),
                    Case.of("VIP", branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> vipCounter.incrementAndGet())),
                    Case.defaultCase(branch -> branch
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {}))
                )
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> afterCounter.incrementAndGet());
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(1, beforeCounter.get());
        assertEquals(1, vipCounter.get());
        assertEquals(1, afterCounter.get());
        assertEquals(context, result);
    }
}

