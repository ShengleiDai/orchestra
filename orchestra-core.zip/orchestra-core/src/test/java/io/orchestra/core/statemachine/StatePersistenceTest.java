package io.orchestra.core.statemachine;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 状态持久化的单元测试。
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
class StatePersistenceTest {
    
    enum TestState {
        INITIAL, COMPLETED
    }
    
    static class TestEvent {}
    
    private InMemoryStatePersistence<TestState, TestEvent> persistence;
    
    @BeforeEach
    void setUp() {
        persistence = new InMemoryStatePersistence<>();
    }
    
    @Test
    void testSaveAndLoadState() {
        // Given
        String instanceId = "test-instance-1";
        StateMachineSnapshot<TestState, TestEvent> snapshot = 
            new StateMachineSnapshot<>(instanceId, TestState.INITIAL);
        snapshot.setVersion(1);
        
        // When
        persistence.saveState(instanceId, snapshot);
        StateMachineSnapshot<TestState, TestEvent> loaded = persistence.loadState(instanceId);
        
        // Then
        assertNotNull(loaded);
        assertEquals(instanceId, loaded.getInstanceId());
        assertEquals(TestState.INITIAL, loaded.getCurrentState());
        assertEquals(1, loaded.getVersion());
    }
    
    @Test
    void testLoadNonExistentState() {
        // When
        StateMachineSnapshot<TestState, TestEvent> loaded = persistence.loadState("non-existent");
        
        // Then
        assertNull(loaded);
    }
    
    @Test
    void testSaveAndLoadTransition() {
        // Given
        String instanceId = "test-instance-2";
        StateTransition<TestState, TestEvent> transition = 
            new StateTransition<>(instanceId, TestState.INITIAL, TestState.COMPLETED, new TestEvent());
        
        // When
        persistence.saveTransition(instanceId, transition);
        List<StateTransition<TestState, TestEvent>> history = persistence.getTransitionHistory(instanceId);
        
        // Then
        assertEquals(1, history.size());
        StateTransition<TestState, TestEvent> saved = history.get(0);
        assertEquals(instanceId, saved.getInstanceId());
        assertEquals(TestState.INITIAL, saved.getFromState());
        assertEquals(TestState.COMPLETED, saved.getToState());
        assertTrue(saved.isSuccess());
    }
    
    @Test
    void testGetTransitionHistoryWithLimit() {
        // Given
        String instanceId = "test-instance-3";
        for (int i = 0; i < 5; i++) {
            StateTransition<TestState, TestEvent> transition = 
                new StateTransition<>(instanceId, TestState.INITIAL, TestState.COMPLETED, new TestEvent());
            persistence.saveTransition(instanceId, transition);
        }
        
        // When
        List<StateTransition<TestState, TestEvent>> history = persistence.getTransitionHistory(instanceId, 3);
        
        // Then
        assertEquals(3, history.size());
    }
    
    @Test
    void testDeleteState() {
        // Given
        String instanceId = "test-instance-4";
        StateMachineSnapshot<TestState, TestEvent> snapshot = 
            new StateMachineSnapshot<>(instanceId, TestState.INITIAL);
        persistence.saveState(instanceId, snapshot);
        persistence.saveTransition(instanceId, 
            new StateTransition<>(instanceId, TestState.INITIAL, TestState.COMPLETED, new TestEvent()));
        
        // When
        persistence.deleteState(instanceId);
        
        // Then
        assertNull(persistence.loadState(instanceId));
        assertTrue(persistence.getTransitionHistory(instanceId).isEmpty());
    }
    
    @Test
    void testClear() {
        // Given
        persistence.saveState("instance-1", new StateMachineSnapshot<>("instance-1", TestState.INITIAL));
        persistence.saveState("instance-2", new StateMachineSnapshot<>("instance-2", TestState.INITIAL));
        
        // When
        persistence.clear();
        
        // Then
        assertNull(persistence.loadState("instance-1"));
        assertNull(persistence.loadState("instance-2"));
    }
}

