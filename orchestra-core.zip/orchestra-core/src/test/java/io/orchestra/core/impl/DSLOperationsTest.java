package io.orchestra.core.impl;

import io.orchestra.core.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.*;

/**
 * DSL 操作的集成测试。
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
class DSLOperationsTest {
    
    private ReactiveApplicator<String, String, StandardRuntimeContext<String, String>> applicator;
    private Composer composer;
    
    @BeforeEach
    void setUp() {
        applicator = new ReactiveApplicator<>();
        composer = applicator.getComposer();
    }
    
    @Test
    void testSyncConsumer() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger counter = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> counter.incrementAndGet());
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(1, counter.get());
        assertEquals(context, result);
    }
    
    @Test
    void testSyncFunction() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync(c -> {
                    c.setAttribute("processed", true);
                    return "result";
                });
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        Boolean processed = result.getAttribute("processed");
        assertTrue(processed != null && processed);
    }
    
    @Test
    void testAsyncSupplier() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger counter = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .async(() -> {
                    counter.incrementAndGet();
                    return "async-result";
                });
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(1, counter.get());
        assertEquals(context, result);
    }
    
    @Test
    void testAsyncFunction() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger counter = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .async(c -> CompletableFuture.supplyAsync(() -> {
                    counter.incrementAndGet();
                    return "async-result";
                }));
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(1, counter.get());
        assertEquals(context, result);
    }
    
    @Test
    void testParallel() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger counter1 = new AtomicInteger(0);
        AtomicInteger counter2 = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .parallel(
                    stream -> stream.sync((Consumer<StandardRuntimeContext<String, String>>) c -> counter1.incrementAndGet()),
                    stream -> stream.sync((Consumer<StandardRuntimeContext<String, String>>) c -> counter2.incrementAndGet())
                );
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(1, counter1.get());
        assertEquals(1, counter2.get());
        assertEquals(context, result);
    }
    
    @Test
    void testBranchTrue() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger trueCounter = new AtomicInteger(0);
        AtomicInteger falseCounter = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .branch(
                    c -> true,
                    branch -> branch.sync((Consumer<StandardRuntimeContext<String, String>>) c -> trueCounter.incrementAndGet()),
                    branch -> branch.sync((Consumer<StandardRuntimeContext<String, String>>) c -> falseCounter.incrementAndGet())
                );
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(1, trueCounter.get());
        assertEquals(0, falseCounter.get());
        assertEquals(context, result);
    }
    
    @Test
    void testBranchFalse() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger trueCounter = new AtomicInteger(0);
        AtomicInteger falseCounter = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .branch(
                    c -> false,
                    branch -> branch.sync((Consumer<StandardRuntimeContext<String, String>>) c -> trueCounter.incrementAndGet()),
                    branch -> branch.sync((Consumer<StandardRuntimeContext<String, String>>) c -> falseCounter.incrementAndGet())
                );
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(0, trueCounter.get());
        assertEquals(1, falseCounter.get());
        assertEquals(context, result);
    }
    
    @Test
    void testBranchSingle_True() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger counter = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .branch(
                    c -> true,
                    branch -> branch.sync((Consumer<StandardRuntimeContext<String, String>>) c -> counter.incrementAndGet())
                );
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(1, counter.get());
        assertEquals(context, result);
    }
    
    @Test
    void testBranchSingle_False() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger counter = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .branch(
                    c -> false,
                    branch -> branch.sync((Consumer<StandardRuntimeContext<String, String>>) c -> counter.incrementAndGet())
                );
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(0, counter.get());
        assertEquals(context, result);
    }
    
    @Test
    void testChainedOperations() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger step1 = new AtomicInteger(0);
        AtomicInteger step2 = new AtomicInteger(0);
        AtomicInteger step3 = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> step1.incrementAndGet())
                .async(() -> {
                    step2.incrementAndGet();
                    return "async";
                })
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> step3.incrementAndGet());
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(1, step1.get());
        assertEquals(1, step2.get());
        assertEquals(1, step3.get());
        assertEquals(context, result);
    }
}

