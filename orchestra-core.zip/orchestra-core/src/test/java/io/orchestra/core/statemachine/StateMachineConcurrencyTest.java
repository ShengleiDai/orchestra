package io.orchestra.core.statemachine;

import io.orchestra.core.StandardRuntimeContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 状态机并发测试，验证并发冲突防护机制。
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
class StateMachineConcurrencyTest {
    
    enum TestState {
        INITIAL,
        PROCESSING,
        COMPLETED
    }
    
    static class StartEvent {}
    static class CompleteEvent {}
    
    private StateMachineBuilder<TestState, Object, StandardRuntimeContext<String, String>> builder;
    
    @BeforeEach
    void setUp() {
        builder = new StateMachineBuilder<>();
    }
    
    @Test
    void testConcurrentTransition_ShouldPreventRaceCondition() throws InterruptedException {
        // Given
        int threadCount = 10;
        int iterationsPerThread = 10;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch startLatch = new CountDownLatch(1);
        CountDownLatch finishLatch = new CountDownLatch(threadCount);
        AtomicInteger successCount = new AtomicInteger(0);
        AtomicInteger conflictCount = new AtomicInteger(0);
        AtomicReference<Exception> lastException = new AtomicReference<>();
        
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        StateMachine<TestState, Object, StandardRuntimeContext<String, String>> stateMachine = builder
            .initial(TestState.INITIAL)
            .transition(TestState.INITIAL, StartEvent.class, TestState.PROCESSING)
            .transition(TestState.PROCESSING, CompleteEvent.class, TestState.COMPLETED)
            .build();
        
        // When - 多个线程同时尝试从 INITIAL 转换到 PROCESSING
        for (int i = 0; i < threadCount; i++) {
            executor.submit(() -> {
                try {
                    startLatch.await(); // 等待所有线程准备就绪
                    
                    for (int j = 0; j < iterationsPerThread; j++) {
                        try {
                            // 尝试从 INITIAL 转换到 PROCESSING
                            if (stateMachine.getCurrentState() == TestState.INITIAL) {
                                stateMachine.transition(context, new StartEvent());
                                successCount.incrementAndGet();
                            }
                        } catch (IllegalStateException e) {
                            // 捕获版本冲突异常
                            if (e.getMessage() != null && e.getMessage().contains("conflict")) {
                                conflictCount.incrementAndGet();
                            } else {
                                // 其他非法状态异常（如已经在 PROCESSING 状态）
                                // 这是正常的，因为只有一个线程能成功转换
                            }
                        } catch (Exception e) {
                            lastException.set(e);
                        }
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    finishLatch.countDown();
                }
            });
        }
        
        // 启动所有线程
        startLatch.countDown();
        
        // 等待所有线程完成
        assertTrue(finishLatch.await(10, TimeUnit.SECONDS), "Test timeout");
        executor.shutdown();
        assertTrue(executor.awaitTermination(5, TimeUnit.SECONDS));
        
        // Then
        // 应该只有一个线程成功转换（从 INITIAL 到 PROCESSING）
        // 其他线程应该因为状态已经改变而失败，或者因为版本冲突而失败
        TestState finalState = stateMachine.getCurrentState();
        assertTrue(finalState == TestState.PROCESSING || finalState == TestState.COMPLETED,
                   "Final state should be PROCESSING or COMPLETED");
        
        // 验证没有未捕获的异常
        if (lastException.get() != null) {
            fail("Unexpected exception: " + lastException.get());
        }
        
        // 验证至少有一个成功的转换
        assertTrue(successCount.get() > 0, "At least one transition should succeed");
    }
    
    @Test
    void testConcurrentTransition_WithVersionCheck() throws InterruptedException {
        // Given
        int threadCount = 5;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch startLatch = new CountDownLatch(1);
        CountDownLatch finishLatch = new CountDownLatch(threadCount);
        AtomicInteger successCount = new AtomicInteger(0);
        AtomicInteger conflictCount = new AtomicInteger(0);
        
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        StateMachine<TestState, Object, StandardRuntimeContext<String, String>> stateMachine = builder
            .initial(TestState.INITIAL)
            .transition(TestState.INITIAL, StartEvent.class, TestState.PROCESSING)
            .build();
        
        // When - 多个线程同时尝试转换
        for (int i = 0; i < threadCount; i++) {
            final int threadId = i;
            executor.submit(() -> {
                try {
                    startLatch.await();
                    
                    try {
                        stateMachine.transition(context, new StartEvent());
                        successCount.incrementAndGet();
                        System.out.println("Thread " + threadId + " succeeded");
                    } catch (IllegalStateException e) {
                        if (e.getMessage() != null && e.getMessage().contains("conflict")) {
                            conflictCount.incrementAndGet();
                            System.out.println("Thread " + threadId + " conflict: " + e.getMessage());
                        } else {
                            System.out.println("Thread " + threadId + " failed: " + e.getMessage());
                        }
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    finishLatch.countDown();
                }
            });
        }
        
        startLatch.countDown();
        assertTrue(finishLatch.await(5, TimeUnit.SECONDS));
        executor.shutdown();
        
        // Then
        // 应该只有一个线程成功
        assertEquals(1, successCount.get(), "Only one thread should succeed");
        // 最终状态应该是 PROCESSING
        assertEquals(TestState.PROCESSING, stateMachine.getCurrentState());
    }
    
    @Test
    void testStateSnapshot_ThreadSafety() throws InterruptedException {
        // Given
        int threadCount = 10;
        ExecutorService executor = Executors.newFixedThreadPool(threadCount);
        CountDownLatch startLatch = new CountDownLatch(1);
        CountDownLatch finishLatch = new CountDownLatch(threadCount);
        AtomicInteger versionMismatchCount = new AtomicInteger(0);
        
        InMemoryStatePersistence<TestState, Object> persistence = new InMemoryStatePersistence<>();
        String instanceId = "test-instance";
        
        // When - 多个线程同时保存和加载状态
        for (int i = 0; i < threadCount; i++) {
            final int threadId = i;
            executor.submit(() -> {
                try {
                    startLatch.await();
                    
                    for (int j = 0; j < 10; j++) {
                        // 加载状态
                        StateMachineSnapshot<TestState, Object> snapshot = persistence.loadState(instanceId);
                        
                        if (snapshot == null) {
                            // 创建新快照
                            snapshot = new StateMachineSnapshot<>(instanceId, TestState.INITIAL);
                        }
                        
                        // 更新版本
                        int oldVersion = snapshot.getVersion();
                        snapshot.incrementVersion();
                        
                        // 保存状态
                        persistence.saveState(instanceId, snapshot);
                        
                        // 验证版本号递增
                        StateMachineSnapshot<TestState, Object> reloaded = persistence.loadState(instanceId);
                        if (reloaded != null && reloaded.getVersion() <= oldVersion) {
                            versionMismatchCount.incrementAndGet();
                        }
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    finishLatch.countDown();
                }
            });
        }
        
        startLatch.countDown();
        assertTrue(finishLatch.await(10, TimeUnit.SECONDS));
        executor.shutdown();
        
        // Then
        // 版本号应该正确递增（虽然可能有冲突，但最终版本应该合理）
        StateMachineSnapshot<TestState, Object> finalSnapshot = persistence.loadState(instanceId);
        assertNotNull(finalSnapshot);
        assertTrue(finalSnapshot.getVersion() >= 0);
    }
}

