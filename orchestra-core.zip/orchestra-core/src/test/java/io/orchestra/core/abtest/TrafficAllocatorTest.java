package io.orchestra.core.abtest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 流量分配器测试。
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
class TrafficAllocatorTest {
    
    private DefaultTrafficAllocator allocator;
    private InMemoryTrafficAllocationPersistence persistence;
    
    @BeforeEach
    void setUp() {
        allocator = new DefaultTrafficAllocator();
        persistence = new InMemoryTrafficAllocationPersistence();
    }
    
    @Test
    void testAllocate_FirstTime() {
        // Given
        String experimentId = "test-experiment";
        String userId = "user-123";
        List<Variant> variants = Arrays.asList(
            new Variant("A", 0.5),
            new Variant("B", 0.5)
        );
        
        // When
        String allocated = allocator.allocate(experimentId, userId, variants, persistence);
        
        // Then
        assertNotNull(allocated);
        assertTrue(allocated.equals("A") || allocated.equals("B"));
        assertEquals(allocated, persistence.getAllocation(experimentId, userId));
    }
    
    @Test
    void testAllocate_Consistent() {
        // Given
        String experimentId = "test-experiment";
        String userId = "user-123";
        List<Variant> variants = Arrays.asList(
            new Variant("A", 0.5),
            new Variant("B", 0.5)
        );
        
        // When - 多次分配应该返回相同结果
        String first = allocator.allocate(experimentId, userId, variants, persistence);
        String second = allocator.allocate(experimentId, userId, variants, persistence);
        String third = allocator.allocate(experimentId, userId, variants, persistence);
        
        // Then
        assertEquals(first, second);
        assertEquals(second, third);
    }
    
    @Test
    void testAllocate_DifferentUsers() {
        // Given
        String experimentId = "test-experiment";
        List<Variant> variants = Arrays.asList(
            new Variant("A", 0.5),
            new Variant("B", 0.5)
        );
        
        // When
        String user1 = allocator.allocate(experimentId, "user-1", variants, persistence);
        String user2 = allocator.allocate(experimentId, "user-2", variants, persistence);
        String user3 = allocator.allocate(experimentId, "user-3", variants, persistence);
        
        // Then - 不同用户可能分配到不同变体（也可能相同，取决于哈希）
        assertNotNull(user1);
        assertNotNull(user2);
        assertNotNull(user3);
        assertTrue(user1.equals("A") || user1.equals("B"));
        assertTrue(user2.equals("A") || user2.equals("B"));
        assertTrue(user3.equals("A") || user3.equals("B"));
    }
    
    @Test
    void testAllocate_ThreeVariants() {
        // Given
        String experimentId = "test-experiment";
        String userId = "user-123";
        List<Variant> variants = Arrays.asList(
            new Variant("A", 0.33),
            new Variant("B", 0.33),
            new Variant("C", 0.34)
        );
        
        // When
        String allocated = allocator.allocate(experimentId, userId, variants, persistence);
        
        // Then
        assertNotNull(allocated);
        assertTrue(allocated.equals("A") || allocated.equals("B") || allocated.equals("C"));
    }
    
    @Test
    void testValidateVariants_Valid() {
        // Given
        List<Variant> variants = Arrays.asList(
            new Variant("A", 0.5),
            new Variant("B", 0.5)
        );
        
        // When & Then
        assertTrue(allocator.validateVariants(variants));
    }
    
    @Test
    void testValidateVariants_InvalidSum() {
        // Given
        List<Variant> variants = Arrays.asList(
            new Variant("A", 0.5),
            new Variant("B", 0.4)  // 总和不是 1.0
        );
        
        // When & Then
        assertFalse(allocator.validateVariants(variants));
    }
    
    @Test
    void testValidateVariants_DuplicateNames() {
        // Given
        List<Variant> variants = Arrays.asList(
            new Variant("A", 0.5),
            new Variant("A", 0.5)  // 重复的名称
        );
        
        // When & Then
        assertFalse(allocator.validateVariants(variants));
    }
    
    @Test
    void testValidateVariants_Empty() {
        // When & Then
        assertFalse(allocator.validateVariants(null));
        assertFalse(allocator.validateVariants(Arrays.asList()));
    }
    
    @Test
    void testAllocate_InvalidVariants() {
        // Given
        String experimentId = "test-experiment";
        String userId = "user-123";
        List<Variant> invalidVariants = Arrays.asList(
            new Variant("A", 0.5),
            new Variant("B", 0.4)  // 总和不是 1.0
        );
        
        // When & Then
        assertThrows(IllegalArgumentException.class, () -> {
            allocator.allocate(experimentId, userId, invalidVariants, persistence);
        });
    }
}

