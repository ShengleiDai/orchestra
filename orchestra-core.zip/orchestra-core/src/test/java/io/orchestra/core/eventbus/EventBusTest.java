package io.orchestra.core.eventbus;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 事件总线的单元测试。
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
class EventBusTest {
    
    static class TestEvent extends BaseEvent {
        private final String message;
        
        public TestEvent(String message) {
            this.message = message;
        }
        
        public String getMessage() {
            return message;
        }
    }
    
    static class AnotherEvent extends BaseEvent {
        private final int value;
        
        public AnotherEvent(int value) {
            this.value = value;
        }
        
        public int getValue() {
            return value;
        }
    }
    
    private EventBus eventBus;
    
    @BeforeEach
    void setUp() {
        eventBus = new InMemoryEventBus();
    }
    
    @AfterEach
    void tearDown() {
        if (eventBus != null) {
            eventBus.shutdown();
        }
    }
    
    @Test
    void testPublishAndSubscribe() throws Exception {
        // Given
        AtomicInteger handlerCallCount = new AtomicInteger(0);
        AtomicReference<String> receivedMessage = new AtomicReference<>();
        
        eventBus.subscribe(TestEvent.class, event -> {
            handlerCallCount.incrementAndGet();
            receivedMessage.set(event.getMessage());
        });
        
        // When
        TestEvent event = new TestEvent("Hello World");
        eventBus.publish(event);
        
        // Then
        Thread.sleep(100); // 等待异步处理完成
        assertEquals(1, handlerCallCount.get());
        assertEquals("Hello World", receivedMessage.get());
    }
    
    @Test
    void testPublishAsync() throws Exception {
        // Given
        AtomicInteger handlerCallCount = new AtomicInteger(0);
        
        eventBus.subscribe(TestEvent.class, event -> {
            handlerCallCount.incrementAndGet();
        });
        
        // When
        TestEvent event = new TestEvent("Async Test");
        CompletableFuture<Void> future = eventBus.publishAsync(event);
        
        // Then
        future.get(1, TimeUnit.SECONDS);
        Thread.sleep(100); // 等待处理完成
        assertEquals(1, handlerCallCount.get());
    }
    
    @Test
    void testMultipleSubscribers() throws Exception {
        // Given
        AtomicInteger count1 = new AtomicInteger(0);
        AtomicInteger count2 = new AtomicInteger(0);
        
        eventBus.subscribe(TestEvent.class, event -> count1.incrementAndGet());
        eventBus.subscribe(TestEvent.class, event -> count2.incrementAndGet());
        
        // When
        eventBus.publish(new TestEvent("Multiple"));
        
        // Then
        Thread.sleep(100);
        assertEquals(1, count1.get());
        assertEquals(1, count2.get());
    }
    
    @Test
    void testUnsubscribe() throws Exception {
        // Given
        AtomicInteger count = new AtomicInteger(0);
        String subscriptionId = eventBus.subscribe(TestEvent.class, event -> count.incrementAndGet());
        
        // When
        eventBus.publish(new TestEvent("Before unsubscribe"));
        Thread.sleep(100);
        assertEquals(1, count.get());
        
        eventBus.unsubscribe(subscriptionId);
        eventBus.publish(new TestEvent("After unsubscribe"));
        Thread.sleep(100);
        
        // Then
        assertEquals(1, count.get()); // 应该还是 1，因为已取消订阅
    }
    
    @Test
    void testUnsubscribeByType() throws Exception {
        // Given
        AtomicInteger count = new AtomicInteger(0);
        eventBus.subscribe(TestEvent.class, event -> count.incrementAndGet());
        
        // When
        eventBus.publish(new TestEvent("Before unsubscribe"));
        Thread.sleep(100);
        assertEquals(1, count.get());
        
        eventBus.unsubscribe(TestEvent.class);
        eventBus.publish(new TestEvent("After unsubscribe"));
        Thread.sleep(100);
        
        // Then
        assertEquals(1, count.get()); // 应该还是 1
    }
    
    @Test
    void testAwait_Success() throws Exception {
        // Given
        TestEvent event = new TestEvent("Await Test");
        
        // When - 在另一个线程中发布事件
        new Thread(() -> {
            try {
                Thread.sleep(100);
                eventBus.publish(event);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
        
        // Then - 等待事件
        TestEvent received = eventBus.await(TestEvent.class, 1000);
        assertNotNull(received);
        assertEquals("Await Test", received.getMessage());
    }
    
    @Test
    void testAwait_Timeout() throws Exception {
        // When & Then
        TestEvent received = eventBus.await(TestEvent.class, 100);
        assertNull(received); // 超时应该返回 null
    }
    
    @Test
    void testEventTypeFiltering() throws Exception {
        // Given
        AtomicInteger testEventCount = new AtomicInteger(0);
        AtomicInteger anotherEventCount = new AtomicInteger(0);
        
        eventBus.subscribe(TestEvent.class, event -> testEventCount.incrementAndGet());
        eventBus.subscribe(AnotherEvent.class, event -> anotherEventCount.incrementAndGet());
        
        // When
        eventBus.publish(new TestEvent("Test"));
        eventBus.publish(new AnotherEvent(42));
        
        // Then
        Thread.sleep(100);
        assertEquals(1, testEventCount.get());
        assertEquals(1, anotherEventCount.get());
    }
    
    @Test
    void testShutdown() {
        // Given
        AtomicInteger count = new AtomicInteger(0);
        eventBus.subscribe(TestEvent.class, event -> count.incrementAndGet());
        
        // When
        eventBus.shutdown();
        
        // Then
        assertThrows(EventBusException.class, () -> {
            eventBus.publish(new TestEvent("After shutdown"));
        });
    }
}

