package io.orchestra.core.impl;

import io.orchestra.core.Composer;
import io.orchestra.core.Procedure;
import io.orchestra.core.ProcedureCase;
import io.orchestra.core.ProcedureManager;
import io.orchestra.core.RuntimeContext;
import io.orchestra.core.StandardRuntimeContext;
import io.orchestra.core.abtest.Variant;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Procedure 组合功能的单元测试。
 * 
 * <p>测试 ProcedureManager 中支持传递 Procedure 参数的各种操作。</p>
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
class ProcedureCompositionTest {
    
    private Composer composer;
    private RuntimeContext<String, String> context;
    
    @BeforeEach
    void setUp() {
        composer = new DefaultComposer();
        context = new StandardRuntimeContext<>("test-request");
    }
    
    /**
     * 测试同步执行 Procedure。
     */
    @Test
    void testSyncProcedure() {
        // Given
        AtomicInteger counter = new AtomicInteger(0);
        Procedure<String, String, RuntimeContext<String, String>> testProcedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((RuntimeContext<String, String> c) -> { counter.incrementAndGet(); });
        
        // When
        ProcedureManager<RuntimeContext<String, String>> manager = composer.just(context);
        manager.sync(testProcedure);
        
        // Execute
        DefaultProcedureManager<RuntimeContext<String, String>> procManager = 
            (DefaultProcedureManager<RuntimeContext<String, String>>) manager;
        ProcedureExecutor<RuntimeContext<String, String>> executor = new ProcedureExecutor<>();
        executor.executeSteps(procManager.getSteps(), context, procManager);
        
        // Then
        assertEquals(1, counter.get());
    }
    
    /**
     * 测试异步执行 Procedure。
     */
    @Test
    void testAsyncProcedure() {
        // Given
        AtomicInteger counter = new AtomicInteger(0);
        Procedure<String, String, RuntimeContext<String, String>> testProcedure = 
            (ctx, comp) -> comp.just(ctx)
                .async(() -> {
                    counter.incrementAndGet();
                    return CompletableFuture.completedFuture(null);
                });
        
        // When
        ProcedureManager<RuntimeContext<String, String>> manager = composer.just(context);
        manager.async(testProcedure);
        
        // Execute
        DefaultProcedureManager<RuntimeContext<String, String>> procManager = 
            (DefaultProcedureManager<RuntimeContext<String, String>>) manager;
        ProcedureExecutor<RuntimeContext<String, String>> executor = new ProcedureExecutor<>();
        executor.executeSteps(procManager.getSteps(), context, procManager);
        
        // Then
        assertEquals(1, counter.get());
    }
    
    /**
     * 测试并行执行多个 Procedure。
     */
    @Test
    void testParallelProcedures() {
        // Given
        AtomicInteger counter1 = new AtomicInteger(0);
        AtomicInteger counter2 = new AtomicInteger(0);
        AtomicInteger counter3 = new AtomicInteger(0);
        
        Procedure<String, String, RuntimeContext<String, String>> proc1 = 
            (ctx, comp) -> comp.just(ctx).sync((RuntimeContext<String, String> c) -> { counter1.incrementAndGet(); });
        Procedure<String, String, RuntimeContext<String, String>> proc2 = 
            (ctx, comp) -> comp.just(ctx).sync((RuntimeContext<String, String> c) -> { counter2.incrementAndGet(); });
        Procedure<String, String, RuntimeContext<String, String>> proc3 = 
            (ctx, comp) -> comp.just(ctx).sync((RuntimeContext<String, String> c) -> { counter3.incrementAndGet(); });
        
        // When
        ProcedureManager<RuntimeContext<String, String>> manager = composer.just(context);
        @SuppressWarnings("unchecked")
        Procedure<String, String, RuntimeContext<String, String>>[] procedures = 
            new Procedure[] { proc1, proc2, proc3 };
        manager.parallel(procedures);
        
        // Execute
        DefaultProcedureManager<RuntimeContext<String, String>> procManager = 
            (DefaultProcedureManager<RuntimeContext<String, String>>) manager;
        ProcedureExecutor<RuntimeContext<String, String>> executor = new ProcedureExecutor<>();
        executor.executeSteps(procManager.getSteps(), context, procManager);
        
        // Then
        assertEquals(1, counter1.get());
        assertEquals(1, counter2.get());
        assertEquals(1, counter3.get());
    }
    
    /**
     * 测试条件分支 Procedure（双分支）。
     */
    @Test
    void testBranchProcedure_DualBranch() {
        // Given
        AtomicInteger trueCounter = new AtomicInteger(0);
        AtomicInteger falseCounter = new AtomicInteger(0);
        
        Procedure<String, String, RuntimeContext<String, String>> trueProc = 
            (ctx, comp) -> comp.just(ctx).sync((RuntimeContext<String, String> c) -> { trueCounter.incrementAndGet(); });
        Procedure<String, String, RuntimeContext<String, String>> falseProc = 
            (ctx, comp) -> comp.just(ctx).sync((RuntimeContext<String, String> c) -> { falseCounter.incrementAndGet(); });
        
        // When - true branch
        ProcedureManager<RuntimeContext<String, String>> manager1 = composer.just(context);
        manager1.branch(c -> true, trueProc, falseProc);
        
        DefaultProcedureManager<RuntimeContext<String, String>> procManager1 = 
            (DefaultProcedureManager<RuntimeContext<String, String>>) manager1;
        ProcedureExecutor<RuntimeContext<String, String>> executor1 = new ProcedureExecutor<>();
        executor1.executeSteps(procManager1.getSteps(), context, procManager1);
        
        // Then
        assertEquals(1, trueCounter.get());
        assertEquals(0, falseCounter.get());
        
        // When - false branch
        ProcedureManager<RuntimeContext<String, String>> manager2 = composer.just(context);
        manager2.branch(c -> false, trueProc, falseProc);
        
        DefaultProcedureManager<RuntimeContext<String, String>> procManager2 = 
            (DefaultProcedureManager<RuntimeContext<String, String>>) manager2;
        ProcedureExecutor<RuntimeContext<String, String>> executor2 = new ProcedureExecutor<>();
        executor2.executeSteps(procManager2.getSteps(), context, procManager2);
        
        // Then
        assertEquals(1, trueCounter.get());
        assertEquals(1, falseCounter.get());
    }
    
    /**
     * 测试条件分支 Procedure（单分支）。
     */
    @Test
    void testBranchProcedure_SingleBranch() {
        // Given
        AtomicInteger counter = new AtomicInteger(0);
        
        Procedure<String, String, RuntimeContext<String, String>> proc = 
            (ctx, comp) -> comp.just(ctx).sync((RuntimeContext<String, String> c) -> { counter.incrementAndGet(); });
        
        // When - condition is true
        ProcedureManager<RuntimeContext<String, String>> manager1 = composer.just(context);
        manager1.branch(c -> true, proc);
        
        DefaultProcedureManager<RuntimeContext<String, String>> procManager1 = 
            (DefaultProcedureManager<RuntimeContext<String, String>>) manager1;
        ProcedureExecutor<RuntimeContext<String, String>> executor1 = new ProcedureExecutor<>();
        executor1.executeSteps(procManager1.getSteps(), context, procManager1);
        
        // Then
        assertEquals(1, counter.get());
        
        // When - condition is false
        ProcedureManager<RuntimeContext<String, String>> manager2 = composer.just(context);
        manager2.branch(c -> false, proc);
        
        DefaultProcedureManager<RuntimeContext<String, String>> procManager2 = 
            (DefaultProcedureManager<RuntimeContext<String, String>>) manager2;
        ProcedureExecutor<RuntimeContext<String, String>> executor2 = new ProcedureExecutor<>();
        executor2.executeSteps(procManager2.getSteps(), context, procManager2);
        
        // Then - should not execute
        assertEquals(1, counter.get());
    }
    
    /**
     * 测试多分支选择 Procedure。
     */
    @Test
    void testSelectProcedure() {
        // Given
        AtomicInteger vipCounter = new AtomicInteger(0);
        AtomicInteger normalCounter = new AtomicInteger(0);
        AtomicInteger defaultCounter = new AtomicInteger(0);
        
        Procedure<String, String, RuntimeContext<String, String>> vipProc = 
            (ctx, comp) -> comp.just(ctx).sync((RuntimeContext<String, String> c) -> { vipCounter.incrementAndGet(); });
        Procedure<String, String, RuntimeContext<String, String>> normalProc = 
            (ctx, comp) -> comp.just(ctx).sync((RuntimeContext<String, String> c) -> { normalCounter.incrementAndGet(); });
        Procedure<String, String, RuntimeContext<String, String>> defaultProc = 
            (ctx, comp) -> comp.just(ctx).sync((RuntimeContext<String, String> c) -> { defaultCounter.incrementAndGet(); });
        
        // When - VIP case
        RuntimeContext<String, String> vipContext = new StandardRuntimeContext<>("test");
        vipContext.setAttribute("orderType", "VIP");
        
        ProcedureManager<RuntimeContext<String, String>> manager1 = composer.just(vipContext);
        @SuppressWarnings("unchecked")
        ProcedureCase<String, ?, ?, RuntimeContext<String, String>>[] cases1 = 
            new ProcedureCase[] {
                ProcedureCase.of("VIP", vipProc),
                ProcedureCase.of("NORMAL", normalProc),
                ProcedureCase.defaultCase(defaultProc)
            };
        manager1.select(c -> (String) c.getAttribute("orderType"), cases1);
        
        DefaultProcedureManager<RuntimeContext<String, String>> procManager1 = 
            (DefaultProcedureManager<RuntimeContext<String, String>>) manager1;
        ProcedureExecutor<RuntimeContext<String, String>> executor1 = new ProcedureExecutor<>();
        executor1.executeSteps(procManager1.getSteps(), vipContext, procManager1);
        
        // Then
        assertEquals(1, vipCounter.get());
        assertEquals(0, normalCounter.get());
        assertEquals(0, defaultCounter.get());
        
        // When - default case
        RuntimeContext<String, String> unknownContext = new StandardRuntimeContext<>("test");
        unknownContext.setAttribute("orderType", "UNKNOWN");
        
        ProcedureManager<RuntimeContext<String, String>> manager2 = composer.just(unknownContext);
        @SuppressWarnings("unchecked")
        ProcedureCase<String, ?, ?, RuntimeContext<String, String>>[] cases2 = 
            new ProcedureCase[] {
                ProcedureCase.of("VIP", vipProc),
                ProcedureCase.of("NORMAL", normalProc),
                ProcedureCase.defaultCase(defaultProc)
            };
        manager2.select(c -> (String) c.getAttribute("orderType"), cases2);
        
        DefaultProcedureManager<RuntimeContext<String, String>> procManager2 = 
            (DefaultProcedureManager<RuntimeContext<String, String>>) manager2;
        ProcedureExecutor<RuntimeContext<String, String>> executor2 = new ProcedureExecutor<>();
        executor2.executeSteps(procManager2.getSteps(), unknownContext, procManager2);
        
        // Then
        assertEquals(1, vipCounter.get());
        assertEquals(0, normalCounter.get());
        assertEquals(1, defaultCounter.get());
    }
    
    /**
     * 测试错误降级 Procedure。
     */
    @Test
    void testOnErrorResumeProcedure() {
        // Given
        AtomicInteger fallbackCounter = new AtomicInteger(0);
        
        Procedure<String, String, RuntimeContext<String, String>> failingProc = 
            (ctx, comp) -> comp.just(ctx)
                .sync((RuntimeContext<String, String> c) -> {
                    throw new RuntimeException("Test error");
                });
        
        Procedure<String, String, RuntimeContext<String, String>> fallbackProc = 
            (ctx, comp) -> comp.just(ctx)
                .sync((RuntimeContext<String, String> c) -> { fallbackCounter.incrementAndGet(); });
        
        // When
        ProcedureManager<RuntimeContext<String, String>> manager = composer.just(context);
        manager.sync(failingProc)
            .onErrorResume(RuntimeException.class, fallbackProc);
        
        // Execute
        DefaultProcedureManager<RuntimeContext<String, String>> procManager = 
            (DefaultProcedureManager<RuntimeContext<String, String>>) manager;
        ProcedureExecutor<RuntimeContext<String, String>> executor = new ProcedureExecutor<>();
        
        // Should not throw exception, should execute fallback
        assertDoesNotThrow(() -> {
            executor.executeSteps(procManager.getSteps(), context, procManager);
        });
        
        // Then
        assertEquals(1, fallbackCounter.get());
    }
    
    /**
     * 测试超时处理 Procedure。
     */
    @Test
    void testTimeoutWithProcedure() {
        // Given
        AtomicInteger timeoutCounter = new AtomicInteger(0);
        
        Procedure<String, String, RuntimeContext<String, String>> slowProc = 
            (ctx, comp) -> comp.just(ctx)
                .async(() -> {
                    try {
                        Thread.sleep(2000); // 2 seconds
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    return CompletableFuture.completedFuture(null);
                });
        
        Procedure<String, String, RuntimeContext<String, String>> timeoutProc = 
            (ctx, comp) -> comp.just(ctx)
                .sync((RuntimeContext<String, String> c) -> { timeoutCounter.incrementAndGet(); });
        
        // When
        ProcedureManager<RuntimeContext<String, String>> manager = composer.just(context);
        manager.async(slowProc)
            .timeoutWithProcedure(100, TimeUnit.MILLISECONDS, timeoutProc);
        
        // Execute
        DefaultProcedureManager<RuntimeContext<String, String>> procManager = 
            (DefaultProcedureManager<RuntimeContext<String, String>>) manager;
        ProcedureExecutor<RuntimeContext<String, String>> executor = new ProcedureExecutor<>();
        
        // Should timeout and execute timeout procedure
        assertThrows(RuntimeException.class, () -> {
            executor.executeSteps(procManager.getSteps(), context, procManager);
        });
        
        // Then - timeout procedure should be executed
        assertEquals(1, timeoutCounter.get());
    }
    
    /**
     * 测试 A/B 测试 Procedure。
     */
    @Test
    void testAbTestProcedure() {
        // Given
        AtomicInteger variantACounter = new AtomicInteger(0);
        AtomicInteger variantBCounter = new AtomicInteger(0);
        
        Procedure<String, String, RuntimeContext<String, String>> variantA = 
            (ctx, comp) -> comp.just(ctx).sync((RuntimeContext<String, String> c) -> { variantACounter.incrementAndGet(); });
        Procedure<String, String, RuntimeContext<String, String>> variantB = 
            (ctx, comp) -> comp.just(ctx).sync((RuntimeContext<String, String> c) -> { variantBCounter.incrementAndGet(); });
        
        List<Variant> variants = Arrays.asList(
            new Variant("A", 0.5),
            new Variant("B", 0.5)
        );
        
        // When
        ProcedureManager<RuntimeContext<String, String>> manager = composer.just(context);
        @SuppressWarnings("unchecked")
        Procedure<String, String, RuntimeContext<String, String>>[] procedures = 
            new Procedure[] { variantA, variantB };
        manager.abTest("test-experiment", c -> "user-1", variants, procedures);
        
        // Execute
        DefaultProcedureManager<RuntimeContext<String, String>> procManager = 
            (DefaultProcedureManager<RuntimeContext<String, String>>) manager;
        ProcedureExecutor<RuntimeContext<String, String>> executor = new ProcedureExecutor<>();
        executor.executeSteps(procManager.getSteps(), context, procManager);
        
        // Then - one of the variants should be executed
        assertTrue(variantACounter.get() == 1 || variantBCounter.get() == 1);
        assertTrue(variantACounter.get() + variantBCounter.get() == 1);
    }
}

