package io.orchestra.core.impl;

import io.orchestra.core.*;
import io.orchestra.core.statemachine.StateMachine;
import io.orchestra.core.statemachine.StateMachineBuilder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 状态机 DSL 的集成测试。
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
class StateMachineDSLTest {
    
    // 测试用的状态枚举
    enum OrderState {
        CREATED,
        PAID,
        SHIPPED,
        DELIVERED,
        CANCELLED
    }
    
    // 测试用的事件类
    static class PaymentCompletedEvent {}
    static class OrderShippedEvent {}
    static class OrderDeliveredEvent {}
    static class OrderCancelledEvent {}
    
    private ReactiveApplicator<String, String, StandardRuntimeContext<String, String>> applicator;
    
    @BeforeEach
    void setUp() {
        applicator = new ReactiveApplicator<>();
    }
    
    @Test
    void testStateMachine_BasicUsage() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> {
                StateMachineManager<OrderState, Object, StandardRuntimeContext<String, String>> sm = 
                    comp.just(ctx)
                        .stateMachine(OrderState.class, builder -> {
                            builder.initial(OrderState.CREATED)
                                .transition(OrderState.CREATED, PaymentCompletedEvent.class, OrderState.PAID)
                                .transition(OrderState.PAID, OrderShippedEvent.class, OrderState.SHIPPED)
                                .transition(OrderState.SHIPPED, OrderDeliveredEvent.class, OrderState.DELIVERED)
                                .terminateOn(OrderState.DELIVERED, OrderState.CANCELLED);
                            return builder.build();
                        });
                
                // 执行状态转换
                sm.trigger(new PaymentCompletedEvent());
                sm.trigger(new OrderShippedEvent());
                sm.trigger(new OrderDeliveredEvent());
                
                return sm;
            };
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertNotNull(result);
        @SuppressWarnings("unchecked")
        StateMachineManager<OrderState, Object, StandardRuntimeContext<String, String>> sm = 
            (StateMachineManager<OrderState, Object, StandardRuntimeContext<String, String>>) 
            result.getAttribute("stateMachine");
        // 注意：状态机可能没有保存到结果中，需要从 procedure 返回的 StateMachineManager 获取
    }
    
    @Test
    void testStateMachine_WithCondition() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        context.setAttribute("vip", true);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> {
                StateMachineManager<OrderState, Object, StandardRuntimeContext<String, String>> sm = 
                    comp.just(ctx)
                        .stateMachine(OrderState.class, builder -> {
                            builder.initial(OrderState.CREATED)
                                .transition(OrderState.CREATED, PaymentCompletedEvent.class, OrderState.PAID,
                                           c -> Boolean.TRUE.equals(c.getAttribute("vip")))
                                .transition(OrderState.CREATED, OrderCancelledEvent.class, OrderState.CANCELLED,
                                           c -> !Boolean.TRUE.equals(c.getAttribute("vip")));
                            return builder.build();
                        });
                
                sm.trigger(new PaymentCompletedEvent());
                return sm;
            };
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertNotNull(result);
    }
    
    @Test
    void testStateMachine_WithAction() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        final boolean[] actionExecuted = {false};
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> {
                StateMachineManager<OrderState, Object, StandardRuntimeContext<String, String>> sm = 
                    comp.just(ctx)
                        .stateMachine(OrderState.class, builder -> {
                            builder.initial(OrderState.CREATED)
                                .transition(OrderState.CREATED, PaymentCompletedEvent.class, OrderState.PAID)
                                .onTransition((c, e) -> {
                                    actionExecuted[0] = true;
                                    c.setAttribute("lastEvent", e);
                                });
                            return builder.build();
                        });
                
                sm.trigger(new PaymentCompletedEvent());
                return sm;
            };
        
        // When
        applicator.apply(context, procedure);
        
        // Then
        assertTrue(actionExecuted[0]);
        assertNotNull(context.getAttribute("lastEvent"));
    }
    
    @Test
    void testStateMachine_InvalidTransition() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        
        // 直接在状态机上测试，不通过 Procedure
        StateMachineBuilder<OrderState, Object, StandardRuntimeContext<String, String>> builder = 
            new StateMachineBuilder<>();
        StateMachine<OrderState, Object, StandardRuntimeContext<String, String>> stateMachine = builder
            .initial(OrderState.CREATED)
            .transition(OrderState.CREATED, PaymentCompletedEvent.class, OrderState.PAID)
            .build();
        
        // When & Then - 尝试无效的转换应该抛出异常
        assertThrows(IllegalStateException.class, () -> {
            stateMachine.transition(context, new OrderShippedEvent());
        });
    }
    
    @Test
    void testStateMachine_GetCurrentState() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> {
                StateMachineManager<OrderState, Object, StandardRuntimeContext<String, String>> sm = 
                    comp.just(ctx)
                        .stateMachine(OrderState.class, builder -> {
                            builder.initial(OrderState.CREATED)
                                .transition(OrderState.CREATED, PaymentCompletedEvent.class, OrderState.PAID);
                            return builder.build();
                        });
                
                // When
                OrderState initialState = sm.getCurrentState();
                sm.trigger(new PaymentCompletedEvent());
                OrderState afterTransition = sm.getCurrentState();
                
                // Then
                assertEquals(OrderState.CREATED, initialState);
                assertEquals(OrderState.PAID, afterTransition);
                
                return sm;
            };
        
        // Execute
        applicator.apply(context, procedure);
    }
}

