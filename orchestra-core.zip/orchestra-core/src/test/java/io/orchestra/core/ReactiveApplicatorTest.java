package io.orchestra.core;

import io.orchestra.core.impl.DefaultComposer;
import io.reactivex.rxjava3.core.Single;
import io.reactivex.rxjava3.observers.TestObserver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

/**
 * ReactiveApplicator 的单元测试。
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
class ReactiveApplicatorTest {
    
    private ReactiveApplicator<String, String, StandardRuntimeContext<String, String>> applicator;
    
    @BeforeEach
    void setUp() {
        applicator = new ReactiveApplicator<>();
    }
    
    @Test
    void testConstructor_WithDefaultComposer_CreatesInstance() {
        // When
        ReactiveApplicator<String, String, StandardRuntimeContext<String, String>> app = 
            new ReactiveApplicator<>();
        
        // Then
        assertNotNull(app);
        assertNotNull(app.getComposer());
        assertTrue(app.getComposer() instanceof DefaultComposer);
    }
    
    @Test
    void testConstructor_WithCustomComposer_CreatesInstance() {
        // Given
        Composer customComposer = new DefaultComposer();
        
        // When
        ReactiveApplicator<String, String, StandardRuntimeContext<String, String>> app = 
            new ReactiveApplicator<>(customComposer);
        
        // Then
        assertNotNull(app);
        assertEquals(customComposer, app.getComposer());
    }
    
    @Test
    void testConstructor_WithNullComposer_ThrowsNullPointerException() {
        // When & Then
        assertThrows(NullPointerException.class, () -> {
            new ReactiveApplicator<>(null);
        });
    }
    
    @Test
    void testApply_WithValidContextAndProcedure_ReturnsContext() {
        // Given
        StandardRuntimeContext<String, String> context = 
            new StandardRuntimeContext<>("test-request");
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            new TestProcedure();
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertNotNull(result);
        assertEquals(context, result);
        assertEquals("test-request", result.getRequest());
    }
    
    @Test
    void testApply_WithNullContext_ThrowsNullPointerException() {
        // Given
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            new TestProcedure();
        
        // When & Then
        assertThrows(NullPointerException.class, () -> {
            applicator.apply(null, procedure);
        });
    }
    
    @Test
    void testApply_WithNullProcedure_ThrowsNullPointerException() {
        // Given
        StandardRuntimeContext<String, String> context = 
            new StandardRuntimeContext<>("test-request");
        
        // When & Then
        assertThrows(NullPointerException.class, () -> {
            applicator.apply(context, null);
        });
    }
    
    @Test
    void testApplyAsync_WithValidContextAndProcedure_ReturnsSingle() {
        // Given
        StandardRuntimeContext<String, String> context = 
            new StandardRuntimeContext<>("test-request");
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            new TestProcedure();
        
        // When
        Single<RuntimeContext<String, String>> single = 
            applicator.applyAsync(context, procedure);
        
        // Then
        assertNotNull(single);
        
        TestObserver<RuntimeContext<String, String>> observer = single.test();
        observer.awaitDone(5, TimeUnit.SECONDS);
        observer.assertComplete();
        observer.assertNoErrors();
        observer.assertValue(result -> {
            assertNotNull(result);
            assertEquals("test-request", result.getRequest());
            return true;
        });
    }
    
    @Test
    void testApplyAsync_WithNullContext_ThrowsNullPointerException() {
        // Given
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            new TestProcedure();
        
        // When & Then
        assertThrows(NullPointerException.class, () -> {
            applicator.applyAsync(null, procedure);
        });
    }
    
    @Test
    void testApplyAsync_WithNullProcedure_ThrowsNullPointerException() {
        // Given
        StandardRuntimeContext<String, String> context = 
            new StandardRuntimeContext<>("test-request");
        
        // When & Then
        assertThrows(NullPointerException.class, () -> {
            applicator.applyAsync(context, null);
        });
    }
    
    /**
     * 测试用的 Procedure 实现。
     */
    private static class TestProcedure implements Procedure<String, String, StandardRuntimeContext<String, String>> {
        @Override
        public Procedurable<StandardRuntimeContext<String, String>> execute(
                StandardRuntimeContext<String, String> context, 
                Composer composer) {
            // 返回一个简单的流程管理器
            return composer.just(context);
        }
    }
}

