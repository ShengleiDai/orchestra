package io.orchestra.core.impl;

import io.orchestra.core.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 错误处理机制的单元测试。
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
class ErrorHandlingTest {
    
    private ReactiveApplicator<String, String, StandardRuntimeContext<String, String>> applicator;
    
    @BeforeEach
    void setUp() {
        applicator = new ReactiveApplicator<>();
    }
    
    @Test
    void testOnErrorRetry_SuccessAfterRetry() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger attemptCount = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    int count = attemptCount.incrementAndGet();
                    if (count < 3) {
                        throw new RuntimeException("Temporary error");
                    }
                })
                .onErrorRetry(RuntimeException.class, 3);
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(3, attemptCount.get());
        assertEquals(context, result);
    }
    
    @Test
    void testOnErrorRetry_ExhaustedRetries() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger attemptCount = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    attemptCount.incrementAndGet();
                    throw new RuntimeException("Persistent error");
                })
                .onErrorRetry(RuntimeException.class, 2);
        
        // When & Then
        assertThrows(RuntimeException.class, () -> {
            applicator.apply(context, procedure);
        });
        assertTrue(attemptCount.get() >= 2);
    }
    
    @Test
    void testOnErrorResume() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger fallbackCount = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    throw new IllegalArgumentException("Test error");
                })
                .onErrorResume(IllegalArgumentException.class, error -> 
                    comp.just(context)
                        .sync((Consumer<StandardRuntimeContext<String, String>>) c -> 
                            fallbackCount.incrementAndGet()
                        )
                );
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(1, fallbackCount.get());
        assertEquals(context, result);
    }
    
    @Test
    void testOnError() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger errorHandlerCount = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    throw new IllegalStateException("Test error");
                })
                .onError(IllegalStateException.class, c -> {
                    errorHandlerCount.incrementAndGet();
                    c.setAttribute("error_handled", true);
                });
        
        // When & Then
        // onError 不会阻止异常传播
        assertThrows(RuntimeException.class, () -> {
            applicator.apply(context, procedure);
        });
        
        // 验证错误处理函数被调用
        assertEquals(1, errorHandlerCount.get());
        Boolean errorHandled = context.getAttribute("error_handled");
        assertTrue(errorHandled != null && errorHandled);
    }
    
    @Test
    void testTimeout() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger timeoutHandlerCount = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .async(() -> {
                    try {
                        Thread.sleep(2000); // 睡眠2秒
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    return "result";
                })
                .timeout(100, TimeUnit.MILLISECONDS, c -> {
                    timeoutHandlerCount.incrementAndGet();
                });
        
        // When & Then
        assertThrows(RuntimeException.class, () -> {
            applicator.apply(context, procedure);
        });
        // 验证超时处理函数被调用
        assertEquals(1, timeoutHandlerCount.get());
    }
    
    @Test
    void testErrorHandlingChain() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger retryCount = new AtomicInteger(0);
        AtomicInteger fallbackCount = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    int count = retryCount.incrementAndGet();
                    if (count <= 2) {
                        throw new RuntimeException("Retry error");
                    }
                    // 第3次成功，不再抛出异常
                })
                .onErrorRetry(RuntimeException.class, 2);
        
        // When
        RuntimeContext<String, String> result = applicator.apply(context, procedure);
        
        // Then
        assertEquals(3, retryCount.get()); // 初始执行 + 2次重试
        assertEquals(context, result);
    }
    
    @Test
    void testErrorTypeMatching() {
        // Given
        StandardRuntimeContext<String, String> context = new StandardRuntimeContext<>("test");
        AtomicInteger handlerCount = new AtomicInteger(0);
        
        Procedure<String, String, StandardRuntimeContext<String, String>> procedure = 
            (ctx, comp) -> comp.just(ctx)
                .sync((Consumer<StandardRuntimeContext<String, String>>) c -> {
                    throw new IllegalArgumentException("Test error");
                })
                .onError(RuntimeException.class, c -> handlerCount.incrementAndGet()); // 应该匹配（IllegalArgumentException 是 RuntimeException 的子类）
        
        // When & Then
        // onError 不会阻止异常传播
        assertThrows(RuntimeException.class, () -> {
            applicator.apply(context, procedure);
        });
        
        // 验证错误处理函数被调用
        assertEquals(1, handlerCount.get());
    }
}

