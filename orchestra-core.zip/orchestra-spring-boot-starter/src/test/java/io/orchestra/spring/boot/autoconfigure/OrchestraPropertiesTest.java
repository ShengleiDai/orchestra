package io.orchestra.spring.boot.autoconfigure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Orchestra 配置属性测试。
 */
@EnableConfigurationProperties(OrchestraProperties.class)
class OrchestraPropertiesTest {
    
    @Test
    void testPropertiesBinding() {
        OrchestraProperties properties = new OrchestraProperties();
        properties.setEnabled(true);
        properties.setDefaultTimeout(60);
        properties.getEventBus().setType("redis");
        properties.getEventBus().getRedis().setTopic("test:events");
        
        assertThat(properties.isEnabled()).isTrue();
        assertThat(properties.getDefaultTimeout()).isEqualTo(60);
        assertThat(properties.getEventBus().getType()).isEqualTo("redis");
        assertThat(properties.getEventBus().getRedis().getTopic()).isEqualTo("test:events");
    }
    
    @Test
    void testDefaultProperties() {
        OrchestraProperties properties = new OrchestraProperties();
        assertThat(properties.isEnabled()).isTrue();
        assertThat(properties.getDefaultTimeout()).isEqualTo(30);
        assertThat(properties.getEventBus().getType()).isEqualTo("local");
        assertThat(properties.getEventBus().getRedis().getTopic()).isEqualTo("orchestra:events");
    }
}

