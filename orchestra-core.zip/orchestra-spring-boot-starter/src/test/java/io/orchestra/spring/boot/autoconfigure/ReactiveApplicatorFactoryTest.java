package io.orchestra.spring.boot.autoconfigure;

import io.orchestra.core.Composer;
import io.orchestra.core.ReactiveApplicator;
import io.orchestra.core.RuntimeContext;
import io.orchestra.core.StandardRuntimeContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import io.orchestra.core.impl.DefaultComposer;

/**
 * ReactiveApplicatorFactory 测试。
 */
class ReactiveApplicatorFactoryTest {
    
    private ReactiveApplicatorFactory factory;
    private Composer composer;
    
    @BeforeEach
    void setUp() {
        composer = new DefaultComposer();
        factory = new ReactiveApplicatorFactory(composer);
    }
    
    @Test
    void testCreate() {
        ReactiveApplicator<TestRequest, TestResponse, TestContext> applicator = factory.create();
        
        assertThat(applicator).isNotNull();
        assertThat(applicator.getComposer()).isSameAs(composer);
    }
    
    @Test
    void testGetComposer() {
        assertThat(factory.getComposer()).isSameAs(composer);
    }
    
    // 测试辅助类
    static class TestRequest {}
    static class TestResponse {}
    static class TestContext extends StandardRuntimeContext<TestRequest, TestResponse> {
        public TestContext(TestRequest request) {
            super(request);
        }
    }
}

