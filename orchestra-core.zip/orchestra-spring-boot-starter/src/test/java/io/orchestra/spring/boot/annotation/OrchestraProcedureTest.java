package io.orchestra.spring.boot.annotation;

import io.orchestra.core.Composer;
import io.orchestra.core.Procedure;
import io.orchestra.core.Procedurable;
import io.orchestra.core.RuntimeContext;
import io.orchestra.core.StandardRuntimeContext;
import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * OrchestraProcedure 注解测试。
 */
class OrchestraProcedureTest {
    
    @Test
    void testOrchestraProcedureAnnotation() {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
        context.scan("io.orchestra.spring.boot.annotation");
        context.refresh();
        
        TestProcedure procedure = context.getBean(TestProcedure.class);
        assertThat(procedure).isNotNull();
        
        context.close();
    }
    
    @OrchestraProcedure
    static class TestProcedure implements Procedure<TestRequest, TestResponse, TestContext> {
        @Override
        public Procedurable<TestContext> execute(TestContext context, Composer composer) {
            return composer.just(context);
        }
    }
    
    static class TestRequest {}
    static class TestResponse {}
    static class TestContext extends StandardRuntimeContext<TestRequest, TestResponse> {
        public TestContext(TestRequest request) {
            super(request);
        }
    }
}


