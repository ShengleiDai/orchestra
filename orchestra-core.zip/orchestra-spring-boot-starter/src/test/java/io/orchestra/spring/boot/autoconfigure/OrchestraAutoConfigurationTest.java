package io.orchestra.spring.boot.autoconfigure;

import io.orchestra.core.Composer;
import io.orchestra.core.ReactiveApplicator;
import io.orchestra.core.RuntimeContext;
import io.orchestra.core.eventbus.EventBus;
import io.orchestra.core.eventbus.EventBusRegistry;
import io.orchestra.core.eventbus.InMemoryEventBus;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Orchestra 自动配置测试。
 */
class OrchestraAutoConfigurationTest {
    
    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
        .withConfiguration(AutoConfigurations.of(OrchestraAutoConfiguration.class));
    
    @AfterEach
    void tearDown() {
        EventBusRegistry.reset();
    }
    
    @Test
    void testAutoConfigurationEnabled() {
        contextRunner
            .withPropertyValues("orchestra.enabled=true")
            .run(context -> {
                assertThat(context).hasSingleBean(Composer.class);
                assertThat(context).hasSingleBean(ReactiveApplicatorFactory.class);
                assertThat(context).hasSingleBean(EventBus.class);
                assertThat(context.getBean(EventBus.class)).isInstanceOf(InMemoryEventBus.class);
            });
    }
    
    @Test
    void testAutoConfigurationDisabled() {
        contextRunner
            .withPropertyValues("orchestra.enabled=false")
            .run(context -> {
                assertThat(context).doesNotHaveBean(Composer.class);
                assertThat(context).doesNotHaveBean(ReactiveApplicatorFactory.class);
                assertThat(context).doesNotHaveBean(EventBus.class);
            });
    }
    
    @Test
    void testCustomComposer() {
        contextRunner
            .withUserConfiguration(CustomComposerConfiguration.class)
            .run(context -> {
                assertThat(context).hasSingleBean(Composer.class);
                assertThat(context.getBean(Composer.class)).isInstanceOf(CustomComposer.class);
            });
    }
    
    @Test
    void testCustomEventBus() {
        contextRunner
            .withUserConfiguration(CustomEventBusConfiguration.class)
            .run(context -> {
                assertThat(context).hasSingleBean(EventBus.class);
                assertThat(context.getBean(EventBus.class)).isInstanceOf(CustomEventBus.class);
            });
    }
    
    @Test
    void testReactiveApplicatorFactory() {
        contextRunner
            .run(context -> {
                ReactiveApplicatorFactory factory = context.getBean(ReactiveApplicatorFactory.class);
                assertThat(factory).isNotNull();
                
                ReactiveApplicator<TestRequest, TestResponse, TestContext> applicator = factory.create();
                assertThat(applicator).isNotNull();
                assertThat(applicator.getComposer()).isNotNull();
            });
    }
    
    @Test
    void testDefaultEventBusType() {
        contextRunner
            .withPropertyValues("orchestra.event-bus.type=local")
            .run(context -> {
                EventBus eventBus = context.getBean(EventBus.class);
                assertThat(eventBus).isInstanceOf(InMemoryEventBus.class);
            });
    }
    
    @Test
    void testPropertiesConfiguration() {
        contextRunner
            .withPropertyValues(
                "orchestra.enabled=true",
                "orchestra.default-timeout=60",
                "orchestra.event-bus.type=local"
            )
            .run(context -> {
                OrchestraProperties properties = context.getBean(OrchestraProperties.class);
                assertThat(properties.isEnabled()).isTrue();
                assertThat(properties.getDefaultTimeout()).isEqualTo(60);
                assertThat(properties.getEventBus().getType()).isEqualTo("local");
            });
    }
    
    // 测试辅助类
    static class TestRequest {}
    static class TestResponse {}
    static class TestContext extends io.orchestra.core.StandardRuntimeContext<TestRequest, TestResponse> {
        public TestContext(TestRequest request) {
            super(request);
        }
    }
    
    // 自定义 Composer
    static class CustomComposer implements Composer {
        @Override
        public <T extends RuntimeContext<R, S>, R, S> io.orchestra.core.ProcedureManager<T> just(T context) {
            return null;
        }
    }
    
    @Configuration
    static class CustomComposerConfiguration {
        @Bean
        public Composer customComposer() {
            return new CustomComposer();
        }
    }
    
    // 自定义 EventBus
    static class CustomEventBus implements EventBus {
        @Override
        public void publish(io.orchestra.core.eventbus.Event event) {}
        
        @Override
        public java.util.concurrent.CompletableFuture<Void> publishAsync(io.orchestra.core.eventbus.Event event) {
            return java.util.concurrent.CompletableFuture.completedFuture(null);
        }
        
        @Override
        public <E extends io.orchestra.core.eventbus.Event> String subscribe(Class<E> eventType, 
                                                                              io.orchestra.core.eventbus.EventHandler<E> handler) {
            return "subscription-id";
        }
        
        @Override
        public void unsubscribe(String subscriptionId) {}
        
        @Override
        public void unsubscribe(Class<? extends io.orchestra.core.eventbus.Event> eventType) {}
        
        @Override
        public <E extends io.orchestra.core.eventbus.Event> E await(Class<E> eventType, long timeoutMillis) {
            return null;
        }
        
        @Override
        public void shutdown() {}
    }
    
    @Configuration
    static class CustomEventBusConfiguration {
        @Bean
        public EventBus customEventBus() {
            return new CustomEventBus();
        }
    }
}

