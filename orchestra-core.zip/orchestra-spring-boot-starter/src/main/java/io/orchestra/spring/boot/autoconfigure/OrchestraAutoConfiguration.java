package io.orchestra.spring.boot.autoconfigure;

import io.orchestra.core.Composer;
import io.orchestra.core.ReactiveApplicator;
import io.orchestra.core.eventbus.EventBus;
import io.orchestra.core.eventbus.EventBusRegistry;
import io.orchestra.core.eventbus.InMemoryEventBus;
import io.orchestra.core.impl.DefaultComposer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

/**
 * Orchestra 自动配置类。
 * 
 * <p>提供 Orchestra 框架的 Spring Boot 自动配置，包括：</p>
 * <ul>
 *   <li>Composer Bean 的自动创建</li>
 *   <li>ReactiveApplicator Bean 的自动创建</li>
 *   <li>EventBus Bean 的自动创建（支持本地和 Redis 模式）</li>
 * </ul>
 * 
 * <p>配置说明：</p>
 * <ul>
 *   <li>通过 {@code orchestra.enabled} 控制是否启用自动配置（默认：true）</li>
 *   <li>通过 {@code orchestra.event-bus.type} 控制 EventBus 类型（local/redis，默认：local）</li>
 * </ul>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
@Configuration
@ConditionalOnProperty(prefix = "orchestra", name = "enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(OrchestraProperties.class)
public class OrchestraAutoConfiguration {
    
    private static final Logger logger = LoggerFactory.getLogger(OrchestraAutoConfiguration.class);
    
    private final OrchestraProperties properties;
    
    public OrchestraAutoConfiguration(OrchestraProperties properties) {
        this.properties = properties;
    }
    
    /**
     * 创建 Composer Bean。
     */
    @Bean
    @ConditionalOnMissingBean
    public Composer composer() {
        logger.debug("Creating default Composer bean");
        return new DefaultComposer();
    }
    
    /**
     * 创建本地 EventBus Bean（默认）。
     * 当没有配置 Redis 或 EventBus 类型为 local 时使用。
     */
    @Bean(name = "eventBus")
    @ConditionalOnMissingBean(EventBus.class)
    @ConditionalOnProperty(prefix = "orchestra.event-bus", name = "type", havingValue = "local", matchIfMissing = true)
    public EventBus localEventBus() {
        logger.info("Creating local InMemoryEventBus bean");
        InMemoryEventBus eventBus = new InMemoryEventBus();
        // 注册为默认 EventBus
        EventBusRegistry.setDefault(eventBus);
        return eventBus;
    }
    
    
    /**
     * 创建 ReactiveApplicator Bean。
     * 支持泛型注入，但需要在使用时指定类型参数。
     */
    @Bean
    @ConditionalOnMissingBean
    public ReactiveApplicatorFactory reactiveApplicatorFactory(Composer composer) {
        logger.debug("Creating ReactiveApplicatorFactory bean");
        return new ReactiveApplicatorFactory(composer);
    }
    
    /**
     * 创建事件驱动的 Procedure 注册器。
     */
    @Bean
    @ConditionalOnMissingBean
    public EventDrivenProcedureRegistrar eventDrivenProcedureRegistrar() {
        logger.debug("Creating EventDrivenProcedureRegistrar bean");
        return new EventDrivenProcedureRegistrar();
    }
    
    /**
     * 初始化配置。
     */
    @PostConstruct
    public void init() {
        logger.info("Orchestra Spring Boot Starter initialized");
        logger.debug("Orchestra configuration: enabled={}, eventBus.type={}, defaultTimeout={}s",
            properties.isEnabled(),
            properties.getEventBus().getType(),
            properties.getDefaultTimeout());
    }
    
    /**
     * 清理资源。
     */
    @PreDestroy
    public void destroy() {
        logger.info("Orchestra Spring Boot Starter shutting down");
        EventBus eventBus = EventBusRegistry.getDefault();
        if (eventBus != null) {
            eventBus.shutdown();
        }
    }
}

