package io.orchestra.spring.boot.autoconfigure;

import io.orchestra.core.Composer;
import io.orchestra.core.Procedure;
import io.orchestra.core.ReactiveApplicator;
import io.orchestra.core.eventbus.Event;
import io.orchestra.core.eventbus.EventBus;
import io.orchestra.core.eventbus.EventBusRegistry;
import io.orchestra.core.eventbus.EventHandler;
import io.orchestra.spring.boot.annotation.OnEvent;
import io.orchestra.spring.boot.context.EventRuntimeContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.annotation.AnnotationUtils;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

/**
 * 事件驱动的 Procedure 注册器。
 * 
 * <p>在 Spring 容器启动完成后，自动扫描所有带有 {@link OnEvent} 注解的 Procedure，
 * 并注册到 EventBus 中，实现事件驱动的流程执行。</p>
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
public class EventDrivenProcedureRegistrar implements ApplicationContextAware, ApplicationListener<ContextRefreshedEvent> {
    
    private static final Logger logger = LoggerFactory.getLogger(EventDrivenProcedureRegistrar.class);
    
    private ApplicationContext applicationContext;
    
    @Autowired(required = false)
    private Composer composer;
    
    private final List<String> subscriptionIds = new ArrayList<>();
    
    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
    
    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        if (composer == null) {
            logger.warn("Composer bean not found, skipping event-driven procedure registration");
            return;
        }
        
        EventBus eventBus = EventBusRegistry.getDefault();
        if (eventBus == null) {
            logger.warn("EventBus not found, skipping event-driven procedure registration");
            return;
        }
        
        logger.info("Starting event-driven procedure registration...");
        
        // 扫描所有带有 @OnEvent 注解的 Procedure
        Map<String, Object> procedureBeans = applicationContext.getBeansWithAnnotation(OnEvent.class);
        
        for (Map.Entry<String, Object> entry : procedureBeans.entrySet()) {
            Object bean = entry.getValue();
            String beanName = entry.getKey();
            
            if (!(bean instanceof Procedure)) {
                logger.warn("Bean {} is annotated with @OnEvent but does not implement Procedure interface", beanName);
                continue;
            }
            
            @SuppressWarnings("unchecked")
            Procedure<?, ?, ?> procedure = (Procedure<?, ?, ?>) bean;
            OnEvent onEvent = AnnotationUtils.findAnnotation(bean.getClass(), OnEvent.class);
            
            if (onEvent == null) {
                continue;
            }
            
            Class<? extends Event> eventType = onEvent.value();
            boolean async = onEvent.async();
            int priority = onEvent.priority();
            
            try {
                registerEventDrivenProcedure(eventBus, procedure, eventType, async, priority, beanName);
            } catch (Exception e) {
                logger.error("Failed to register event-driven procedure for bean: {}", beanName, e);
            }
        }
        
        logger.info("Event-driven procedure registration completed. Registered {} procedures", subscriptionIds.size());
    }
    
    /**
     * 注册事件驱动的 Procedure。
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private void registerEventDrivenProcedure(
            EventBus eventBus,
            Procedure<?, ?, ?> procedure,
            Class<? extends Event> eventType,
            boolean async,
            int priority,
            String beanName) {
        
        EventHandler handler = new EventHandler() {
            @Override
            public void handle(io.orchestra.core.eventbus.Event event) throws Exception {
                try {
                    // 创建事件上下文
                    EventRuntimeContext context = new EventRuntimeContext(event);
                    
                    // 创建 ReactiveApplicator（使用原始类型避免泛型问题）
                    ReactiveApplicator applicator = new ReactiveApplicator(composer);
                    
                    // 执行 Procedure
                    if (async) {
                        // 异步执行
                        applicator.applyAsync(context, (Procedure) procedure)
                            .subscribe(
                                result -> logger.debug("Event-driven procedure executed successfully: bean={}, eventType={}", 
                                    beanName, eventType.getSimpleName()),
                                error -> logger.error("Event-driven procedure execution failed: bean={}, eventType={}", 
                                    beanName, eventType.getSimpleName(), error)
                            );
                    } else {
                        // 同步执行
                        try {
                            applicator.apply(context, (Procedure) procedure);
                            logger.debug("Event-driven procedure executed successfully: bean={}, eventType={}", 
                                beanName, eventType.getSimpleName());
                        } catch (Exception e) {
                            logger.error("Event-driven procedure execution failed: bean={}, eventType={}", 
                                beanName, eventType.getSimpleName(), e);
                        }
                    }
                } catch (Exception e) {
                    logger.error("Failed to execute event-driven procedure: bean={}, eventType={}", 
                        beanName, eventType.getSimpleName(), e);
                }
            }
        };
        
        // 注册到 EventBus
        String subscriptionId = eventBus.subscribe(eventType, handler);
        subscriptionIds.add(subscriptionId);
        
        logger.info("Registered event-driven procedure: bean={}, eventType={}, async={}, priority={}", 
            beanName, eventType.getSimpleName(), async, priority);
    }
    
    /**
     * 获取所有订阅 ID（用于测试和调试）。
     */
    public List<String> getSubscriptionIds() {
        return new ArrayList<>(subscriptionIds);
    }
}

