package io.orchestra.spring.boot.autoconfigure;

import io.orchestra.core.Composer;
import io.orchestra.core.ReactiveApplicator;
import io.orchestra.core.RuntimeContext;

/**
 * ReactiveApplicator 工厂类。
 * 
 * <p>由于 ReactiveApplicator 是泛型类，无法直接作为 Spring Bean 注入。
 * 通过工厂类提供创建 ReactiveApplicator 实例的方法。</p>
 * 
 * <p>使用示例：</p>
 * <pre>{@code
 * @Autowired
 * private ReactiveApplicatorFactory applicatorFactory;
 * 
 * public void executeProcedure() {
 *     ReactiveApplicator<OrderRequest, OrderResponse, OrderContext> applicator = 
 *         applicatorFactory.create();
 *     // 使用 applicator...
 * }
 * }</pre>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
public class ReactiveApplicatorFactory {
    
    private final Composer composer;
    
    public ReactiveApplicatorFactory(Composer composer) {
        this.composer = composer;
    }
    
    /**
     * 创建 ReactiveApplicator 实例。
     * 
     * @param <R> 请求类型
     * @param <S> 响应类型
     * @param <T> 运行时上下文类型
     * @return ReactiveApplicator 实例
     */
    public <R, S, T extends RuntimeContext<R, S>> ReactiveApplicator<R, S, T> create() {
        return new ReactiveApplicator<>(composer);
    }
    
    /**
     * 获取 Composer 实例。
     * 
     * @return Composer 实例
     */
    public Composer getComposer() {
        return composer;
    }
}


