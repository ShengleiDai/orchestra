package io.orchestra.spring.boot.autoconfigure;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Orchestra 配置属性类。
 * 
 * <p>用于配置 Orchestra 框架的各种参数，支持通过 application.yml 或 application.properties 进行配置。</p>
 * 
 * <p>配置示例：</p>
 * <pre>{@code
 * orchestra:
 *   enabled: true
 *   event-bus:
 *     type: local  # local, redis
 *     redis:
 *       topic: orchestra:events
 *   default-timeout: 30s
 * }</pre>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
@ConfigurationProperties(prefix = "orchestra")
public class OrchestraProperties {
    
    /**
     * 是否启用 Orchestra 自动配置。
     */
    private boolean enabled = true;
    
    /**
     * EventBus 配置。
     */
    private EventBus eventBus = new EventBus();
    
    /**
     * 默认超时时间（秒）。
     */
    private long defaultTimeout = 30;
    
    public boolean isEnabled() {
        return enabled;
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    public EventBus getEventBus() {
        return eventBus;
    }
    
    public void setEventBus(EventBus eventBus) {
        this.eventBus = eventBus;
    }
    
    public long getDefaultTimeout() {
        return defaultTimeout;
    }
    
    public void setDefaultTimeout(long defaultTimeout) {
        this.defaultTimeout = defaultTimeout;
    }
    
    /**
     * EventBus 配置。
     */
    public static class EventBus {
        
        /**
         * EventBus 类型：local（本地内存）、redis（Redis 分布式）。
         */
        private String type = "local";
        
        /**
         * Redis 配置（当 type 为 redis 时使用）。
         */
        private Redis redis = new Redis();
        
        public String getType() {
            return type;
        }
        
        public void setType(String type) {
            this.type = type;
        }
        
        public Redis getRedis() {
            return redis;
        }
        
        public void setRedis(Redis redis) {
            this.redis = redis;
        }
        
        /**
         * Redis EventBus 配置。
         */
        public static class Redis {
            
            /**
             * Redis 主题名称。
             */
            private String topic = "orchestra:events";
            
            public String getTopic() {
                return topic;
            }
            
            public void setTopic(String topic) {
                this.topic = topic;
            }
        }
    }
}


