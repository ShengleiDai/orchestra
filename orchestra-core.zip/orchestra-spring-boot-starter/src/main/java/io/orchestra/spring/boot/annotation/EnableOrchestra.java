package io.orchestra.spring.boot.annotation;

import io.orchestra.spring.boot.autoconfigure.OrchestraAutoConfiguration;
import org.springframework.context.annotation.Import;

import java.lang.annotation.*;

/**
 * 启用 Orchestra 框架的注解。
 * 
 * <p>在 Spring Boot 应用中使用此注解来启用 Orchestra 框架的自动配置。
 * 通常不需要显式使用，因为自动配置会默认启用。</p>
 * 
 * <p>使用示例：</p>
 * <pre>{@code
 * @SpringBootApplication
 * @EnableOrchestra
 * public class Application {
 *     public static void main(String[] args) {
 *         SpringApplication.run(Application.class, args);
 *     }
 * }
 * }</pre>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Import(OrchestraAutoConfiguration.class)
public @interface EnableOrchestra {
}


