package io.orchestra.spring.boot.annotation;

import java.lang.annotation.*;

/**
 * 标记 Procedure 监听的事件。
 * 
 * <p>用于标记实现了 {@link io.orchestra.core.Procedure} 接口的类，
 * 使其能够在接收到指定事件时自动触发执行。</p>
 * 
 * <p>使用示例：</p>
 * <pre>{@code
 * @OrchestraProcedure
 * @OnEvent(OrderCreatedEvent.class)
 * public class OrderCreatedHandlerProcedure implements Procedure<OrderCreatedEvent, Void, OrderContext> {
 *     
 *     @Autowired
 *     private NotificationService notificationService;
 *     
 *     @Override
 *     public Procedurable<OrderContext> execute(OrderContext context, Composer composer) {
 *         return composer.just(context)
 *             .sync(ctx -> notificationService.sendNotification(ctx.getEvent()));
 *     }
 * }
 * }</pre>
 * 
 * <p>支持的事件类型：</p>
 * <ul>
 *   <li>普通事件：继承自 {@link io.orchestra.core.eventbus.Event} 的事件类</li>
 *   <li>状态机事件：用于状态机转换的事件类</li>
 * </ul>
 * 
 * @author Orchestra Team
 * @since 2.0.0
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface OnEvent {
    
    /**
     * 要监听的事件类型。
     * 
     * @return 事件类型 Class
     */
    Class<? extends io.orchestra.core.eventbus.Event> value();
    
    /**
     * 是否异步执行。
     * 
     * <p>如果为 true，事件处理将在异步线程中执行，不会阻塞事件发布者。</p>
     * 
     * @return 是否异步执行，默认为 true
     */
    boolean async() default true;
    
    /**
     * 事件处理器的优先级。
     * 
     * <p>数值越小，优先级越高。相同优先级的事件处理器按注册顺序执行。</p>
     * 
     * @return 优先级，默认为 0
     */
    int priority() default 0;
}


