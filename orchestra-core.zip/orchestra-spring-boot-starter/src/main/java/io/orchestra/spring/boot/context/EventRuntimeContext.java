package io.orchestra.spring.boot.context;

import io.orchestra.core.StandardRuntimeContext;
import io.orchestra.core.eventbus.Event;

/**
 * 基于事件的运行时上下文。
 * 
 * <p>用于事件驱动的 Procedure 执行，将事件作为请求对象。</p>
 * 
 * @param <E> 事件类型
 * @author Orchestra Team
 * @since 2.0.0
 */
public class EventRuntimeContext<E extends Event> extends StandardRuntimeContext<E, Void> {
    
    /**
     * 构造一个基于事件的运行时上下文。
     * 
     * @param event 触发流程的事件
     */
    public EventRuntimeContext(E event) {
        super(event);
    }
    
    /**
     * 获取触发流程的事件。
     * 
     * @return 事件对象
     */
    public E getEvent() {
        return getRequest();
    }
}


