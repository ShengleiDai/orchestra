package io.orchestra.spring.boot.eventbus;

import io.orchestra.core.eventbus.Event;
import io.orchestra.core.eventbus.EventBus;
import io.orchestra.core.eventbus.EventBusException;
import io.orchestra.core.eventbus.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;

/**
 * 基于 Redis 的分布式 EventBus 实现。
 * 
 * <p>支持跨进程、跨机器的分布式事件发布和订阅。</p>
 * 
 * <p>使用 Redis 的发布/订阅功能实现事件总线，支持：</p>
 * <ul>
 *   <li>跨进程事件发布和订阅</li>
 *   <li>事件序列化（JSON）</li>
 *   <li>本地事件处理器管理</li>
 * </ul>
 * 
 * <p>注意：此实现需要 Redis 服务器支持。</p>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
public class RedisEventBus implements EventBus {
    
    private static final Logger logger = LoggerFactory.getLogger(RedisEventBus.class);
    
    private final RedisConnectionFactory connectionFactory;
    private final String topic;
    private final RedisTemplate<String, Object> redisTemplate;
    private final RedisMessageListenerContainer listenerContainer;
    private final ConcurrentHashMap<Class<? extends Event>, CopyOnWriteArrayList<EventHandlerWrapper>> localHandlers;
    private final ConcurrentHashMap<String, EventHandlerWrapper> subscriptionMap;
    private volatile boolean shutdown = false;
    
    public RedisEventBus(RedisConnectionFactory connectionFactory, String topic) {
        this.connectionFactory = connectionFactory;
        this.topic = topic;
        this.localHandlers = new ConcurrentHashMap<>();
        this.subscriptionMap = new ConcurrentHashMap<>();
        
        // 创建 RedisTemplate
        this.redisTemplate = new RedisTemplate<>();
        this.redisTemplate.setConnectionFactory(connectionFactory);
        this.redisTemplate.setKeySerializer(new StringRedisSerializer());
        this.redisTemplate.setValueSerializer(new GenericJackson2JsonRedisSerializer());
        this.redisTemplate.afterPropertiesSet();
        
        // 创建消息监听容器
        this.listenerContainer = new RedisMessageListenerContainer();
        this.listenerContainer.setConnectionFactory(connectionFactory);
        
        // 创建消息监听适配器
        MessageListenerAdapter adapter = new MessageListenerAdapter(this, "handleRedisMessage");
        this.listenerContainer.addMessageListener(adapter, new ChannelTopic(topic));
    }
    
    @PostConstruct
    public void init() {
        if (!shutdown) {
            listenerContainer.start();
            logger.info("RedisEventBus initialized with topic: {}", topic);
        }
    }
    
    @PreDestroy
    @Override
    public void shutdown() {
        if (shutdown) {
            return;
        }
        shutdown = true;
        
        if (listenerContainer != null && listenerContainer.isRunning()) {
            listenerContainer.stop();
        }
        
        localHandlers.clear();
        subscriptionMap.clear();
        
        logger.info("RedisEventBus shut down");
    }
    
    @Override
    public void publish(Event event) throws EventBusException {
        if (event == null) {
            throw new NullPointerException("Event cannot be null");
        }
        if (shutdown) {
            throw new EventBusException("EventBus has been shut down");
        }
        
        try {
            // 发布到 Redis
            redisTemplate.convertAndSend(topic, event);
            
            // 本地处理（如果有本地订阅者）
            handleLocalEvent(event);
            
        } catch (Exception e) {
            throw new EventBusException("Failed to publish event: " + event.getClass().getSimpleName(), e);
        }
    }
    
    @Override
    public CompletableFuture<Void> publishAsync(Event event) {
        CompletableFuture<Void> future = new CompletableFuture<>();
        
        if (event == null) {
            future.completeExceptionally(new NullPointerException("Event cannot be null"));
            return future;
        }
        if (shutdown) {
            future.completeExceptionally(new EventBusException("EventBus has been shut down"));
            return future;
        }
        
        return CompletableFuture.runAsync(() -> {
            try {
                publish(event);
            } catch (EventBusException e) {
                throw new RuntimeException(e);
            }
        }, Executors.newCachedThreadPool(r -> {
            Thread t = new Thread(r, "RedisEventBus-Async-" + UUID.randomUUID().toString().substring(0, 8));
            t.setDaemon(true);
            return t;
        }));
    }
    
    @Override
    public <E extends Event> String subscribe(Class<E> eventType, EventHandler<E> handler) {
        if (eventType == null) {
            throw new NullPointerException("Event type cannot be null");
        }
        if (handler == null) {
            throw new NullPointerException("Event handler cannot be null");
        }
        if (shutdown) {
            throw new EventBusException("EventBus has been shut down");
        }
        
        String subscriptionId = UUID.randomUUID().toString();
        EventHandlerWrapper wrapper = new EventHandlerWrapper(subscriptionId, eventType, handler);
        
        localHandlers.computeIfAbsent(eventType, k -> new CopyOnWriteArrayList<>()).add(wrapper);
        subscriptionMap.put(subscriptionId, wrapper);
        
        logger.debug("Subscribed to event type: {} with subscription ID: {}", eventType.getSimpleName(), subscriptionId);
        return subscriptionId;
    }
    
    @Override
    public void unsubscribe(String subscriptionId) {
        if (subscriptionId == null || subscriptionId.trim().isEmpty()) {
            return;
        }
        
        EventHandlerWrapper wrapper = subscriptionMap.remove(subscriptionId);
        if (wrapper != null) {
            localHandlers.get(wrapper.getEventType()).remove(wrapper);
            logger.debug("Unsubscribed subscription ID: {}", subscriptionId);
        }
    }
    
    @Override
    public void unsubscribe(Class<? extends Event> eventType) {
        if (eventType == null) {
            return;
        }
        
        CopyOnWriteArrayList<EventHandlerWrapper> handlers = localHandlers.remove(eventType);
        if (handlers != null) {
            handlers.forEach(wrapper -> subscriptionMap.remove(wrapper.getSubscriptionId()));
            logger.debug("Unsubscribed all handlers for event type: {}", eventType.getSimpleName());
        }
    }
    
    @Override
    public <E extends Event> E await(Class<E> eventType, long timeoutMillis) {
        // Redis EventBus 的 await 功能需要额外的实现（使用阻塞队列）
        // 这里简化实现，实际生产环境可能需要更复杂的实现
        throw new UnsupportedOperationException("await() is not supported in RedisEventBus. " +
            "Use local EventBus or implement custom waiting mechanism.");
    }
    
    /**
     * 处理从 Redis 接收到的消息。
     * 此方法由 RedisMessageListenerAdapter 调用。
     */
    @SuppressWarnings("unused")
    public void handleRedisMessage(Object message) {
        if (shutdown || !(message instanceof Event)) {
            return;
        }
        
        Event event = (Event) message;
        handleLocalEvent(event);
    }
    
    /**
     * 处理本地事件。
     */
    private void handleLocalEvent(Event event) {
        Class<? extends Event> eventType = event.getClass();
        CopyOnWriteArrayList<EventHandlerWrapper> handlers = localHandlers.get(eventType);
        
        if (handlers != null && !handlers.isEmpty()) {
            for (EventHandlerWrapper wrapper : handlers) {
                try {
                    @SuppressWarnings("unchecked")
                    EventHandler<Event> handler = (EventHandler<Event>) wrapper.getHandler();
                    handler.handle(event);
                } catch (Exception e) {
                    logger.error("Error handling event: " + eventType.getSimpleName(), e);
                }
            }
        }
    }
    
    /**
     * 事件处理器包装类。
     */
    private static class EventHandlerWrapper {
        private final String subscriptionId;
        private final Class<? extends Event> eventType;
        private final EventHandler<? extends Event> handler;
        
        public EventHandlerWrapper(String subscriptionId, Class<? extends Event> eventType, 
                                   EventHandler<? extends Event> handler) {
            this.subscriptionId = subscriptionId;
            this.eventType = eventType;
            this.handler = handler;
        }
        
        public String getSubscriptionId() {
            return subscriptionId;
        }
        
        public Class<? extends Event> getEventType() {
            return eventType;
        }
        
        @SuppressWarnings("unchecked")
        public <E extends Event> EventHandler<E> getHandler() {
            return (EventHandler<E>) handler;
        }
    }
}

