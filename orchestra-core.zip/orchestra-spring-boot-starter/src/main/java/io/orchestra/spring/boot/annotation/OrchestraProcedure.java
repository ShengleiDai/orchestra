package io.orchestra.spring.boot.annotation;

import org.springframework.stereotype.Component;

import java.lang.annotation.*;

/**
 * 标记 Orchestra Procedure 的注解。
 * 
 * <p>用于标记实现了 {@link io.orchestra.core.Procedure} 接口的类，
 * 使其能够被 Spring 容器管理，并可以通过依赖注入使用其他 Spring Bean。</p>
 * 
 * <p>使用示例：</p>
 * <pre>{@code
 * @OrchestraProcedure
 * public class OrderCreationProcedure implements Procedure<OrderRequest, OrderResponse, OrderContext> {
 *     
 *     @Autowired
 *     private OrderService orderService;
 *     
 *     @Override
 *     public Procedurable<OrderContext> execute(OrderContext context, Composer composer) {
 *         return composer.just(context)
 *             .sync(ctx -> orderService.validate(ctx))
 *             .async(ctx -> orderService.process(ctx));
 *     }
 * }
 * }</pre>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Component
public @interface OrchestraProcedure {
    
    /**
     * Bean 名称。
     * 
     * @return Bean 名称
     */
    String value() default "";
}


