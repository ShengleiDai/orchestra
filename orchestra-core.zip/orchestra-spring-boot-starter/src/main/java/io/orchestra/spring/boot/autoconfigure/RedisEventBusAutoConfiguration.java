package io.orchestra.spring.boot.autoconfigure;

import io.orchestra.core.eventbus.EventBus;
import io.orchestra.core.eventbus.EventBusRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Redis EventBus 自动配置类。
 * 
 * <p>当检测到 Redis 相关类存在且配置了 Redis EventBus 时，自动创建 RedisEventBus Bean。</p>
 * 
 * @author Orchestra Team
 * @since 1.0.0
 */
@Configuration
@ConditionalOnProperty(prefix = "orchestra.event-bus", name = "type", havingValue = "redis")
@ConditionalOnClass(name = "org.springframework.data.redis.connection.RedisConnectionFactory")
public class RedisEventBusAutoConfiguration {
    
    private static final Logger logger = LoggerFactory.getLogger(RedisEventBusAutoConfiguration.class);
    
    private final OrchestraProperties properties;
    
    private final ApplicationContext applicationContext;
    
    public RedisEventBusAutoConfiguration(OrchestraProperties properties, ApplicationContext applicationContext) {
        this.properties = properties;
        this.applicationContext = applicationContext;
    }
    
    /**
     * 创建 Redis EventBus Bean。
     * 当配置了 RedisConnectionFactory 且 EventBus 类型为 redis 时使用。
     */
    @Bean(name = "eventBus")
    @ConditionalOnMissingBean(EventBus.class)
    @ConditionalOnBean(name = "redisConnectionFactory")
    public EventBus redisEventBus() {
        logger.info("Creating RedisEventBus bean with topic: {}", 
            properties.getEventBus().getRedis().getTopic());
        
        try {
            // 使用反射来避免编译时依赖 Redis 类
            Object connectionFactory = applicationContext.getBean("redisConnectionFactory");
            
            // 使用反射创建 RedisEventBus 实例
            Class<?> redisEventBusClass = Class.forName("io.orchestra.spring.boot.eventbus.RedisEventBus");
            Object eventBus = redisEventBusClass.getConstructor(
                connectionFactory.getClass(),
                String.class
            ).newInstance(connectionFactory, properties.getEventBus().getRedis().getTopic());
            
            // 注册为默认 EventBus
            EventBusRegistry.setDefault((EventBus) eventBus);
            return (EventBus) eventBus;
        } catch (Exception e) {
            logger.error("Failed to create RedisEventBus", e);
            throw new IllegalStateException("Failed to create RedisEventBus. " +
                "Please ensure spring-boot-starter-data-redis is in the classpath.", e);
        }
    }
}

