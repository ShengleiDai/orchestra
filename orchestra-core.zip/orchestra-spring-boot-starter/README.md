# Orchestra Spring Boot Starter

Orchestra Spring Boot Starter 是 Orchestra 框架的 Spring Boot 集成模块，提供了与 Spring 框架的深度集成，让 Orchestra 能够更好地应用于 Spring Boot 应用开发中。

## 特性

- ✅ **零配置启动**：通过 Spring Boot 自动配置，最小化配置工作
- ✅ **依赖注入支持**：支持在 Procedure 中使用 Spring Bean
- ✅ **灵活配置**：支持通过配置文件自定义 Orchestra 行为
- ✅ **多种 EventBus 模式**：支持本地（InMemory）和分布式（Redis）EventBus
- ✅ **类型安全**：保持 Orchestra 的类型安全特性
- ✅ **易于测试**：与 Spring Boot Test 框架完美集成

## 快速开始

### 1. 添加依赖

```xml
<dependency>
    <groupId>io.orchestra</groupId>
    <artifactId>orchestra-spring-boot-starter</artifactId>
    <version>1.0-SNAPSHOT</version>
</dependency>
```

### 2. 定义业务流程

```java
@OrchestraProcedure
public class OrderCreationProcedure 
        implements Procedure<OrderRequest, OrderResponse, OrderContext> {
    
    @Autowired
    private OrderService orderService;
    
    @Override
    public Procedurable<OrderContext> execute(OrderContext context, Composer composer) {
        return composer.just(context)
            .sync(ctx -> orderService.validate(ctx.getRequest()))
            .async(ctx -> orderService.process(ctx.getOrderId()));
    }
}
```

### 3. 执行流程

```java
@RestController
public class OrderController {
    
    @Autowired
    private ReactiveApplicatorFactory applicatorFactory;
    
    @PostMapping("/orders")
    public ResponseEntity<OrderResponse> createOrder(@RequestBody OrderRequest request) {
        ReactiveApplicator<OrderRequest, OrderResponse, OrderContext> applicator = 
            applicatorFactory.create();
        
        OrderContext context = new OrderContext(request);
        RuntimeContext<OrderRequest, OrderResponse> result = 
            applicator.apply(context, new OrderCreationProcedure());
        
        return ResponseEntity.ok(result.getResponse());
    }
}
```

## 配置

### 基本配置

```yaml
orchestra:
  enabled: true                    # 是否启用 Orchestra（默认：true）
  default-timeout: 30              # 默认超时时间（秒，默认：30）
  event-bus:
    type: local                    # EventBus 类型：local（本地）或 redis（分布式）
    redis:
      topic: orchestra:events      # Redis 主题名称（默认：orchestra:events）
```

### 本地模式（默认）

```yaml
orchestra:
  event-bus:
    type: local
```

### Redis 模式

```yaml
orchestra:
  event-bus:
    type: redis
    redis:
      topic: orchestra:events

spring:
  redis:
    host: localhost
    port: 6379
```

**注意**：使用 Redis 模式需要添加 Spring Data Redis 依赖：

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-redis</artifactId>
</dependency>
```

## 文档

- [用户指南](用户指南.md) - 详细的使用说明和示例
- [开发指南](开发指南.md) - 架构设计和扩展开发指南

## 模块结构

```
orchestra-spring-boot-starter/
├── src/main/java/
│   └── io/orchestra/spring/boot/
│       ├── autoconfigure/          # 自动配置
│       │   ├── OrchestraAutoConfiguration.java
│       │   ├── OrchestraProperties.java
│       │   └── ReactiveApplicatorFactory.java
│       ├── annotation/              # 注解支持
│       │   ├── EnableOrchestra.java
│       │   └── OrchestraProcedure.java
│       └── eventbus/                # EventBus 实现
│           └── RedisEventBus.java
└── src/main/resources/
    └── META-INF/
        └── spring.factories         # 自动配置注册
```

## 核心组件

### OrchestraAutoConfiguration

自动配置类，负责创建和管理 Orchestra 相关的 Spring Bean。

### OrchestraProperties

配置属性类，用于读取 `application.yml` 或 `application.properties` 中的配置。

### ReactiveApplicatorFactory

由于 `ReactiveApplicator` 是泛型类，无法直接作为 Spring Bean 注入。通过工厂类提供创建实例的方法。

### RedisEventBus

基于 Redis 的分布式 EventBus 实现，支持跨进程、跨机器的分布式事件发布和订阅。

## 许可证

[待定]

## 贡献

欢迎贡献代码和提出建议！


